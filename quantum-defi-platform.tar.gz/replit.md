# Quantum - Intent-Driven DeFi Protocol

## Overview

Quantum is an advanced Web3 DeFi platform with AI-powered features, including intent-based interactions, automated strategy proposals, MEV protection/capture, and multichain support. The platform features a modern futuristic interface with chat-based AI interactions and comprehensive DeFi pools exploration across all major protocols.

**Current Status (Feb 2025):** Counter-Argument Engine PRODUCTION READY. Pool dashboard fully implemented with interactive analytics and detailed popups. Complete AI-powered chat system with robust error handling.

**✅ Counter-Argument Engine - PRODUCTION DEPLOYMENT READY:**
- **Vietnamese NLP Processor** - Complete Vietnamese text processing with DeFi vocabulary (60+ crypto terms)
- **Logical Fallacy Detector** - 8 fallacy types with pattern matching and ML classification 
- **DeFi Knowledge Graph** - Comprehensive knowledge base with 50+ protocols, concepts, risks
- **Evidence Synthesizer** - Source credibility assessment with 15+ trusted DeFi data providers
- **Response Generator** - Multi-strategy response generation with adaptive tone and context
- **Advanced Text Processing** - TF-IDF vectorization, semantic similarity, pattern recognition
- **ML Models Integration** - TensorFlow.js, Natural NLP, sentiment analysis, multi-language support
- **✅ PRODUCTION: Circuit Breaker System** - Robust quota management with 5-minute reset timeout
- **✅ PRODUCTION: Smart Fallback Responses** - Topic-specific knowledge (Bitcoin, DeFi, safety analysis)
- **✅ PRODUCTION: Multi-language Support** - Vietnamese/English with proper UI language separation
- **✅ PRODUCTION: Error Handling** - Graceful degradation with 0.8 confidence scores and fast response times

**Libraries Installed:**
- AI/ML: TensorFlow.js, Natural, Node-NLP, ML-Matrix, ML-Regression, Sentiment Analysis
- Language: Compromise, Franc-min, Langdetect, Vader-sentiment, Stopword
- Utils: Lodash, Underscore, Moment, Axios, Cheerio
- Core: OpenAI GPT-4 integration for advanced reasoning

**✅ COMPLETED: Production Chat System:**
- **Chat Interface Integration** - Real-time chat box with Counter-Argument Engine
- **User Interaction Flow**: User message → Vietnamese NLP → Fallacy Detection → Knowledge Graph → Response Generation → Reply  
- **API Endpoints** - Backend routes for chat functionality (`/api/chat`)
- **Multi-language Support** - Vietnamese ↔ English seamless conversation
- **Circuit Breaker Protection** - Prevents API quota exhaustion with intelligent fallbacks
- **Response Times** - Optimized to ~1.7-2s with fallback system

## User Preferences

Preferred communication style: Simple, everyday language.
UI Design: Modern, futuristic design with quantum-themed styling and neon effects.
Language: All content in English.
Navigation: Horizontal header navigation next to logo.
Dashboard Content: Comprehensive DeFi pools explorer showing all protocols and chains.
Pool Display: 15 pools per page with pagination, pool cards with expandable details, Flow Routes visualization, interactive popup analytics with investment calculator.
Chain Selection: Dropdown with 68+ chains and chain avatars for visual identification.
Vault Types: Two distinct vault types - Project-created vaults (curated strategies) and User-designed vaults (custom strategies).
Analytics Features: Interactive investment calculator, risk analysis, performance metrics, advanced analytics in popup modals.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development patterns
- **UI Components**: Shadcn/ui component library built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with custom CSS variables for theming, including Web3-specific color schemes
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules for modern JavaScript features
- **Development**: TSX for TypeScript execution in development
- **Build**: ESBuild for fast production bundling
- **Storage Interface**: Abstracted storage layer with in-memory implementation for user data

### Database & ORM
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for production use)
- **Connection**: Neon Database serverless driver for scalable connections
- **Migrations**: Drizzle Kit for database schema management
- **Schema**: User management with username/password authentication

### Web3 Integration & Real-time DeFi Data
- **Library**: Ethers.js for blockchain interactions
- **Networks**: Multi-chain support for 384+ blockchains including Ethereum, Polygon, BSC, Arbitrum, Optimism, Avalanche, Solana, and more
- **Real-time Data**: Automated data fetching from CoinGecko DEX API, DeFiLlama, and yield farming APIs every 30 seconds
- **Features**: 
  - Wallet connection and management
  - Token balance tracking and transfers
  - Smart contract interaction with ERC-20 support
  - Transaction history and monitoring
  - Network switching capabilities
  - Live DeFi pools data with TVL, APY, volume tracking
  - Comprehensive protocol and blockchain analytics
  - Advanced filtering and pagination (15 pools per page)
  - Flow route visualization for yield farming strategies
  - **Enhanced Multi-Source Logo System**: 
    - Protocol logos: 30+ major DeFi protocols with 2-3 backup sources each
    - Asset logos: 25+ major cryptocurrencies and tokens with multiple API endpoints
    - Smart onError handling automatically switches to next available source
    - Sources include CoinGecko, CryptoLogos, and project-specific domains
    - Comprehensive fallback chain: Primary API → Secondary API → Placeholder with protocol initial
  - **Interactive Pool Analytics**: 
    - Expandable pool cards with Flow Routes visualization showing token → protocol → yield flows
    - View Details popup: Pool information, financial metrics, asset composition, investment strategy with security/performance features
    - Analytics popup: Performance metrics, risk analysis, interactive investment calculator, advanced metrics (Sharpe ratio, drawdown, volatility)
    - Real-time calculations for investment returns with compound interest formula
    - User-configurable investment amount and timeframe selection

### Component Architecture
- **Wallet Management**: Context-based wallet state management with React hooks
- **Modular Components**: Separate components for contract interaction, token transfers, and transaction history
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Toast Notifications**: Custom toast system for user feedback

### Development Environment
- **Replit Integration**: Custom Vite plugins for Replit development environment
- **Hot Reload**: Vite HMR for fast development cycles
- **Error Handling**: Runtime error overlay for development debugging

## External Dependencies

### Blockchain Services
- **Infura**: Ethereum mainnet RPC provider for blockchain connectivity
- **Network RPCs**: Direct RPC connections for Polygon and BSC networks
- **Block Explorers**: Etherscan, Polygonscan, and BSCScan for transaction verification

### UI & Design System
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives
- **Lucide Icons**: Modern icon library for consistent iconography
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens

### Development & Build Tools
- **Vite**: Build tool and development server
- **ESBuild**: Fast JavaScript bundler for production
- **PostCSS**: CSS processing with Autoprefixer

### Database & Persistence
- **Neon Database**: Serverless PostgreSQL provider
- **Drizzle ORM**: Type-safe database toolkit
- **Connect PG Simple**: PostgreSQL session store for Express

### Utility Libraries
- **Date-fns**: Date manipulation and formatting
- **Class Variance Authority**: Utility for managing component variants
- **CLSX**: Conditional className utility
- **Zod**: TypeScript-first schema validation