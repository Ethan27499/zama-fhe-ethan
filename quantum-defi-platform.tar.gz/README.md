# Quantum - AI-Powered DeFi Platform with Counter-Argument Engine

An advanced Web3 DeFi platform featuring AI-powered intent-based interactions, comprehensive DeFi pools marketplace, and a sophisticated Counter-Argument Engine for intelligent chat responses.

## 🚀 Features

### Counter-Argument Engine (Production Ready)
- **Vietnamese NLP Processing** - Advanced text processing with 60+ DeFi-specific crypto terms
- **Logical Fallacy Detection** - 8 fallacy types with pattern matching and ML classification
- **DeFi Knowledge Graph** - 50+ protocols, concepts, and risk analysis
- **Circuit Breaker Protection** - Robust quota management with intelligent fallbacks
- **Multi-language Support** - Seamless Vietnamese ↔ English conversation
- **Real-time Chat Interface** - Fast responses (~1.7-2s) with graceful error handling

### DeFi Marketplace
- **384+ Blockchain Support** - Comprehensive multi-chain DeFi data
- **Real-time Pool Data** - TVL, APY, volume tracking with 30-second updates
- **Interactive Analytics** - Investment calculator, risk analysis, performance metrics
- **Flow Route Visualization** - Token → protocol → yield flow mapping
- **Advanced Filtering** - 15 pools per page with intelligent pagination

### Technical Stack
- **Frontend**: React 18 + TypeScript, Tailwind CSS, Shadcn/ui
- **Backend**: Node.js + Express, TypeScript
- **AI/ML**: OpenAI GPT-4, TensorFlow.js, Natural NLP, multi-language detection
- **Database**: PostgreSQL with Drizzle ORM
- **Web3**: Ethers.js with multi-chain support
- **Real-time**: WebSocket integration for live data

## 📋 Prerequisites

- Node.js 18+ 
- PostgreSQL database
- OpenAI API key (optional - fallback system available)

## 🛠️ Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd quantum-defi-platform
```

2. **Install dependencies**
```bash
npm install
```

3. **Environment Setup**
```bash
# Copy environment template
cp .env.example .env

# Required variables:
DATABASE_URL=postgresql://...
OPENAI_API_KEY=sk-... # Optional - fallback system available
```

4. **Database Setup**
```bash
# Push schema to database
npm run db:push
```

5. **Start Development Server**
```bash
npm run dev
```

## 🧠 Counter-Argument Engine Usage

### Chat API Endpoint
```javascript
POST /api/chat
Content-Type: application/json

{
  "message": "Bitcoin sẽ lên $100k năm nay",
  "sessionId": "optional-session-id"
}
```

### Response Format
```javascript
{
  "success": true,
  "data": {
    "response": "Về Bitcoin: Đây là cryptocurrency đầu tiên...",
    "analysis": {
      "language": "vietnamese",
      "fallacies": [],
      "confidence": 0.8,
      "processingTime": 1725
    },
    "metadata": {
      "sources": ["Fallback knowledge base", "DeFi risk assessment"],
      "warnings": ["Warning: DeFi involves significant risks..."],
      "sessionId": "session_1754151343291"
    }
  }
}
```

### Supported Languages
- **Vietnamese**: Full NLP processing with DeFi terminology
- **English**: Complete fallacy detection and response generation
- **Auto-detection**: Intelligent language detection from user input

## 🏗️ Architecture

### AI Components
- **Vietnamese NLP Processor** (`server/ai/vietnamese-nlp.ts`)
- **Logical Fallacy Detector** (`server/ai/fallacy-detector.ts`)
- **DeFi Knowledge Graph** (`server/ai/knowledge-graph.ts`)
- **Response Generator** (`server/ai/response-generator.ts`)

### Circuit Breaker System
- **Failure Threshold**: 3 consecutive API failures
- **Reset Timeout**: 5 minutes
- **Fallback Responses**: Topic-specific intelligent responses
- **Error Recovery**: Graceful degradation with maintained functionality

### Frontend Structure
```
client/
├── src/
│   ├── components/
│   │   ├── ChatInterface.tsx      # Main chat component
│   │   ├── layout/
│   │   └── ui/                    # Shadcn components
│   ├── pages/
│   │   ├── ChatPage.tsx          # Chat interface page
│   │   ├── HomePage.tsx          # Pool marketplace
│   │   └── App.tsx               # Main app router
```

### Backend Structure
```
server/
├── ai/                           # Counter-Argument Engine
│   ├── index.ts                  # Main engine orchestrator
│   ├── vietnamese-nlp.ts         # Vietnamese processing
│   ├── fallacy-detector.ts       # Logical fallacy detection
│   ├── knowledge-graph.ts        # DeFi knowledge base
│   └── response-generator.ts     # Response generation
├── routes/
│   ├── chat.ts                   # Chat API endpoints
│   └── pools.ts                  # DeFi pools API
└── index.ts                      # Express server
```

## 🚦 Production Deployment

### Environment Variables
```bash
# Required
DATABASE_URL=postgresql://user:pass@host:port/db
NODE_ENV=production

# Optional (fallback system available)
OPENAI_API_KEY=sk-...

# Auto-configured by hosting platform
PORT=5000
```

### Performance Optimizations
- **Circuit Breaker**: Prevents API quota exhaustion
- **Response Caching**: Intelligent fallback knowledge base
- **Database Pooling**: Optimized PostgreSQL connections
- **Error Handling**: Graceful degradation with maintained UX

## 🧪 Testing

### Chat Engine Testing
```bash
# Test English input
curl -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Is DeFi safe for beginners?"}'

# Test Vietnamese input  
curl -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Bitcoin sẽ lên $100k năm nay"}'
```

### Health Check
```bash
curl http://localhost:5000/api/chat/health
```

## 📚 API Documentation

### Chat Endpoints
- `POST /api/chat` - Process user message through Counter-Argument Engine
- `GET /api/chat/health` - Health check for AI components

### Pool Endpoints  
- `GET /api/pools` - Get DeFi pools with filtering and pagination
- `GET /api/pools/:id` - Get detailed pool information

## 🛡️ Error Handling

### Circuit Breaker States
1. **Closed**: Normal operation with OpenAI API
2. **Open**: Fallback responses after 3 failures  
3. **Half-Open**: Testing recovery after 5-minute timeout

### Fallback Responses
- **Bitcoin Analysis**: Price prediction warnings and investment advice
- **DeFi Safety**: Risk assessment and protocol recommendations  
- **General**: Technical issue acknowledgment with available capabilities

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🏆 Production Status

✅ **Counter-Argument Engine**: Production ready with robust error handling  
✅ **Circuit Breaker System**: Prevents quota exhaustion  
✅ **Multi-language Support**: Vietnamese/English seamless switching  
✅ **DeFi Marketplace**: Real-time data from 384+ blockchains  
✅ **Performance**: Optimized response times (~1.7-2s)  

**Last Updated**: February 2025  
**Deployment Ready**: ✅ Yes