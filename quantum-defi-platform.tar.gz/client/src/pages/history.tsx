import { WalletProvider } from '@/hooks/use-wallet';
import Header from '@/components/layout/header';
import TransactionHistory from '@/components/transaction-history';

function HistoryContent() {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold mb-4 quantum-text-glow">
          Transaction <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-400">History</span>
        </h2>
        <p className="text-gray-300 text-lg mb-6 max-w-3xl mx-auto">
          Track all transactions executed through Quantum. 
          View detailed transaction info, MEV capture status and efficiency analysis.
        </p>
      </div>

      {/* Transaction History */}
      <TransactionHistory />
    </main>
  );
}

export default function HistoryPage() {
  return (
    <WalletProvider>
      <div className="min-h-screen bg-[var(--crypto-dark)] text-white">
        <Header />
        <HistoryContent />
      </div>
    </WalletProvider>
  );
}