import { WalletProvider } from '@/hooks/use-wallet';
import Header from '@/components/layout/header';
import QuantumVaultStats from '@/components/quantum-vault-stats';

function VaultContent() {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold mb-4 quantum-text-glow">
          Quantum <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-400">Vault</span>
        </h2>
        <p className="text-gray-300 text-lg mb-6 max-w-3xl mx-auto">
          Monitor performance and detailed analytics of Quantum Vault. 
          View real-time analysis of TVL, APY, MEV captured and other critical metrics.
        </p>
      </div>

      {/* Vault Stats */}
      <QuantumVaultStats />

      {/* Additional vault information */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="quantum-border rounded-xl p-6 quantum-glow-hover transition-all duration-300">
          <h3 className="text-lg font-semibold mb-2 text-gray-200">Strategy Allocation</h3>
          <p className="text-gray-400 text-sm">
            Strategy allocation will be displayed here after wallet connection and data availability.
          </p>
        </div>
        
        <div className="quantum-border rounded-xl p-6 quantum-glow-hover transition-all duration-300">
          <h3 className="text-lg font-semibold mb-2 text-gray-200">Risk Analytics</h3>
          <p className="text-gray-400 text-sm">
            Detailed risk analysis will be updated real-time from AI Brain.
          </p>
        </div>
        
        <div className="quantum-border rounded-xl p-6 quantum-glow-hover transition-all duration-300">
          <h3 className="text-lg font-semibold mb-2 text-gray-200">Performance Metrics</h3>
          <p className="text-gray-400 text-sm">
            Detailed performance indicators and market comparisons.
          </p>
        </div>
      </div>
    </main>
  );
}

export default function VaultPage() {
  return (
    <WalletProvider>
      <div className="min-h-screen bg-[var(--crypto-dark)] text-white">
        <Header />
        <VaultContent />
      </div>
    </WalletProvider>
  );
}