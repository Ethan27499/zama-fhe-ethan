import { ChatInterface } from '@/components/ChatInterface';
import { WalletProvider } from '@/hooks/use-wallet';
import Header from '@/components/layout/header';

export default function ChatPage() {
  return (
    <WalletProvider>
      <div className="min-h-screen bg-[var(--crypto-dark)] text-white relative overflow-hidden">
        <Header />
        
        {/* Quantum background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-black to-blue-900/10 -z-10"></div>
        <div className="absolute top-0 left-0 w-full h-full -z-10">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute top-3/4 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Chat Interface - Full Height */}
          <div className="h-[calc(100vh-120px)]">
            <ChatInterface className="h-full" />
          </div>
        </main>
      </div>
    </WalletProvider>
  );
}