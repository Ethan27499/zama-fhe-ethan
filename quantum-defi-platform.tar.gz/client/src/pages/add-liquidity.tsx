import { useRoute } from 'wouter';
import { useState } from 'react';
import { ArrowLeft, Plus, AlertTriangle, Info } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { usePools } from '@/hooks/use-pools';

export default function AddLiquidity() {
  const [, params] = useRoute('/add-liquidity/:poolId');
  const poolId = params?.poolId;
  
  const { data: allPools } = usePools({});
  const pool = allPools?.find(p => p.id === parseInt(poolId || '0'));
  
  const [amounts, setAmounts] = useState<{ [key: string]: string }>({});
  
  if (!pool) {
    return (
      <div className="min-h-screen bg-black text-white p-8">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">Pool Not Found</h2>
              <p className="text-gray-400 mb-4">The requested pool could not be found.</p>
              <Link href="/dashboard">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Back to Dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const tokens = Array.isArray(pool.tokens) ? pool.tokens : [];
  
  const handleAmountChange = (tokenSymbol: string, value: string) => {
    setAmounts(prev => ({ ...prev, [tokenSymbol]: value }));
  };

  const calculateEstimatedLP = () => {
    // Simple estimation based on first token amount
    const firstToken = tokens[0];
    if (!firstToken || !amounts[firstToken.symbol]) return '0';
    
    const amount = parseFloat(amounts[firstToken.symbol]);
    const tvl = parseFloat(pool.tvl || '0');
    
    if (tvl > 0) {
      return ((amount / tvl) * 1000000).toFixed(6); // Rough LP token estimation
    }
    return '0';
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Pools
            </Button>
          </Link>
        </div>

        {/* Pool Info */}
        <Card className="bg-gray-900 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <img 
                  src={pool.protocol?.logo || `https://via.placeholder.com/24x24/1f2937/ffffff?text=${pool.protocol?.name?.charAt(0) || 'P'}`}
                  alt={pool.protocol?.name || 'Protocol'}
                  className="w-6 h-6 rounded-full"
                  onError={(e) => {
                    e.currentTarget.src = `https://via.placeholder.com/24x24/1f2937/ffffff?text=${pool.protocol?.name?.charAt(0) || 'P'}`;
                  }}
                />
                <span className="text-lg">{pool.name}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <span>{pool.protocol?.name}</span>
                <span>•</span>
                <span>{pool.blockchain?.name}</span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-400">{pool.apy}%</div>
                <div className="text-sm text-gray-400">APY</div>
              </div>
              <div>
                <div className="text-2xl font-bold">${parseFloat(pool.tvl || '0').toLocaleString()}</div>
                <div className="text-sm text-gray-400">TVL</div>
              </div>
              <div>
                <div className="text-2xl font-bold">${parseFloat(pool.volume24h || '0').toLocaleString()}</div>
                <div className="text-sm text-gray-400">24h Volume</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Add Liquidity Form */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Add Liquidity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Token Inputs */}
            <div className="space-y-4">
              {tokens.map((token: any, index: number) => (
                <div key={index} className="space-y-2">
                  <Label className="text-gray-300">
                    {typeof token === 'object' ? token.symbol || token.name : token} Amount
                  </Label>
                  <div className="relative">
                    <Input
                      type="number"
                      placeholder="0.0"
                      value={amounts[typeof token === 'object' ? token.symbol : token] || ''}
                      onChange={(e) => handleAmountChange(
                        typeof token === 'object' ? token.symbol : token, 
                        e.target.value
                      )}
                      className="bg-gray-800 border-gray-600 text-white pr-20"
                    />
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-sm text-gray-400">
                      {typeof token === 'object' ? token.symbol || token.name : token}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Estimated LP Tokens */}
            <div className="bg-gray-800 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Info className="h-4 w-4 text-blue-400" />
                <span className="text-sm text-gray-300">Estimated LP Tokens</span>
              </div>
              <div className="text-lg font-semibold">
                {calculateEstimatedLP()} LP
              </div>
            </div>

            {/* Price Impact & Fees */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Price Impact</span>
                <span className="text-green-400">&lt; 0.01%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Liquidity Provider Fee</span>
                <span>0.3%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Minimum LP Tokens</span>
                <span>{(parseFloat(calculateEstimatedLP()) * 0.995).toFixed(6)} LP</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 py-3 text-lg">
                Connect Wallet to Add Liquidity
              </Button>
              <Button variant="outline" className="w-full border-gray-600 text-gray-300 hover:bg-gray-800">
                Preview Transaction
              </Button>
            </div>

            {/* Warning */}
            <div className="bg-yellow-900/20 border border-yellow-700 rounded-lg p-4">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5" />
                <div className="text-sm">
                  <div className="font-medium text-yellow-400 mb-1">Important</div>
                  <div className="text-gray-300">
                    Adding liquidity exposes you to impermanent loss. Make sure you understand the risks before proceeding.
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}