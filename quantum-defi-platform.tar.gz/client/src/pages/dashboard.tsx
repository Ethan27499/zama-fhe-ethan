import { WalletProvider } from '@/hooks/use-wallet';
import Header from '@/components/layout/header';
import PoolsDashboard from '@/components/pools-dashboard-new';

function DashboardContent() {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-8 relative">
        <h2 className="text-4xl font-bold mb-4 quantum-text-glow">
          DeFi <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">Pools</span> Explorer
        </h2>

      </div>

      {/* Pools Dashboard */}
      <PoolsDashboard />
    </main>
  );
}

export default function Dashboard() {
  return (
    <WalletProvider>
      <div className="min-h-screen bg-[var(--crypto-dark)] text-white">
        <Header />
        <DashboardContent />
      </div>
    </WalletProvider>
  );
}
