import { WalletProvider } from '@/hooks/use-wallet';
import Header from '@/components/layout/header';
import IntentChat from '@/components/intent-chat';

function IntentContent() {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold mb-4 quantum-text-glow">
          Chat with <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">Quantum AI</span>
        </h2>
        <p className="text-gray-300 text-lg mb-6 max-w-3xl mx-auto">
          Describe your DeFi goals in natural language. Our AI Brain will analyze 47 protocols across 8 chains 
          to find you the optimal strategy with MEV protection and maximum yield.
        </p>
      </div>

      {/* Chat Interface */}
      <IntentChat />
    </main>
  );
}

export default function IntentPage() {
  return (
    <WalletProvider>
      <div className="min-h-screen bg-[var(--crypto-dark)] text-white">
        <Header />
        <IntentContent />
      </div>
    </WalletProvider>
  );
}