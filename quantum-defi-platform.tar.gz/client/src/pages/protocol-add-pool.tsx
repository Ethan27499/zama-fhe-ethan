import { useRoute } from 'wouter';
import { useState } from 'react';
import { ArrowLeft, ExternalLink, Info, Plus, Shield } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useProtocols } from '@/hooks/use-pools';

export default function ProtocolAddPool() {
  const [, params] = useRoute('/protocol/:slug/add-pool');
  const protocolSlug = params?.slug;
  
  const { data: protocols } = useProtocols();
  const protocol = protocols?.find((p: any) => p.slug === protocolSlug);
  
  if (!protocol) {
    return (
      <div className="min-h-screen bg-black text-white p-8">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-8 text-center">
              <Shield className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">Protocol Not Found</h2>
              <p className="text-gray-400 mb-4">The requested protocol could not be found.</p>
              <Link href="/dashboard">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Back to Dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Protocol-specific external URLs and information
  const getProtocolInfo = () => {
    const slug = protocol.slug.toLowerCase();
    
    // Common DeFi protocol mappings
    const protocolMappings: { [key: string]: { 
      name: string; 
      addPoolUrl: string; 
      description: string;
      category: string;
    } } = {
      'uniswap-v3': {
        name: 'Uniswap V3',
        addPoolUrl: 'https://app.uniswap.org/#/add/v2',
        description: 'Add liquidity to Uniswap V3 pools for trading fees and rewards',
        category: 'DEX'
      },
      'uniswap-v2': {
        name: 'Uniswap V2', 
        addPoolUrl: 'https://app.uniswap.org/#/add/v2',
        description: 'Provide liquidity to Uniswap V2 trading pairs',
        category: 'DEX'
      },
      'curve': {
        name: 'Curve Finance',
        addPoolUrl: 'https://curve.fi/#/ethereum/pools',
        description: 'Add liquidity to Curve stable coin and crypto pools',
        category: 'DEX'
      },
      'aave': {
        name: 'AAVE',
        addPoolUrl: 'https://app.aave.com/supply',
        description: 'Supply assets to AAVE lending protocol for yield',
        category: 'Lending'
      },
      'compound': {
        name: 'Compound',
        addPoolUrl: 'https://app.compound.finance/',
        description: 'Supply assets to Compound money market',
        category: 'Lending'
      },
      'balancer': {
        name: 'Balancer',
        addPoolUrl: 'https://app.balancer.fi/#/ethereum/pool/add-liquidity',
        description: 'Add liquidity to Balancer weighted pools',
        category: 'DEX'
      },
      'sushiswap': {
        name: 'SushiSwap',
        addPoolUrl: 'https://app.sushi.com/add',
        description: 'Provide liquidity to SushiSwap pools',
        category: 'DEX'
      },
      'pancakeswap': {
        name: 'PancakeSwap',
        addPoolUrl: 'https://pancakeswap.finance/add',
        description: 'Add liquidity to PancakeSwap on BSC',
        category: 'DEX'
      },
      'convex-finance': {
        name: 'Convex Finance',
        addPoolUrl: 'https://www.convexfinance.com/stake',
        description: 'Stake in Convex for boosted CRV rewards',
        category: 'Yield'
      },
      'yearn-finance': {
        name: 'Yearn Finance',
        addPoolUrl: 'https://yearn.finance/#/vault',
        description: 'Deposit into Yearn vaults for optimized yield',
        category: 'Yield'
      }
    };

    return protocolMappings[slug] || {
      name: protocol.name,
      addPoolUrl: `https://www.google.com/search?q=${encodeURIComponent(protocol.name + ' add liquidity')}`,
      description: `Add liquidity to ${protocol.name} pools`,
      category: protocol.category || 'DeFi'
    };
  };

  const protocolInfo = getProtocolInfo();

  const handleRedirectToProtocol = () => {
    window.open(protocolInfo.addPoolUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Pools
            </Button>
          </Link>
        </div>

        {/* Protocol Header */}
        <Card className="bg-gray-900 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <img 
                  src={protocol.logo || `https://via.placeholder.com/48x48/1f2937/ffffff?text=${protocol.name?.charAt(0) || 'P'}`}
                  alt={protocol.name}
                  className="w-12 h-12 rounded-full border border-gray-600"
                  onError={(e) => {
                    e.currentTarget.src = `https://via.placeholder.com/48x48/1f2937/ffffff?text=${protocol.name?.charAt(0) || 'P'}`;
                  }}
                />
                <div>
                  <h1 className="text-2xl font-bold">{protocolInfo.name}</h1>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-blue-400 border-blue-400">
                      {protocolInfo.category}
                    </Badge>
                    {protocol.isVerified && (
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        <Shield className="h-3 w-3 mr-1" />
                        Verified
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-4">{protocolInfo.description}</p>
            
            {/* Protocol Stats */}
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-400">
                  ${parseFloat(protocol.tvl || '0').toLocaleString()}
                </div>
                <div className="text-sm text-gray-400">Total TVL</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-400">
                  {protocolInfo.category}
                </div>
                <div className="text-sm text-gray-400">Category</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-400">
                  {protocol.isVerified ? 'Verified' : 'Unverified'}
                </div>
                <div className="text-sm text-gray-400">Status</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Add Liquidity Action */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Add Liquidity to {protocolInfo.name}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Info Box */}
            <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-4">
              <div className="flex items-start gap-2">
                <Info className="h-4 w-4 text-blue-400 mt-0.5" />
                <div className="text-sm">
                  <div className="font-medium text-blue-400 mb-1">Direct Protocol Access</div>
                  <div className="text-gray-300">
                    You will be redirected to the official {protocolInfo.name} interface to add liquidity safely and directly.
                  </div>
                </div>
              </div>
            </div>

            {/* Features */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Why Add Liquidity Here?</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="text-green-400 font-semibold mb-2">Earn Trading Fees</div>
                  <div className="text-sm text-gray-300">
                    Collect fees from every trade that uses your liquidity
                  </div>
                </div>
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="text-blue-400 font-semibold mb-2">Liquidity Rewards</div>
                  <div className="text-sm text-gray-300">
                    Earn additional token rewards for providing liquidity
                  </div>
                </div>
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="text-purple-400 font-semibold mb-2">Compounding Yield</div>
                  <div className="text-sm text-gray-300">
                    Reinvest your earnings automatically for maximum returns
                  </div>
                </div>
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="text-yellow-400 font-semibold mb-2">Protocol Native</div>
                  <div className="text-sm text-gray-300">
                    Direct access to the official protocol interface
                  </div>
                </div>
              </div>
            </div>

            {/* Action Button */}
            <div className="space-y-3">
              <Button 
                onClick={handleRedirectToProtocol}
                className="w-full bg-blue-600 hover:bg-blue-700 py-6 text-lg flex items-center justify-center gap-2"
              >
                <ExternalLink className="h-5 w-5" />
                Open {protocolInfo.name} Add Liquidity
              </Button>
              
              <p className="text-center text-sm text-gray-400">
                This will open {protocolInfo.name}'s official interface in a new tab
              </p>
            </div>

            {/* Security Notice */}
            <div className="bg-yellow-900/20 border border-yellow-700 rounded-lg p-4">
              <div className="flex items-start gap-2">
                <Shield className="h-4 w-4 text-yellow-400 mt-0.5" />
                <div className="text-sm">
                  <div className="font-medium text-yellow-400 mb-1">Security Notice</div>
                  <div className="text-gray-300">
                    Always verify you're on the correct protocol website. Check the URL and ensure it matches the official domain before connecting your wallet.
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}