import { useState } from 'react';
import { WalletProvider } from '@/hooks/use-wallet';
import Header from '@/components/layout/header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Plus, 
  TrendingUp, 
  Shield, 
  Zap, 
  Users, 
  User, 
  Star,
  Lock,
  Unlock,
  Settings,
  BarChart3,
  DollarSign,
  Calendar,
  Target
} from 'lucide-react';

interface Vault {
  id: string;
  name: string;
  type: 'project' | 'user';
  creator?: string;
  description: string;
  apy: number;
  tvl: number;
  risk: 'Low' | 'Medium' | 'High';
  strategy: string;
  tokens: string[];
  isActive: boolean;
  minDeposit: number;
  lockPeriod?: string;
  createdAt: string;
}

const PROJECT_VAULTS: Vault[] = [
  {
    id: 'pv1',
    name: 'Quantum Yield Optimizer',
    type: 'project',
    description: 'AI-powered yield farming across multiple protocols with automatic rebalancing',
    apy: 15.8,
    tvl: 2400000,
    risk: 'Medium',
    strategy: 'Multi-protocol yield farming with MEV protection',
    tokens: ['ETH', 'USDC', 'DAI'],
    isActive: true,
    minDeposit: 100,
    lockPeriod: '30 days',
    createdAt: '2025-01-15'
  },
  {
    id: 'pv2',
    name: 'Stable Quantum Pool',
    type: 'project',
    description: 'Conservative strategy focusing on stable yields with low risk',
    apy: 8.2,
    tvl: 5600000,
    risk: 'Low',
    strategy: 'Stablecoin lending and LP strategies',
    tokens: ['USDC', 'USDT', 'DAI'],
    isActive: true,
    minDeposit: 50,
    createdAt: '2025-01-10'
  },
  {
    id: 'pv3',
    name: 'High Yield Quantum',
    type: 'project',
    description: 'Aggressive strategy targeting maximum returns with calculated risks',
    apy: 28.5,
    tvl: 890000,
    risk: 'High',
    strategy: 'Leveraged farming and arbitrage opportunities',
    tokens: ['ETH', 'BTC', 'MATIC'],
    isActive: true,
    minDeposit: 500,
    lockPeriod: '60 days',
    createdAt: '2025-01-20'
  }
];

const USER_VAULTS: Vault[] = [
  {
    id: 'uv1',
    name: 'My Conservative Strategy',
    type: 'user',
    creator: 'alice.eth',
    description: 'Personal vault focusing on USDC lending across Aave and Compound',
    apy: 6.5,
    tvl: 45000,
    risk: 'Low',
    strategy: 'USDC lending with auto-compound',
    tokens: ['USDC'],
    isActive: true,
    minDeposit: 10,
    createdAt: '2025-01-25'
  },
  {
    id: 'uv2',
    name: 'ETH Maximalist Vault',
    type: 'user',
    creator: 'bob.eth',
    description: 'ETH-only strategy with staking and DeFi yield',
    apy: 12.3,
    tvl: 120000,
    risk: 'Medium',
    strategy: 'ETH staking + Uniswap V3 LP',
    tokens: ['ETH'],
    isActive: true,
    minDeposit: 0.1,
    lockPeriod: '14 days',
    createdAt: '2025-01-22'
  }
];

function VaultCard({ vault }: { vault: Vault }) {
  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Low': return 'bg-green-500/20 text-green-400 border border-green-500/30';
      case 'Medium': return 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30';
      case 'High': return 'bg-red-500/20 text-red-400 border border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border border-gray-500/30';
    }
  };

  const formatCurrency = (value: number): string => {
    if (value >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
    if (value >= 1e3) return `$${(value / 1e3).toFixed(1)}K`;
    return `$${value.toFixed(2)}`;
  };

  return (
    <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)] hover:border-blue-500/50 transition-all duration-300 group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <h3 className="font-semibold text-lg group-hover:text-blue-400 transition-colors">
                {vault.name}
              </h3>
              {vault.type === 'project' ? (
                <Badge className="bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  <Zap className="h-3 w-3 mr-1" />
                  Project
                </Badge>
              ) : (
                <Badge className="bg-purple-500/20 text-purple-400 border border-purple-500/30">
                  <User className="h-3 w-3 mr-1" />
                  User
                </Badge>
              )}
            </div>
            {vault.creator && (
              <p className="text-xs text-gray-400 mb-2">Created by {vault.creator}</p>
            )}
            <p className="text-gray-300 text-sm mb-3">{vault.description}</p>
            <div className="flex items-center space-x-2 mb-2">
              <Badge className={getRiskColor(vault.risk)}>{vault.risk} Risk</Badge>
              {vault.lockPeriod && (
                <Badge variant="outline" className="text-xs">
                  <Lock className="h-3 w-3 mr-1" />
                  {vault.lockPeriod}
                </Badge>
              )}
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-xs text-gray-500 mb-1">APY</p>
            <p className="text-xl font-bold text-green-400">{vault.apy.toFixed(1)}%</p>
          </div>
          <div>
            <p className="text-xs text-gray-500 mb-1">TVL</p>
            <p className="text-xl font-bold text-blue-400">{formatCurrency(vault.tvl)}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500 mb-1">Min Deposit</p>
            <p className="text-sm font-medium text-gray-300">{formatCurrency(vault.minDeposit)}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500 mb-1">Strategy</p>
            <p className="text-sm font-medium text-gray-300 truncate" title={vault.strategy}>
              {vault.strategy}
            </p>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-xs text-gray-500 mb-2">Assets</p>
          <div className="flex flex-wrap gap-1">
            {vault.tokens.map((token, index) => (
              <Badge key={index} variant="secondary" className="text-xs bg-gray-700 text-gray-300">
                {token}
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex space-x-2">
          <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
            <DollarSign className="h-4 w-4 mr-2" />
            Deposit
          </Button>
          <Button variant="outline" size="sm">
            <BarChart3 className="h-4 w-4" />
          </Button>
          {vault.type === 'user' && (
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function CreateVaultCard() {
  return (
    <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)] border-dashed hover:border-blue-500/50 transition-all duration-300 group cursor-pointer">
      <CardContent className="p-8 text-center">
        <div className="mb-4">
          <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-500/30 transition-colors">
            <Plus className="h-8 w-8 text-blue-400" />
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">Create Your Vault</h3>
          <p className="text-gray-400 text-sm">
            Design custom yield strategies tailored to your risk tolerance and goals
          </p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 mr-2" />
          Create Vault
        </Button>
      </CardContent>
    </Card>
  );
}

function VaultContent() {
  const [activeTab, setActiveTab] = useState<'project' | 'user'>('project');

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold mb-4 quantum-text-glow">
          Quantum <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">Vaults</span>
        </h2>
        <p className="text-gray-300 text-lg mb-6 max-w-3xl mx-auto">
          Advanced yield strategies and automated portfolio management. Choose from our curated strategies or create your own.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-1">Total TVL</p>
                <p className="text-2xl font-bold text-blue-400">$9.1M</p>
              </div>
              <BarChart3 className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-1">Active Vaults</p>
                <p className="text-2xl font-bold text-green-400">5</p>
              </div>
              <Shield className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-1">Avg APY</p>
                <p className="text-2xl font-bold text-purple-400">14.3%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-1">Total Users</p>
                <p className="text-2xl font-bold text-cyan-400">1,247</p>
              </div>
              <Users className="h-8 w-8 text-cyan-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Vault Tabs */}
      <div className="flex space-x-1 mb-8 bg-gray-800/50 p-1 rounded-lg w-fit">
        <Button
          variant={activeTab === 'project' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('project')}
          className={`${activeTab === 'project' ? 'bg-blue-600' : 'text-gray-400 hover:text-white'}`}
        >
          <Zap className="h-4 w-4 mr-2" />
          Project Vaults
        </Button>
        <Button
          variant={activeTab === 'user' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('user')}
          className={`${activeTab === 'user' ? 'bg-purple-600' : 'text-gray-400 hover:text-white'}`}
        >
          <User className="h-4 w-4 mr-2" />
          User Vaults
        </Button>
      </div>

      {/* Vault Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeTab === 'project' ? (
          PROJECT_VAULTS.map((vault) => (
            <VaultCard key={vault.id} vault={vault} />
          ))
        ) : (
          <>
            {USER_VAULTS.map((vault) => (
              <VaultCard key={vault.id} vault={vault} />
            ))}
            <CreateVaultCard />
          </>
        )}
      </div>
    </main>
  );
}

export default function Vault() {
  return (
    <WalletProvider>
      <div className="min-h-screen bg-[var(--crypto-dark)] text-white">
        <Header />
        <VaultContent />
      </div>
    </WalletProvider>
  );
}