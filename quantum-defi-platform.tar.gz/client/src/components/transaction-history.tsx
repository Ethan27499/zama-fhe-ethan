import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useWallet } from '@/hooks/use-wallet';
import { SUPPORTED_NETWORKS } from '@/lib/web3';
import { History, RefreshCcw, ExternalLink, ArrowUp, ArrowDown, Clock, Zap } from 'lucide-react';
import type { Transaction } from '@shared/types';

export default function TransactionHistory() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { wallet } = useWallet();

  // Mock transaction data - in a real app, fetch from blockchain or indexer
  const mockTransactions: Transaction[] = [
    {
      hash: '0xabc123def456789',
      from: wallet?.address || '0x1234567890123456789012345678901234567890',
      to: '0x1234567890123456789012345678901234567678',
      value: '0.1',
      gasUsed: '21000',
      gasPrice: '20000000000',
      timestamp: Date.now() - 120000, // 2 minutes ago
      status: 'success',
      type: 'intent_execution',
      symbol: 'ETH',
    },
    {
      hash: '0xdef456abc789123',
      from: '0x9876543210987654321098765432109876543210',
      to: wallet?.address || '0x1234567890123456789012345678901234567890',
      value: '500',
      gasUsed: '65000',
      gasPrice: '25000000000',
      timestamp: Date.now() - 3600000, // 1 hour ago
      status: 'success',
      type: 'deposit',
      symbol: 'USDC',
    },
    {
      hash: '0x789123def456abc',
      from: wallet?.address || '0x1234567890123456789012345678901234567890',
      to: '0xabcdef1234567890abcdef1234567890abcdef12',
      value: '0',
      gasUsed: '45000',
      gasPrice: '18000000000',
      timestamp: Date.now() - 300000, // 5 minutes ago
      status: 'pending',
      type: 'rebalance',
    },
  ];

  const loadTransactions = async () => {
    if (!wallet?.isConnected) return;
    
    setIsLoading(true);
    try {
      // In a real app, you would fetch from an API or blockchain indexer
      // For now, we'll use mock data
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      setTransactions(mockTransactions);
    } catch (error) {
      console.error('Failed to load transactions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTransactions();
  }, [wallet?.address]);

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const formatTime = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  const getTransactionIcon = (transaction: Transaction) => {
    if (transaction.status === 'pending') {
      return <Clock className="h-4 w-4 text-yellow-400" />;
    }
    
    if (transaction.type === 'intent_execution') {
      return <ArrowUp className="h-4 w-4 text-purple-400" />;
    }
    
    if (transaction.type === 'deposit') {
      return <ArrowDown className="h-4 w-4 text-green-400" />;
    }
    
    if (transaction.type === 'mev_capture') {
      return <Zap className="h-4 w-4 text-yellow-400" />;
    }
    
    return <Clock className="h-4 w-4 text-blue-400" />;
  };

  const getTransactionTitle = (transaction: Transaction) => {
    if (transaction.type === 'intent_execution') return `Intent Execution`;
    if (transaction.type === 'deposit') return `Deposit ${transaction.symbol || 'ETH'}`;
    if (transaction.type === 'withdraw') return `Withdraw ${transaction.symbol || 'ETH'}`;
    if (transaction.type === 'rebalance') return `Auto Rebalance`;
    if (transaction.type === 'mev_capture') return `MEV Capture`;
    return 'Quantum Transaction';
  };

  const getTransactionSubtitle = (transaction: Transaction) => {
    if (transaction.type === 'intent_execution') return `AI Strategy Execution`;
    if (transaction.type === 'deposit') return `To Quantum Vault`;
    if (transaction.type === 'withdraw') return `From Quantum Vault`;
    if (transaction.type === 'rebalance') return `Portfolio optimization`;
    if (transaction.type === 'mev_capture') return `MEV Bot captured profit`;
    return 'Quantum operation';
  };

  const getTransactionAmount = (transaction: Transaction) => {
    if (transaction.type === 'rebalance') {
      const gasCost = (parseFloat(transaction.gasUsed) * parseFloat(transaction.gasPrice)) / 1e18;
      return `Gas: $${(gasCost * 2000).toFixed(2)}`; // Mock ETH price
    }
    
    if (transaction.type === 'mev_capture') {
      return `+$${transaction.value}`;
    }
    
    const prefix = transaction.type === 'intent_execution' ? '-' : '+';
    return `${prefix}${transaction.value} ${transaction.symbol || 'ETH'}`;
  };

  const getStatusBadge = (status: Transaction['status']) => {
    const variants = {
      success: 'bg-green-500/20 text-green-400 hover:bg-green-500/20',
      pending: 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/20',
      failed: 'bg-red-500/20 text-red-400 hover:bg-red-500/20',
    };

    return (
      <Badge className={variants[status]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const openTransaction = (hash: string) => {
    if (!wallet) return;
    
    const network = SUPPORTED_NETWORKS[wallet.chainId];
    if (network) {
      const url = `${network.blockExplorer}/tx/${hash}`;
      window.open(url, '_blank');
    }
  };

  if (!wallet?.isConnected) {
    return (
      <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
        <CardContent className="p-6 text-center">
          <History className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-400">Connect your wallet to view transaction history</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <History className="mr-2 h-5 w-5 text-green-400" />
            Transaction History
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={loadTransactions}
            disabled={isLoading}
            className="text-[var(--crypto-blue)] hover:text-blue-400"
          >
            <RefreshCcw className={`mr-1 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-[var(--crypto-light-gray)] rounded-lg p-4 animate-pulse">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-600 rounded-full"></div>
                    <div>
                      <div className="w-24 h-4 bg-gray-600 rounded mb-2"></div>
                      <div className="w-32 h-3 bg-gray-600 rounded"></div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="w-20 h-4 bg-gray-600 rounded mb-2"></div>
                    <div className="w-16 h-3 bg-gray-600 rounded"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : transactions.length === 0 ? (
          <div className="text-center py-8">
            <History className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-400">No transactions found</p>
          </div>
        ) : (
          <div className="space-y-3">
            {transactions.map((transaction) => (
              <div
                key={transaction.hash}
                className="bg-[var(--crypto-light-gray)] rounded-lg p-4 hover:bg-gray-600 transition-colors cursor-pointer"
                onClick={() => openTransaction(transaction.hash)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center">
                      {getTransactionIcon(transaction)}
                    </div>
                    <div>
                      <p className="font-medium">{getTransactionTitle(transaction)}</p>
                      <p className="text-sm text-gray-400">{getTransactionSubtitle(transaction)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{getTransactionAmount(transaction)}</p>
                    <p className="text-sm text-gray-400">{formatTime(transaction.timestamp)}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusBadge(transaction.status)}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 text-[var(--crypto-blue)] hover:text-blue-400"
                      onClick={(e) => {
                        e.stopPropagation();
                        openTransaction(transaction.hash);
                      }}
                    >
                      <ExternalLink className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
