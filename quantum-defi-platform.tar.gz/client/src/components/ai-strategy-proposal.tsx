import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Brain, CheckCircle, XCircle, TrendingUp, Shield, Zap, Clock, ExternalLink } from 'lucide-react';
import type { AIStrategy, MEVOpportunity } from '@shared/types';

interface AIStrategyProposalProps {
  strategy: AIStrategy;
  onApprove: (strategyId: string) => void;
  onReject: (strategyId: string) => void;
  isExecuting?: boolean;
}

export default function AIStrategyProposal({
  strategy,
  onApprove,
  onReject,
  isExecuting = false
}: AIStrategyProposalProps) {
  const [showDetails, setShowDetails] = useState(false);

  const getRiskColor = (score: number) => {
    if (score <= 3) return 'text-green-400 bg-green-500/20';
    if (score <= 6) return 'text-yellow-400 bg-yellow-500/20';
    return 'text-red-400 bg-red-500/20';
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 85) return 'text-green-400';
    if (confidence >= 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  const formatAPY = (apy: string) => {
    const value = parseFloat(apy);
    return value.toFixed(2);
  };

  const getChainIcon = (chain: string) => {
    const icons: Record<string, string> = {
      'Ethereum': '⟠',
      'Arbitrum': '🔵',
      'Polygon': '🟣',
      'Optimism': '🔴',
      'BSC': '🟡',
    };
    return icons[chain] || '⚪';
  };

  return (
    <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 via-transparent to-blue-500/5"></div>
      
      <CardHeader className="relative">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Brain className="mr-2 h-5 w-5 text-[var(--crypto-purple)] animate-pulse" />
            AI Strategy Proposal
          </div>
          <Badge className={`${getRiskColor(strategy.riskScore)}`}>
            Risk: {strategy.riskScore}/10
          </Badge>
        </CardTitle>
        <p className="text-gray-400 text-sm">
          AI Brain đã tìm ra chiến lược tối ưu cho Intent của bạn
        </p>
      </CardHeader>

      <CardContent className="space-y-6 relative">
        {/* Strategy Overview */}
        <div className="bg-[var(--crypto-light-gray)] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">{strategy.name}</h3>
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-green-400" />
              <span className="text-xl font-bold text-green-400">
                {formatAPY(strategy.expectedAPY)}% APY
              </span>
            </div>
          </div>
          
          <p className="text-gray-300 text-sm">{strategy.description}</p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-400">Confidence:</span>
              <span className={`text-sm font-bold ${getConfidenceColor(strategy.confidence)}`}>
                {strategy.confidence}%
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-gray-400" />
              <span className="text-sm text-gray-400">Est. Gas: {strategy.estimatedGas}</span>
            </div>
          </div>
        </div>

        {/* MEV Opportunity (if exists) */}
        {strategy.mevOpportunity && (
          <Card className="bg-purple-500/10 border-purple-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <Zap className="h-4 w-4 text-yellow-400 mr-2" />
                  <span className="text-sm font-medium text-purple-300">MEV Opportunity Detected</span>
                </div>
                <Badge className="bg-yellow-500/20 text-yellow-400">
                  +{strategy.mevOpportunity.estimatedProfit}
                </Badge>
              </div>
              <p className="text-xs text-purple-200">{strategy.mevOpportunity.description}</p>
              <div className="mt-2">
                <Progress value={strategy.mevOpportunity.confidence} className="h-2" />
                <p className="text-xs text-gray-400 mt-1">
                  MEV Confidence: {strategy.mevOpportunity.confidence}%
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Protocols & Chains */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm font-medium text-gray-300 mb-2">Protocols</h4>
            <div className="flex flex-wrap gap-1">
              {strategy.protocols.map((protocol) => (
                <Badge key={protocol} variant="outline" className="text-xs border-blue-500 text-blue-400">
                  {protocol}
                </Badge>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-300 mb-2">Chains</h4>
            <div className="flex flex-wrap gap-1">
              {strategy.chains.map((chain) => (
                <Badge key={chain} variant="outline" className="text-xs border-green-500 text-green-400">
                  {getChainIcon(chain)} {chain}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Strategy Steps */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-medium text-gray-300">Execution Steps</h4>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDetails(!showDetails)}
              className="text-[var(--crypto-blue)] hover:text-blue-400"
            >
              {showDetails ? 'Hide' : 'Show'} Details
            </Button>
          </div>
          
          {showDetails && (
            <div className="space-y-2">
              {strategy.steps.map((step, index) => (
                <div key={index} className="bg-[var(--crypto-light-gray)] rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-6 h-6 rounded-full bg-[var(--crypto-purple)] text-white text-xs flex items-center justify-center">
                        {index + 1}
                      </div>
                      <span className="text-sm font-medium capitalize">{step.action}</span>
                      <Badge variant="outline" className="text-xs">{step.protocol}</Badge>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{step.amount} {step.token}</p>
                      <p className="text-xs text-gray-400">on {step.chain}</p>
                    </div>
                  </div>
                  <p className="text-xs text-green-400 mt-1">
                    Expected: {step.estimatedReturn}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-3 pt-4 border-t border-gray-600">
          <Button
            onClick={() => onReject(strategy.id)}
            variant="outline"
            disabled={isExecuting}
            className="flex-1 border-red-500 text-red-400 hover:bg-red-500/10"
          >
            <XCircle className="mr-2 h-4 w-4" />
            Reject Strategy
          </Button>
          
          <Button
            onClick={() => onApprove(strategy.id)}
            disabled={isExecuting}
            className="flex-1 crypto-gradient crypto-gradient-hover text-white font-medium"
          >
            {isExecuting ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Executing...
              </div>
            ) : (
              <div className="flex items-center">
                <CheckCircle className="mr-2 h-4 w-4" />
                Execute Strategy
              </div>
            )}
          </Button>
        </div>

        {/* Risk Warning */}
        {strategy.riskScore > 6 && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
            <div className="flex items-center">
              <Shield className="h-4 w-4 text-red-400 mr-2" />
              <span className="text-sm font-medium text-red-300">High Risk Warning</span>
            </div>
            <p className="text-xs text-red-200 mt-1">
              Chiến lược này có mức rủi ro cao. Vui lòng cân nhắc kỹ trước khi thực hiện.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}