import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  Filter, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Zap, 
  Shield,
  ExternalLink,
  Star,
  StarOff
} from 'lucide-react';

interface DeFiPool {
  id: string;
  protocol: string;
  name: string;
  chain: string;
  apy: number;
  tvl: number;
  volume24h: number;
  risk: 'Low' | 'Medium' | 'High';
  category: 'Lending' | 'DEX' | 'Farming' | 'Staking' | 'Vault';
  tokens: string[];
  verified: boolean;
  trending?: boolean;
}

// Mock data for comprehensive DeFi pools across major protocols
const DEFI_POOLS: DeFiPool[] = [
  {
    id: '1',
    protocol: 'Aave',
    name: 'USDC Lending',
    chain: 'Ethereum',
    apy: 4.2,
    tvl: 1420000000,
    volume24h: 45000000,
    risk: 'Low',
    category: 'Lending',
    tokens: ['USDC'],
    verified: true,
    trending: true
  },
  {
    id: '2',
    protocol: 'Uniswap V3',
    name: 'ETH/USDC 0.05%',
    chain: 'Ethereum',
    apy: 18.7,
    tvl: 89000000,
    volume24h: 120000000,
    risk: 'Medium',
    category: 'DEX',
    tokens: ['ETH', 'USDC'],
    verified: true,
    trending: true
  },
  {
    id: '3',
    protocol: 'Compound',
    name: 'DAI Supply',
    chain: 'Ethereum',
    apy: 3.8,
    tvl: 340000000,
    volume24h: 12000000,
    risk: 'Low',
    category: 'Lending',
    tokens: ['DAI'],
    verified: true
  },
  {
    id: '4',
    protocol: 'Curve',
    name: '3Pool',
    chain: 'Ethereum',
    apy: 2.4,
    tvl: 2100000000,
    volume24h: 78000000,
    risk: 'Low',
    category: 'DEX',
    tokens: ['USDC', 'USDT', 'DAI'],
    verified: true
  },
  {
    id: '5',
    protocol: 'PancakeSwap',
    name: 'CAKE/BNB',
    chain: 'BSC',
    apy: 45.2,
    tvl: 156000000,
    volume24h: 23000000,
    risk: 'High',
    category: 'Farming',
    tokens: ['CAKE', 'BNB'],
    verified: true,
    trending: true
  },
  {
    id: '6',
    protocol: 'SushiSwap',
    name: 'WETH/USDT',
    chain: 'Polygon',
    apy: 12.8,
    tvl: 45000000,
    volume24h: 15000000,
    risk: 'Medium',
    category: 'DEX',
    tokens: ['WETH', 'USDT'],
    verified: true
  },
  {
    id: '7',
    protocol: 'Yearn',
    name: 'yvUSDC',
    chain: 'Ethereum',
    apy: 8.9,
    tvl: 234000000,
    volume24h: 5000000,
    risk: 'Medium',
    category: 'Vault',
    tokens: ['USDC'],
    verified: true
  },
  {
    id: '8',
    protocol: 'Lido',
    name: 'stETH',
    chain: 'Ethereum',
    apy: 5.1,
    tvl: 12400000000,
    volume24h: 89000000,
    risk: 'Low',
    category: 'Staking',
    tokens: ['ETH'],
    verified: true,
    trending: true
  },
  {
    id: '9',
    protocol: 'Convex',
    name: 'cvxCRV',
    chain: 'Ethereum',
    apy: 15.3,
    tvl: 567000000,
    volume24h: 12000000,
    risk: 'Medium',
    category: 'Farming',
    tokens: ['CRV', 'CVX'],
    verified: true
  },
  {
    id: '10',
    protocol: 'GMX',
    name: 'GLP',
    chain: 'Arbitrum',
    apy: 23.7,
    tvl: 456000000,
    volume24h: 34000000,
    risk: 'High',
    category: 'Vault',
    tokens: ['ETH', 'BTC', 'USDC'],
    verified: true,
    trending: true
  }
];

const CHAINS = ['All', 'Ethereum', 'Polygon', 'Arbitrum', 'Optimism', 'BSC'];
const CATEGORIES = ['All', 'Lending', 'DEX', 'Farming', 'Staking', 'Vault'];
const RISK_LEVELS = ['All', 'Low', 'Medium', 'High'];

export default function PoolsDashboard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChain, setSelectedChain] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedRisk, setSelectedRisk] = useState('All');
  const [sortBy, setSortBy] = useState<'apy' | 'tvl' | 'volume'>('tvl');
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  const filteredPools = useMemo(() => {
    return DEFI_POOLS
      .filter(pool => {
        const matchesSearch = pool.protocol.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            pool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            pool.tokens.some(token => token.toLowerCase().includes(searchTerm.toLowerCase()));
        const matchesChain = selectedChain === 'All' || pool.chain === selectedChain;
        const matchesCategory = selectedCategory === 'All' || pool.category === selectedCategory;
        const matchesRisk = selectedRisk === 'All' || pool.risk === selectedRisk;
        
        return matchesSearch && matchesChain && matchesCategory && matchesRisk;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'apy':
            return b.apy - a.apy;
          case 'tvl':
            return b.tvl - a.tvl;
          case 'volume':
            return b.volume24h - a.volume24h;
          default:
            return 0;
        }
      });
  }, [searchTerm, selectedChain, selectedCategory, selectedRisk, sortBy]);

  const toggleFavorite = (poolId: string) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(poolId)) {
      newFavorites.delete(poolId);
    } else {
      newFavorites.add(poolId);
    }
    setFavorites(newFavorites);
  };

  const formatNumber = (num: number) => {
    if (num >= 1e9) return `$${(num / 1e9).toFixed(1)}B`;
    if (num >= 1e6) return `$${(num / 1e6).toFixed(1)}M`;
    if (num >= 1e3) return `$${(num / 1e3).toFixed(1)}K`;
    return `$${num.toFixed(0)}`;
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Low': return 'text-green-400 border-green-500/50';
      case 'Medium': return 'text-yellow-400 border-yellow-500/50';
      case 'High': return 'text-red-400 border-red-500/50';
      default: return 'text-gray-400 border-gray-500/50';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Lending': return 'bg-blue-500/20 text-blue-400';
      case 'DEX': return 'bg-purple-500/20 text-purple-400';
      case 'Farming': return 'bg-green-500/20 text-green-400';
      case 'Staking': return 'bg-orange-500/20 text-orange-400';
      case 'Vault': return 'bg-cyan-500/20 text-cyan-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const totalTVL = DEFI_POOLS.reduce((sum, pool) => sum + pool.tvl, 0);
  const totalVolume = DEFI_POOLS.reduce((sum, pool) => sum + pool.volume24h, 0);
  const avgAPY = DEFI_POOLS.reduce((sum, pool) => sum + pool.apy, 0) / DEFI_POOLS.length;

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="quantum-border quantum-glow-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <DollarSign className="h-8 w-8 text-green-400" />
              <span className="text-2xl font-bold text-white">{formatNumber(totalTVL)}</span>
            </div>
            <h3 className="text-gray-300 font-medium">Total TVL</h3>
            <p className="text-gray-400 text-sm">Across all protocols</p>
          </CardContent>
        </Card>

        <Card className="quantum-border quantum-glow-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <TrendingUp className="h-8 w-8 text-blue-400" />
              <span className="text-2xl font-bold text-white">{avgAPY.toFixed(1)}%</span>
            </div>
            <h3 className="text-gray-300 font-medium">Average APY</h3>
            <p className="text-gray-400 text-sm">Weighted average</p>
          </CardContent>
        </Card>

        <Card className="quantum-border quantum-glow-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <Zap className="h-8 w-8 text-blue-300" />
              <span className="text-2xl font-bold text-white">{formatNumber(totalVolume)}</span>
            </div>
            <h3 className="text-gray-300 font-medium">24h Volume</h3>
            <p className="text-gray-400 text-sm">All protocols</p>
          </CardContent>
        </Card>

        <Card className="quantum-border quantum-glow-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <Shield className="h-8 w-8 text-cyan-400" />
              <span className="text-2xl font-bold text-white">{DEFI_POOLS.length}</span>
            </div>
            <h3 className="text-gray-300 font-medium">Active Pools</h3>
            <p className="text-gray-400 text-sm">Verified protocols</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="quantum-border quantum-glow">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center space-x-2 text-white">
            <Filter className="h-5 w-5 text-blue-400" />
            <span>Filters & Search</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-blue-400" />
            <Input
              placeholder="Search protocols, pools, or tokens..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-[var(--crypto-light-gray)] border-blue-500/30 focus:border-blue-400 text-white placeholder-gray-400 quantum-glow-hover"
            />
          </div>

          {/* Filter Groups */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
            {/* Chains */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-blue-400 flex items-center">
                <span className="w-2 h-2 bg-blue-400 rounded-full mr-2"></span>
                Chain
              </label>
              <div className="flex flex-wrap gap-2">
                {CHAINS.map(chain => (
                  <Button
                    key={chain}
                    size="sm"
                    variant={selectedChain === chain ? "default" : "outline"}
                    onClick={() => setSelectedChain(chain)}
                    className={`transition-all duration-200 ${
                      selectedChain === chain 
                        ? "crypto-gradient quantum-glow text-white" 
                        : "border-gray-600 text-gray-300 hover:border-blue-400 hover:text-blue-300"
                    }`}
                  >
                    {chain}
                  </Button>
                ))}
              </div>
            </div>

            {/* Categories */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-cyan-400 flex items-center">
                <span className="w-2 h-2 bg-cyan-400 rounded-full mr-2"></span>
                Category
              </label>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map(category => (
                  <Button
                    key={category}
                    size="sm"
                    variant={selectedCategory === category ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category)}
                    className={`transition-all duration-200 ${
                      selectedCategory === category 
                        ? "crypto-gradient quantum-glow text-white" 
                        : "border-gray-600 text-gray-300 hover:border-cyan-400 hover:text-cyan-300"
                    }`}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>

            {/* Risk Levels */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-green-400 flex items-center">
                <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                Risk Level
              </label>
              <div className="flex flex-wrap gap-2">
                {RISK_LEVELS.map(risk => (
                  <Button
                    key={risk}
                    size="sm"
                    variant={selectedRisk === risk ? "default" : "outline"}
                    onClick={() => setSelectedRisk(risk)}
                    className={`transition-all duration-200 ${
                      selectedRisk === risk 
                        ? "crypto-gradient quantum-glow text-white" 
                        : "border-gray-600 text-gray-300 hover:border-green-400 hover:text-green-300"
                    }`}
                  >
                    {risk}
                  </Button>
                ))}
              </div>
            </div>

            {/* Sort Options */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-blue-300 flex items-center">
                <span className="w-2 h-2 bg-blue-300 rounded-full mr-2"></span>
                Sort By
              </label>
              <div className="flex flex-wrap gap-2">
                {(['apy', 'tvl', 'volume'] as const).map(sort => (
                  <Button
                    key={sort}
                    size="sm"
                    variant={sortBy === sort ? "default" : "outline"}
                    onClick={() => setSortBy(sort)}
                    className={`transition-all duration-200 ${
                      sortBy === sort 
                        ? "crypto-gradient quantum-glow text-white" 
                        : "border-gray-600 text-gray-300 hover:border-blue-300 hover:text-blue-200"
                    }`}
                  >
                    {sort.toUpperCase()}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pools List - Horizontal Cards */}
      <div className="space-y-4">
        {filteredPools.map((pool) => (
          <Card key={pool.id} className="quantum-border quantum-glow-hover transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                {/* Left Section - Protocol Info */}
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 crypto-gradient rounded-xl flex items-center justify-center quantum-glow">
                    <span className="text-lg font-bold text-white">
                      {pool.protocol.slice(0, 2).toUpperCase()}
                    </span>
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <h3 className="font-semibold text-white text-lg">{pool.protocol}</h3>
                      {pool.verified && (
                        <Shield className="h-4 w-4 text-green-400" />
                      )}
                      {pool.trending && (
                        <TrendingUp className="h-4 w-4 text-yellow-400" />
                      )}
                    </div>
                    <p className="text-gray-400 mb-2">{pool.name}</p>
                    <div className="flex items-center space-x-3">
                      <Badge className={getCategoryColor(pool.category)}>
                        {pool.category}
                      </Badge>
                      <Badge variant="outline" className={getRiskColor(pool.risk)}>
                        {pool.risk} Risk
                      </Badge>
                      <div className="flex space-x-1">
                        {pool.tokens.map(token => (
                          <Badge key={token} variant="outline" className="text-xs border-gray-600">
                            {token}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Middle Section - Metrics */}
                <div className="hidden md:flex items-center space-x-8">
                  <div className="text-center">
                    <p className="text-gray-400 text-sm">APY</p>
                    <p className="font-bold text-green-400 text-xl">
                      {pool.apy.toFixed(1)}%
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-400 text-sm">TVL</p>
                    <p className="font-semibold text-white text-lg">
                      {formatNumber(pool.tvl)}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-400 text-sm">24h Volume</p>
                    <p className="font-semibold text-white text-lg">
                      {formatNumber(pool.volume24h)}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-400 text-sm">Chain</p>
                    <p className="font-semibold text-blue-400">
                      {pool.chain}
                    </p>
                  </div>
                </div>

                {/* Mobile Metrics */}
                <div className="md:hidden flex flex-col space-y-1 text-right">
                  <p className="font-bold text-green-400 text-xl">
                    {pool.apy.toFixed(1)}%
                  </p>
                  <p className="text-gray-400 text-sm">APY</p>
                  <p className="font-semibold text-white">
                    {formatNumber(pool.tvl)}
                  </p>
                  <p className="text-gray-400 text-xs">TVL</p>
                </div>

                {/* Right Section - Actions */}
                <div className="flex items-center space-x-3">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => toggleFavorite(pool.id)}
                    className="p-2 hover:bg-gray-700/50"
                  >
                    {favorites.has(pool.id) ? (
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    ) : (
                      <StarOff className="h-4 w-4 text-gray-400" />
                    )}
                  </Button>
                  <Button 
                    size="sm" 
                    className="crypto-gradient crypto-gradient-hover px-6"
                  >
                    Deposit
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="border-gray-600 hover:border-blue-400"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredPools.length === 0 && (
        <Card className="quantum-border">
          <CardContent className="p-12 text-center">
            <p className="text-gray-400 text-lg">No pools found matching your criteria</p>
            <p className="text-gray-500 text-sm mt-2">Try adjusting your filters or search terms</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}