import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useWallet } from '@/hooks/use-wallet';
import { SUPPORTED_NETWORKS } from '@/lib/web3';
import { Wallet, Copy, ExternalLink, RefreshCcw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function WalletConnect() {
  const { wallet, tokenBalances, isConnecting, connectWallet, disconnect, switchNetwork, refreshBalances } = useWallet();
  const { toast } = useToast();

  const handleCopyAddress = () => {
    if (wallet?.address) {
      navigator.clipboard.writeText(wallet.address);
      toast({
        title: "Address Copied",
        description: "Wallet address copied to clipboard",
      });
    }
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const formatBalance = (balance: string, decimals: number = 4) => {
    const num = parseFloat(balance);
    return num.toFixed(decimals);
  };

  const getTotalValue = () => {
    // Simple calculation - in a real app, you'd fetch USD prices
    const ethBalance = parseFloat(wallet?.balance || '0');
    const usdcBalance = tokenBalances.find(t => t.symbol === 'USDC')?.balance || '0';
    return (ethBalance * 2000 + parseFloat(usdcBalance)).toFixed(2); // Mock ETH price
  };

  if (!wallet?.isConnected) {
    return (
      <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 crypto-gradient rounded-full mx-auto mb-4 flex items-center justify-center">
            <Wallet className="h-8 w-8 text-white" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Connect Your Wallet</h3>
          <p className="text-gray-400 mb-6">Connect your Web3 wallet to access DeFi features and manage your assets</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={connectWallet} 
              disabled={isConnecting}
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              <Wallet className="mr-2 h-4 w-4" />
              {isConnecting ? 'Connecting...' : 'MetaMask'}
            </Button>
            <Button 
              onClick={connectWallet}
              disabled={isConnecting}
              className="bg-blue-500 hover:bg-blue-600 text-white"
            >
              <ExternalLink className="mr-2 h-4 w-4" />
              WalletConnect
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
      <CardContent className="p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <div>
            <h2 className="text-lg font-semibold mb-2">Connected Wallet</h2>
            <div className="flex items-center gap-2">
              <p className="text-gray-400 font-mono text-sm">{formatAddress(wallet.address)}</p>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCopyAddress}
                className="h-6 w-6 p-0"
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
          </div>
          <div className="mt-4 sm:mt-0 flex items-center gap-2">
            <Badge className="bg-green-500/20 text-green-400 hover:bg-green-500/20">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
              Connected
            </Badge>
            <Select value={wallet.chainId.toString()} onValueChange={(value) => switchNetwork(parseInt(value))}>
              <SelectTrigger className="w-40 bg-[var(--crypto-light-gray)] border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.values(SUPPORTED_NETWORKS).map((network) => (
                  <SelectItem key={network.chainId} value={network.chainId.toString()}>
                    {network.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="sm"
              onClick={refreshBalances}
            >
              <RefreshCcw className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={disconnect}
              className="text-red-400 hover:text-red-300"
            >
              Disconnect
            </Button>
          </div>
        </div>
        
        {/* Balance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">ETH Balance</p>
                  <p className="text-xl font-bold">{formatBalance(wallet.balance)} ETH</p>
                  <p className="text-gray-400 text-sm">${(parseFloat(wallet.balance) * 2000).toFixed(2)}</p>
                </div>
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-white">Ξ</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">USDC Balance</p>
                  <p className="text-xl font-bold">
                    {tokenBalances.find(t => t.symbol === 'USDC')?.balance 
                      ? formatBalance(tokenBalances.find(t => t.symbol === 'USDC')!.balance, 2)
                      : '0.00'}
                  </p>
                  <p className="text-gray-400 text-sm">
                    ${tokenBalances.find(t => t.symbol === 'USDC')?.balance 
                      ? formatBalance(tokenBalances.find(t => t.symbol === 'USDC')!.balance, 2)
                      : '0.00'}
                  </p>
                </div>
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-white">UC</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Total Value</p>
                  <p className="text-xl font-bold text-green-400">${getTotalValue()}</p>
                  <p className="text-green-400 text-sm">+2.4% (24h)</p>
                </div>
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-white">$</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  );
}
