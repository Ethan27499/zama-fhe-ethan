import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, ExternalLink, CheckCircle, XCircle } from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactionHash?: string;
  title?: string;
  description?: string;
}

export default function TransactionModal({
  isOpen,
  onClose,
  transactionHash,
  title = "Processing Transaction",
  description = "Please confirm the transaction in your wallet..."
}: TransactionModalProps) {
  const [status, setStatus] = useState<'pending' | 'success' | 'failed'>('pending');
  const [confirmations, setConfirmations] = useState(0);

  useEffect(() => {
    if (transactionHash && isOpen) {
      // Mock transaction status checking
      const checkStatus = () => {
        // Simulate random success/failure after some time
        setTimeout(() => {
          const isSuccess = Math.random() > 0.2; // 80% success rate
          setStatus(isSuccess ? 'success' : 'failed');
          if (isSuccess) {
            // Simulate confirmations
            let conf = 0;
            const interval = setInterval(() => {
              conf++;
              setConfirmations(conf);
              if (conf >= 12) {
                clearInterval(interval);
              }
            }, 2000);
          }
        }, 5000);
      };
      
      checkStatus();
    }
  }, [transactionHash, isOpen]);

  const getStatusIcon = () => {
    switch (status) {
      case 'pending':
        return <Loader2 className="h-8 w-8 animate-spin text-[var(--crypto-blue)]" />;
      case 'success':
        return <CheckCircle className="h-8 w-8 text-green-400" />;
      case 'failed':
        return <XCircle className="h-8 w-8 text-red-400" />;
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'pending':
        return 'Transaction Pending';
      case 'success':
        return 'Transaction Successful';
      case 'failed':
        return 'Transaction Failed';
    }
  };

  const getStatusDescription = () => {
    switch (status) {
      case 'pending':
        return description;
      case 'success':
        return `Your transaction has been confirmed with ${confirmations} confirmations.`;
      case 'failed':
        return 'The transaction has failed. Please try again.';
    }
  };

  const getStatusBadge = () => {
    const variants = {
      pending: 'bg-yellow-500/20 text-yellow-400',
      success: 'bg-green-500/20 text-green-400',
      failed: 'bg-red-500/20 text-red-400',
    };

    return (
      <Badge className={variants[status]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const openInExplorer = () => {
    if (transactionHash) {
      // In a real app, this would use the correct explorer URL for the current network
      const explorerUrl = `https://etherscan.io/tx/${transactionHash}`;
      window.open(explorerUrl, '_blank');
    }
  };

  const handleClose = () => {
    setStatus('pending');
    setConfirmations(0);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)] max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        
        <div className="text-center py-6">
          <div className="w-16 h-16 crypto-gradient rounded-full mx-auto mb-4 flex items-center justify-center">
            {getStatusIcon()}
          </div>
          
          <h3 className="text-lg font-semibold mb-2">{getStatusText()}</h3>
          <p className="text-gray-400 mb-4">{getStatusDescription()}</p>
          
          {transactionHash && (
            <Card className="bg-[var(--crypto-light-gray)] border-gray-600 mb-4">
              <CardContent className="p-3 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Transaction Hash:</span>
                  <span className="font-mono text-xs">
                    {transactionHash.slice(0, 10)}...{transactionHash.slice(-8)}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Status:</span>
                  {getStatusBadge()}
                </div>
                {status === 'success' && confirmations > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Confirmations:</span>
                    <span className="text-green-400">{confirmations}/12</span>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
          
          <div className="flex gap-2">
            {transactionHash && (
              <Button
                variant="outline"
                onClick={openInExplorer}
                className="flex-1 border-gray-600 hover:bg-[var(--crypto-light-gray)]"
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                View on Explorer
              </Button>
            )}
            <Button
              onClick={handleClose}
              className="flex-1 bg-gray-600 hover:bg-gray-700"
            >
              {status === 'pending' ? 'Close' : 'Done'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
