import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useWallet } from '@/hooks/use-wallet';
import { web3Service, COMMON_TOKENS } from '@/lib/web3';
import { useToast } from '@/hooks/use-toast';
import { Send } from 'lucide-react';

export default function TokenTransfer() {
  const [selectedToken, setSelectedToken] = useState('ETH');
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [isSending, setIsSending] = useState(false);
  
  const { wallet, tokenBalances } = useWallet();
  const { toast } = useToast();

  const getAvailableTokens = () => {
    const tokens = [{ symbol: 'ETH', balance: wallet?.balance || '0', decimals: 18 }];
    tokenBalances.forEach(token => {
      tokens.push({
        symbol: token.symbol,
        balance: token.balance,
        decimals: token.decimals,
      });
    });
    return tokens;
  };

  const getTokenBalance = (symbol: string) => {
    if (symbol === 'ETH') return wallet?.balance || '0';
    const token = tokenBalances.find(t => t.symbol === symbol);
    return token?.balance || '0';
  };

  const setMaxAmount = () => {
    const balance = getTokenBalance(selectedToken);
    if (selectedToken === 'ETH') {
      // Leave some ETH for gas fees
      const maxAmount = Math.max(0, parseFloat(balance) - 0.01);
      setAmount(maxAmount.toString());
    } else {
      setAmount(balance);
    }
  };

  const estimateGasFee = () => {
    // Simple gas estimation - in a real app, you'd call estimateGas
    return selectedToken === 'ETH' ? '$3.50' : '$5.20';
  };

  const sendTokens = async () => {
    if (!wallet?.isConnected) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet first",
        variant: "destructive",
      });
      return;
    }

    if (!recipient || !amount) {
      toast({
        title: "Missing Information",
        description: "Please provide recipient address and amount",
        variant: "destructive",
      });
      return;
    }

    if (!/^0x[a-fA-F0-9]{40}$/.test(recipient)) {
      toast({
        title: "Invalid Address",
        description: "Please enter a valid Ethereum address",
        variant: "destructive",
      });
      return;
    }

    const balance = parseFloat(getTokenBalance(selectedToken));
    const sendAmount = parseFloat(amount);

    if (sendAmount <= 0 || sendAmount > balance) {
      toast({
        title: "Invalid Amount",
        description: "Amount must be greater than 0 and not exceed balance",
        variant: "destructive",
      });
      return;
    }

    setIsSending(true);

    try {
      let txHash: string;

      if (selectedToken === 'ETH') {
        txHash = await web3Service.sendTransaction(recipient, amount);
      } else {
        const token = tokenBalances.find(t => t.symbol === selectedToken);
        const tokenAddresses = COMMON_TOKENS[wallet.chainId] || [];
        const tokenAddress = tokenAddresses.find(t => t.symbol === selectedToken)?.address;
        
        if (!tokenAddress || !token) {
          throw new Error(`Token address not found for ${selectedToken}`);
        }

        txHash = await web3Service.sendTokens(tokenAddress, recipient, amount, token.decimals);
      }

      toast({
        title: "Transaction Submitted",
        description: `Transaction hash: ${txHash.slice(0, 10)}...`,
      });

      // Clear form
      setRecipient('');
      setAmount('');
      
      // Refresh balances after a delay
      setTimeout(() => {
        // This would trigger a balance refresh in a real implementation
      }, 5000);

    } catch (error) {
      console.error('Send tokens error:', error);
      toast({
        title: "Transaction Failed",
        description: error instanceof Error ? error.message : "Failed to send tokens",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Send className="mr-2 h-5 w-5 text-[var(--crypto-blue)]" />
          Send Tokens
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="token-select" className="text-sm font-medium text-gray-300">
            Token
          </Label>
          <Select value={selectedToken} onValueChange={setSelectedToken}>
            <SelectTrigger className="bg-[var(--crypto-light-gray)] border-gray-600 focus:ring-[var(--crypto-blue)]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {getAvailableTokens().map((token) => (
                <SelectItem key={token.symbol} value={token.symbol}>
                  {token.symbol} (Balance: {parseFloat(token.balance).toFixed(4)})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="recipient" className="text-sm font-medium text-gray-300">
            Recipient Address
          </Label>
          <Input
            id="recipient"
            placeholder="0x..."
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            className="bg-[var(--crypto-light-gray)] border-gray-600 focus:ring-[var(--crypto-blue)]"
          />
        </div>
        
        <div>
          <Label htmlFor="amount" className="text-sm font-medium text-gray-300">
            Amount
          </Label>
          <div className="relative">
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-[var(--crypto-light-gray)] border-gray-600 pr-16 focus:ring-[var(--crypto-blue)]"
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={setMaxAmount}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-[var(--crypto-blue)] text-sm font-medium h-auto p-1"
            >
              MAX
            </Button>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Available: {parseFloat(getTokenBalance(selectedToken)).toFixed(4)} {selectedToken}
          </p>
        </div>
        
        <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
          <CardContent className="p-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Gas Fee:</span>
              <span>{estimateGasFee()}</span>
            </div>
          </CardContent>
        </Card>
        
        <Button
          onClick={sendTokens}
          disabled={isSending || !wallet?.isConnected}
          className="w-full bg-gradient-to-r from-[var(--crypto-blue)] to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-medium transition-all duration-200"
        >
          {isSending ? 'Sending...' : 'Send Tokens'}
        </Button>
      </CardContent>
    </Card>
  );
}
