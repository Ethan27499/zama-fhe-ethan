import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Brain, Clock, CheckCircle, XCircle, Activity, TrendingUp, RefreshCw } from 'lucide-react';
import type { Intent, AIStrategy } from '@shared/types';
import AIStrategyProposal from './ai-strategy-proposal';

export default function IntentDashboard() {
  const [intents, setIntents] = useState<Intent[]>([]);
  const [strategies, setStrategies] = useState<AIStrategy[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Mock data for demonstration
  const mockIntents: Intent[] = [
    {
      id: 'intent_1',
      type: 'maximize_yield',
      description: 'Tối đa hóa lợi nhuận cho 10,000 USDC của tôi',
      amount: '10000',
      token: 'USDC',
      riskLevel: 'medium',
      status: 'proposal_ready',
      timestamp: Date.now() - 300000, // 5 minutes ago
    },
    {
      id: 'intent_2',
      type: 'safe_farming',
      description: 'Tìm cơ hội farm an toàn cho 2 ETH',
      amount: '2',
      token: 'ETH',
      riskLevel: 'low',
      status: 'active',
      timestamp: Date.now() - 3600000, // 1 hour ago
    },
    {
      id: 'intent_3',
      type: 'arbitrage',
      description: 'Tìm kiếm cơ hội arbitrage với 5000 USDT',
      amount: '5000',
      token: 'USDT',
      riskLevel: 'high',
      status: 'analyzing',
      timestamp: Date.now() - 120000, // 2 minutes ago
    },
  ];

  const mockStrategies: AIStrategy[] = [
    {
      id: 'strategy_1',
      intentId: 'intent_1',
      name: 'Multi-Chain Yield Optimization',
      description: 'Tối ưu hóa lợi nhuận qua Aave (Arbitrum), Compound (Ethereum), và QuickSwap (Polygon)',
      expectedAPY: '14.25',
      riskScore: 4,
      protocols: ['Aave', 'Compound', 'QuickSwap'],
      chains: ['Arbitrum', 'Ethereum', 'Polygon'],
      steps: [
        {
          action: 'bridge',
          protocol: 'Arbitrum Bridge',
          chain: 'Arbitrum',
          amount: '6000',
          token: 'USDC',
          estimatedReturn: '6000 USDC',
        },
        {
          action: 'deposit',
          protocol: 'Aave V3',
          chain: 'Arbitrum',
          amount: '6000',
          token: 'USDC',
          estimatedReturn: '12.8% APY',
        },
        {
          action: 'farm',
          protocol: 'QuickSwap',
          chain: 'Polygon',
          amount: '4000',
          token: 'USDC',
          estimatedReturn: '16.2% APY',
        },
      ],
      mevOpportunity: {
        type: 'arbitrage',
        estimatedProfit: '$127',
        confidence: 78,
        description: 'Phát hiện chênh lệch giá USDC giữa Arbitrum và Polygon',
      },
      confidence: 89,
      estimatedGas: '$23.50',
    },
  ];

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      // Simulate API calls
      await new Promise(resolve => setTimeout(resolve, 1500));
      setIntents(mockIntents);
      setStrategies(mockStrategies);
      setIsLoading(false);
    };

    loadData();
  }, []);

  const getStatusIcon = (status: Intent['status']) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4 text-gray-400" />;
      case 'analyzing':
        return <Brain className="h-4 w-4 text-[var(--crypto-purple)] animate-pulse" />;
      case 'proposal_ready':
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'executing':
        return <Activity className="h-4 w-4 text-yellow-400 animate-spin" />;
      case 'active':
        return <TrendingUp className="h-4 w-4 text-green-400" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-blue-400" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-400" />;
      default:
        return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: Intent['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-gray-500/20 text-gray-400';
      case 'analyzing':
        return 'bg-purple-500/20 text-purple-400';
      case 'proposal_ready':
        return 'bg-green-500/20 text-green-400';
      case 'executing':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'active':
        return 'bg-green-500/20 text-green-400';
      case 'completed':
        return 'bg-blue-500/20 text-blue-400';
      case 'failed':
        return 'bg-red-500/20 text-red-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusText = (status: Intent['status']) => {
    const statusMap = {
      pending: 'Chờ xử lý',
      analyzing: 'AI đang phân tích',
      proposal_ready: 'Đề xuất sẵn sàng',
      executing: 'Đang thực hiện',
      active: 'Đang hoạt động',
      completed: 'Hoàn thành',
      failed: 'Thất bại',
    };
    return statusMap[status];
  };

  const formatTime = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  const handleApproveStrategy = async (strategyId: string) => {
    // Update intent status to executing
    setIntents(prev => prev.map(intent => {
      const strategy = strategies.find(s => s.id === strategyId);
      if (strategy && intent.id === strategy.intentId) {
        return { ...intent, status: 'executing' };
      }
      return intent;
    }));

    // Simulate execution
    setTimeout(() => {
      setIntents(prev => prev.map(intent => {
        const strategy = strategies.find(s => s.id === strategyId);
        if (strategy && intent.id === strategy.intentId) {
          return { ...intent, status: 'active' };
        }
        return intent;
      }));
    }, 3000);
  };

  const handleRejectStrategy = (strategyId: string) => {
    setIntents(prev => prev.map(intent => {
      const strategy = strategies.find(s => s.id === strategyId);
      if (strategy && intent.id === strategy.intentId) {
        return { ...intent, status: 'pending' };
      }
      return intent;
    }));
  };

  if (isLoading) {
    return (
      <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="mr-2 h-5 w-5 text-[var(--crypto-blue)]" />
            Intent Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-[var(--crypto-light-gray)] rounded-lg p-4 animate-pulse">
                <div className="flex items-center justify-between">
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-600 rounded w-48"></div>
                    <div className="h-3 bg-gray-600 rounded w-32"></div>
                  </div>
                  <div className="h-6 bg-gray-600 rounded w-20"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Intent List */}
      <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Activity className="mr-2 h-5 w-5 text-[var(--crypto-blue)]" />
              Intent Dashboard
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.location.reload()}
              className="text-[var(--crypto-blue)] hover:text-blue-400"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-gray-400 text-sm">
            Theo dõi trạng thái và kết quả của các Intent đã gửi
          </p>
        </CardHeader>
        
        <CardContent>
          {intents.length === 0 ? (
            <div className="text-center py-8">
              <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">Chưa có Intent nào được tạo</p>
            </div>
          ) : (
            <div className="space-y-4">
              {intents.map((intent) => (
                <div
                  key={intent.id}
                  className="bg-[var(--crypto-light-gray)] rounded-lg p-4 hover:bg-gray-600 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(intent.status)}
                      <div>
                        <p className="font-medium">{intent.description}</p>
                        <p className="text-sm text-gray-400">
                          {intent.amount} {intent.token} • Risk: {intent.riskLevel} • {formatTime(intent.timestamp)}
                        </p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(intent.status)}>
                      {getStatusText(intent.status)}
                    </Badge>
                  </div>
                  
                  {intent.status === 'analyzing' && (
                    <div className="mt-3">
                      <Progress value={65} className="h-2" />
                      <p className="text-xs text-purple-400 mt-1">
                        AI Brain đang phân tích 47 protocol trên 8 chain...
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Strategy Proposals */}
      {strategies.map((strategy) => {
        const relatedIntent = intents.find(intent => intent.id === strategy.intentId);
        if (!relatedIntent || relatedIntent.status !== 'proposal_ready') return null;
        
        const isExecuting = false; // Will be set dynamically based on intent status
        
        return (
          <AIStrategyProposal
            key={strategy.id}
            strategy={strategy}
            onApprove={handleApproveStrategy}
            onReject={handleRejectStrategy}
            isExecuting={isExecuting}
          />
        );
      })}
    </div>
  );
}