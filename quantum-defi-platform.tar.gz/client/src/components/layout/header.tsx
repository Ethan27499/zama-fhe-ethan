import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useWallet } from '@/hooks/use-wallet';
import { SUPPORTED_NETWORKS } from '@/lib/web3';
import { useLocation, Link } from 'wouter';
import { 
  Wallet, 
  Atom, 
  Brain, 
  Sparkles, 
  Globe, 
  Shield, 
  Target, 
  Database, 
  Activity, 
  History 
} from 'lucide-react';

const navigationItems = [
  {
    path: '/',
    label: 'Dashboard',
    icon: Activity,
    description: 'Overview and general statistics'
  },
  {
    path: '/chat',
    label: 'Intent Chat',
    icon: Brain,
    description: 'AI-powered DeFi conversations with Counter-Argument Engine'
  },
  {
    path: '/vault',
    label: 'Quantum Vault',
    icon: Database,
    description: 'Vault analytics and insights'
  },
  {
    path: '/history',
    label: 'History',
    icon: History,
    description: 'Transaction history'
  }
];

export default function Header() {
  const { wallet, connectWallet, isConnecting, switchNetwork } = useWallet();
  const [location] = useLocation();

  return (
    <header className="bg-[var(--crypto-gray)] border-b border-[var(--crypto-light-gray)] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 via-transparent to-cyan-500/10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Single Header Bar */}
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            {/* Logo */}
            <Link href="/">
              <div className="flex items-center space-x-3 cursor-pointer hover:opacity-80 transition-opacity">
                <div className="w-10 h-10 crypto-gradient rounded-xl flex items-center justify-center relative">
                  <Atom className="h-6 w-6 text-white animate-pulse" />
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-xl opacity-30 animate-ping"></div>
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                    Quantum
                  </h1>
                  <p className="text-xs text-gray-400 -mt-1">Intent-Driven DeFi Protocol</p>
                </div>
              </div>
            </Link>
            


            {/* Navigation */}
            <nav className="hidden lg:flex items-center space-x-1">
              {navigationItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = location === item.path;
                
                return (
                  <Link key={item.path} href={item.path}>
                    <div
                      className={`
                        relative px-4 py-2 rounded-lg transition-all duration-200 cursor-pointer group
                        ${isActive 
                          ? 'bg-gradient-to-r from-blue-600/20 to-cyan-500/20 text-white' 
                          : 'hover:bg-gray-700/50 text-gray-300 hover:text-white'
                        }
                      `}
                    >
                      <div className="flex items-center space-x-2">
                        <IconComponent className={`h-4 w-4 ${isActive ? 'text-blue-400' : ''}`} />
                        <span className="font-medium">{item.label}</span>
                      </div>
                      
                      {/* Active indicator */}
                      {isActive && (
                        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-8 h-0.5 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full"></div>
                      )}
                      
                      {/* Hover tooltip */}
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-3 py-1 bg-gray-800 text-xs text-gray-300 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
                        {item.description}
                      </div>
                    </div>
                  </Link>
                );
              })}
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Network Selector - Only show when connected */}

            
            {/* Wallet Connection Button */}
            <Button 
              onClick={connectWallet} 
              disabled={isConnecting}
              className="crypto-gradient crypto-gradient-hover text-white font-medium transition-all duration-200"
            >
              {isConnecting ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Connecting...
                </div>
              ) : wallet?.isConnected ? (
                <div className="flex items-center">
                  <Wallet className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">{`${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`}</span>
                  <span className="sm:hidden">Connected</span>
                </div>
              ) : (
                <div className="flex items-center">
                  <Wallet className="mr-2 h-4 w-4" />
                  <span>Connect</span>
                </div>
              )}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}