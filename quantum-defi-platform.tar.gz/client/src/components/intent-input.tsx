import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useWallet } from '@/hooks/use-wallet';
import { useToast } from '@/hooks/use-toast';
import { Brain, Target, Zap, TrendingUp, Shield, Sparkles } from 'lucide-react';
import type { Intent } from '@shared/types';

export default function IntentInput() {
  const [intentType, setIntentType] = useState<Intent['type']>('maximize_yield');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [token, setToken] = useState('USDC');
  const [riskLevel, setRiskLevel] = useState<Intent['riskLevel']>('medium');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { wallet, tokenBalances } = useWallet();
  const { toast } = useToast();

  const intentTemplates = {
    maximize_yield: {
      title: 'Maximize Returns',
      icon: TrendingUp,
      description: 'Find the highest yield opportunities across all chains',
      placeholder: 'Tối đa hóa lợi nhuận cho 10,000 USDC của tôi',
      color: 'text-green-400',
      bgColor: 'bg-green-500/20',
    },
    safe_farming: {
      title: 'Safe Farming',
      icon: Shield,
      description: 'Focus on low-risk, stable yield farming strategies',
      placeholder: 'Tìm cơ hội farm an toàn nhất cho 5 ETH',
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20',
    },
    arbitrage: {
      title: 'MEV Capture',
      icon: Zap,
      description: 'Hunt for arbitrage and MEV opportunities',
      placeholder: 'Tìm kiếm cơ hội arbitrage với 1000 USDT',
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20',
    },
    custom: {
      title: 'Custom Strategy',
      icon: Target,
      description: 'Describe your specific investment goals',
      placeholder: 'Mô tả mục tiêu đầu tư cụ thể của bạn...',
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/20',
    },
  };

  const riskLevels = {
    low: { label: 'Thấp', color: 'bg-green-500/20 text-green-400', description: 'APY 3-8%, rủi ro tối thiểu' },
    medium: { label: 'Trung bình', color: 'bg-yellow-500/20 text-yellow-400', description: 'APY 8-15%, cân bằng risk/reward' },
    high: { label: 'Cao', color: 'bg-red-500/20 text-red-400', description: 'APY 15%+, chấp nhận rủi ro cao' },
  };

  const getAvailableTokens = () => {
    const tokens = [
      { symbol: 'USDC', balance: tokenBalances.find(t => t.symbol === 'USDC')?.balance || '0' },
      { symbol: 'USDT', balance: tokenBalances.find(t => t.symbol === 'USDT')?.balance || '0' },
      { symbol: 'ETH', balance: wallet?.balance || '0' },
      { symbol: 'DAI', balance: tokenBalances.find(t => t.symbol === 'DAI')?.balance || '0' },
    ];
    return tokens.filter(t => parseFloat(t.balance) > 0);
  };

  const handleSubmitIntent = async () => {
    if (!wallet?.isConnected) {
      toast({
        title: "Wallet Not Connected",
        description: "Vui lòng kết nối ví trước khi tạo Intent",
        variant: "destructive",
      });
      return;
    }

    if (!description || !amount || !token) {
      toast({
        title: "Thiếu thông tin",
        description: "Vui lòng điền đầy đủ thông tin Intent",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate intent submission to AI Brain
      const newIntent: Intent = {
        id: `intent_${Date.now()}`,
        type: intentType,
        description,
        amount,
        token,
        riskLevel,
        status: 'analyzing',
        timestamp: Date.now(),
      };

      // Mock API call to submit intent
      await new Promise(resolve => setTimeout(resolve, 2000));

      toast({
        title: "Intent Submitted",
        description: "AI Brain đang phân tích yêu cầu của bạn...",
      });

      // Clear form
      setDescription('');
      setAmount('');
      
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "Không thể gửi Intent. Vui lòng thử lại.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedTemplate = intentTemplates[intentType];
  const IconComponent = selectedTemplate.icon;

  return (
    <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-transparent to-blue-500/5"></div>
      <CardHeader className="relative">
        <CardTitle className="flex items-center text-xl">
          <Brain className="mr-3 h-6 w-6 text-[var(--crypto-purple)]" />
          Submit Your Intent
          <Sparkles className="ml-2 h-5 w-5 text-yellow-400 animate-pulse" />
        </CardTitle>
        <p className="text-gray-400 text-sm">
          Chỉ cần nêu ý định của bạn, AI Brain sẽ tự động tìm chiến lược tối ưu
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6 relative">
        {/* Intent Type Selection */}
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-3 block">
            Loại Intent
          </Label>
          <div className="grid grid-cols-2 gap-3">
            {Object.entries(intentTemplates).map(([type, template]) => {
              const TemplateIcon = template.icon;
              return (
                <div
                  key={type}
                  onClick={() => setIntentType(type as Intent['type'])}
                  className={`p-3 rounded-lg border cursor-pointer transition-all hover:scale-105 ${
                    intentType === type 
                      ? `${template.bgColor} border-current` 
                      : 'bg-[var(--crypto-light-gray)] border-gray-600 hover:border-gray-500'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <TemplateIcon className={`h-4 w-4 ${intentType === type ? template.color : 'text-gray-400'}`} />
                    <span className={`text-sm font-medium ${intentType === type ? template.color : 'text-gray-300'}`}>
                      {template.title}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Intent Description */}
        <div>
          <Label htmlFor="intent-description" className="text-sm font-medium text-gray-300">
            Mô tả Intent
          </Label>
          <Textarea
            id="intent-description"
            placeholder={selectedTemplate.placeholder}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="bg-[var(--crypto-light-gray)] border-gray-600 mt-2 h-20 resize-none focus:ring-[var(--crypto-purple)]"
          />
          <p className="text-xs text-gray-500 mt-1">
            {selectedTemplate.description}
          </p>
        </div>

        {/* Amount and Token */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="amount" className="text-sm font-medium text-gray-300">
              Số lượng
            </Label>
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-[var(--crypto-light-gray)] border-gray-600 mt-2 focus:ring-[var(--crypto-purple)]"
            />
          </div>
          
          <div>
            <Label htmlFor="token" className="text-sm font-medium text-gray-300">
              Token
            </Label>
            <Select value={token} onValueChange={setToken}>
              <SelectTrigger className="bg-[var(--crypto-light-gray)] border-gray-600 mt-2 focus:ring-[var(--crypto-purple)]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {getAvailableTokens().map((t) => (
                  <SelectItem key={t.symbol} value={t.symbol}>
                    {t.symbol} (Có sẵn: {parseFloat(t.balance).toFixed(2)})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Risk Level */}
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-3 block">
            Mức độ rủi ro
          </Label>
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(riskLevels).map(([level, config]) => (
              <div
                key={level}
                onClick={() => setRiskLevel(level as Intent['riskLevel'])}
                className={`p-3 rounded-lg border cursor-pointer transition-all text-center ${
                  riskLevel === level 
                    ? `${config.color} border-current` 
                    : 'bg-[var(--crypto-light-gray)] border-gray-600 hover:border-gray-500'
                }`}
              >
                <div className="text-sm font-medium">{config.label}</div>
                <div className="text-xs text-gray-400 mt-1">{config.description}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <Button
          onClick={handleSubmitIntent}
          disabled={isSubmitting || !wallet?.isConnected}
          className="w-full crypto-gradient crypto-gradient-hover text-white font-medium py-6 text-lg transition-all duration-200 transform hover:scale-105"
        >
          {isSubmitting ? (
            <div className="flex items-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
              AI Brain đang phân tích...
            </div>
          ) : (
            <div className="flex items-center">
              <IconComponent className="mr-3 h-5 w-5" />
              Submit Intent to AI Brain
            </div>
          )}
        </Button>

        {!wallet?.isConnected && (
          <div className="text-center">
            <Badge variant="outline" className="border-yellow-500 text-yellow-400">
              Kết nối ví để bắt đầu sử dụng Quantum
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
}