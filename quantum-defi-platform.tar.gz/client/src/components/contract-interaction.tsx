import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useWallet } from '@/hooks/use-wallet';
import { web3Service, ERC20_ABI } from '@/lib/web3';
import { useToast } from '@/hooks/use-toast';
import { Code } from 'lucide-react';

export default function ContractInteraction() {
  const [contractAddress, setContractAddress] = useState('');
  const [selectedFunction, setSelectedFunction] = useState('');
  const [parameters, setParameters] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  
  const { wallet } = useWallet();
  const { toast } = useToast();

  const commonFunctions = [
    { name: 'balanceOf', params: 'address' },
    { name: 'transfer', params: 'address,uint256' },
    { name: 'approve', params: 'address,uint256' },
    { name: 'allowance', params: 'address,address' },
    { name: 'name', params: '' },
    { name: 'symbol', params: '' },
    { name: 'decimals', params: '' },
    { name: 'totalSupply', params: '' },
  ];

  const parseParameters = (paramString: string): any[] => {
    if (!paramString.trim()) return [];
    
    try {
      const params = paramString.split(',').map(param => {
        const trimmed = param.trim();
        // Try to parse as number if it looks like one
        if (/^\d+(\.\d+)?$/.test(trimmed)) {
          return trimmed.includes('.') ? parseFloat(trimmed) : parseInt(trimmed);
        }
        // Remove quotes if present
        return trimmed.replace(/^["']|["']$/g, '');
      });
      return params;
    } catch (error) {
      throw new Error('Invalid parameter format. Use comma-separated values.');
    }
  };

  const executeFunction = async () => {
    if (!wallet?.isConnected) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet first",
        variant: "destructive",
      });
      return;
    }

    if (!contractAddress || !selectedFunction) {
      toast({
        title: "Missing Information",
        description: "Please provide contract address and select a function",
        variant: "destructive",
      });
      return;
    }

    setIsExecuting(true);
    setResult(null);

    try {
      const params = parseParameters(parameters);
      
      // Check if this is a view function (doesn't change state)
      const viewFunctions = ['balanceOf', 'allowance', 'name', 'symbol', 'decimals', 'totalSupply'];
      const isViewFunction = viewFunctions.includes(selectedFunction);

      if (isViewFunction) {
        // For view functions, call without transaction
        const result = await web3Service.callContractFunction(
          contractAddress,
          ERC20_ABI,
          selectedFunction,
          params
        );
        
        setResult(typeof result === 'object' ? JSON.stringify(result, null, 2) : result.toString());
        toast({
          title: "Function Called",
          description: "View function executed successfully",
        });
      } else {
        // For state-changing functions, execute transaction
        const txHash = await web3Service.executeContractFunction(
          contractAddress,
          ERC20_ABI,
          selectedFunction,
          params
        );
        
        setResult(`Transaction hash: ${txHash}`);
        toast({
          title: "Transaction Submitted",
          description: `Transaction hash: ${txHash.slice(0, 10)}...`,
        });
      }
    } catch (error) {
      console.error('Contract interaction error:', error);
      toast({
        title: "Execution Failed",
        description: error instanceof Error ? error.message : "Failed to execute function",
        variant: "destructive",
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const getPlaceholderForFunction = (functionName: string) => {
    const placeholders: Record<string, string> = {
      'balanceOf': wallet?.address || '0x...',
      'transfer': `${wallet?.address || '0x...'}, 1000000`,
      'approve': `${wallet?.address || '0x...'}, 1000000`,
      'allowance': `${wallet?.address || '0x...'}, 0x...`,
    };
    return placeholders[functionName] || '';
  };

  return (
    <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Code className="mr-2 h-5 w-5 text-[var(--crypto-purple)]" />
          Smart Contract Interaction
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="contract-address" className="text-sm font-medium text-gray-300">
            Contract Address
          </Label>
          <Input
            id="contract-address"
            placeholder="0x..."
            value={contractAddress}
            onChange={(e) => setContractAddress(e.target.value)}
            className="bg-[var(--crypto-light-gray)] border-gray-600 focus:ring-[var(--crypto-purple)]"
          />
        </div>
        
        <div>
          <Label htmlFor="function-select" className="text-sm font-medium text-gray-300">
            Function
          </Label>
          <Select value={selectedFunction} onValueChange={setSelectedFunction}>
            <SelectTrigger className="bg-[var(--crypto-light-gray)] border-gray-600 focus:ring-[var(--crypto-purple)]">
              <SelectValue placeholder="Select function..." />
            </SelectTrigger>
            <SelectContent>
              {commonFunctions.map((func) => (
                <SelectItem key={func.name} value={func.name}>
                  {func.name}({func.params})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="parameters" className="text-sm font-medium text-gray-300">
            Parameters
          </Label>
          <Textarea
            id="parameters"
            placeholder={getPlaceholderForFunction(selectedFunction)}
            value={parameters}
            onChange={(e) => setParameters(e.target.value)}
            className="bg-[var(--crypto-light-gray)] border-gray-600 h-24 resize-none focus:ring-[var(--crypto-purple)]"
          />
          <p className="text-xs text-gray-500 mt-1">
            Enter comma-separated parameters (e.g., address, amount)
          </p>
        </div>
        
        {result && (
          <div>
            <Label className="text-sm font-medium text-gray-300">Result</Label>
            <div className="bg-[var(--crypto-light-gray)] border border-gray-600 rounded-lg p-3 mt-1">
              <pre className="text-sm text-gray-300 whitespace-pre-wrap">{result}</pre>
            </div>
          </div>
        )}
        
        <Button
          onClick={executeFunction}
          disabled={isExecuting || !wallet?.isConnected}
          className="w-full crypto-gradient crypto-gradient-hover text-white font-medium transition-all duration-200"
        >
          {isExecuting ? 'Executing...' : 'Execute Function'}
        </Button>
      </CardContent>
    </Card>
  );
}
