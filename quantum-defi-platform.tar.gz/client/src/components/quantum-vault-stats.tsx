import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, Users, Shield, Zap, Database, Activity, Lock, Globe } from 'lucide-react';
import type { QuantumVault } from '@shared/types';

export default function QuantumVaultStats() {
  const [vaultData, setVaultData] = useState<QuantumVault | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Mock data for Quantum Vault - in real app, fetch from API
  const mockVaultData: QuantumVault = {
    totalTVL: '42500000',
    totalUsers: 1247,
    aParameter: 0.85,
    currentAPY: '12.7',
    mevCaptured24h: '127500',
    securityScore: 98,
    activeStrategies: 23,
    supportedChains: ['Ethereum', 'Arbitrum', 'Polygon', 'Optimism'],
  };

  useEffect(() => {
    // Simulate API call
    const loadVaultData = async () => {
      setIsLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1500));
      setVaultData(mockVaultData);
      setIsLoading(false);
    };

    loadVaultData();
  }, []);

  const formatNumber = (num: string | number) => {
    const value = typeof num === 'string' ? parseFloat(num) : num;
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}K`;
    }
    return `$${value.toFixed(0)}`;
  };

  const getSecurityColor = (score: number) => {
    if (score >= 95) return 'text-green-400';
    if (score >= 85) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getAPYColor = (apy: string) => {
    const value = parseFloat(apy);
    if (value >= 15) return 'text-green-400';
    if (value >= 10) return 'text-blue-400';
    return 'text-gray-400';
  };

  if (isLoading) {
    return (
      <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)]">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Database className="mr-2 h-5 w-5 text-[var(--crypto-purple)]" />
            Quantum Vault Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-[var(--crypto-light-gray)] rounded-lg p-4 animate-pulse">
                <div className="h-4 bg-gray-600 rounded mb-2"></div>
                <div className="h-6 bg-gray-600 rounded mb-2"></div>
                <div className="h-3 bg-gray-600 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!vaultData) return null;

  return (
    <Card className="bg-[var(--crypto-gray)] border-[var(--crypto-light-gray)] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-transparent to-blue-500/5"></div>
      <CardHeader className="relative">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Database className="mr-2 h-5 w-5 text-[var(--crypto-purple)]" />
            Quantum Vault Analytics
          </div>
          <Badge className="bg-green-500/20 text-green-400">
            <Activity className="mr-1 h-3 w-3" />
            Live
          </Badge>
        </CardTitle>
        <p className="text-gray-400 text-sm">
          Thống kê thời gian thực của Quantum Vault - AMM Chủ động đầu tiên trên thế giới
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6 relative">
        {/* Main Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Total TVL */}
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="h-5 w-5 text-green-400" />
                <Badge variant="outline" className="text-xs border-green-500 text-green-400">
                  +12.3%
                </Badge>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold text-green-400">
                  {formatNumber(vaultData.totalTVL)}
                </p>
                <p className="text-xs text-gray-400">Total Value Locked</p>
              </div>
            </CardContent>
          </Card>

          {/* Current APY */}
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Zap className="h-5 w-5 text-[var(--crypto-blue)]" />
                <Badge variant="outline" className="text-xs border-blue-500 text-blue-400">
                  Auto
                </Badge>
              </div>
              <div className="space-y-1">
                <p className={`text-2xl font-bold ${getAPYColor(vaultData.currentAPY)}`}>
                  {vaultData.currentAPY}%
                </p>
                <p className="text-xs text-gray-400">Current APY</p>
              </div>
            </CardContent>
          </Card>

          {/* Active Users */}
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Users className="h-5 w-5 text-purple-400" />
                <Badge variant="outline" className="text-xs border-purple-500 text-purple-400">
                  +47
                </Badge>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold text-purple-400">
                  {vaultData.totalUsers.toLocaleString()}
                </p>
                <p className="text-xs text-gray-400">Active Users</p>
              </div>
            </CardContent>
          </Card>

          {/* Security Score */}
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Shield className="h-5 w-5 text-green-400" />
                <Badge variant="outline" className="text-xs border-green-500 text-green-400">
                  Forta
                </Badge>
              </div>
              <div className="space-y-1">
                <p className={`text-2xl font-bold ${getSecurityColor(vaultData.securityScore)}`}>
                  {vaultData.securityScore}/100
                </p>
                <p className="text-xs text-gray-400">Security Score</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* A Parameter & MEV Stats */}
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4 space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">A Parameter (Tự động điều chỉnh)</span>
                  <span className="text-sm font-mono text-blue-400">{vaultData.aParameter}</span>
                </div>
                <Progress 
                  value={vaultData.aParameter * 100} 
                  className="h-2"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Cao = Ổn định, Thấp = Biến động
                </p>
              </div>
              
              <div className="border-t border-gray-600 pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">MEV Captured (24h)</span>
                  <span className="text-sm font-bold text-yellow-400">
                    {formatNumber(vaultData.mevCaptured24h)}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Lợi nhuận từ MEV được chia cho tất cả người dùng
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Strategy & Chain Info */}
          <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
            <CardContent className="p-4 space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">Active Strategies</span>
                  <Badge className="bg-blue-500/20 text-blue-400">
                    {vaultData.activeStrategies}
                  </Badge>
                </div>
                <p className="text-xs text-gray-500">
                  AI đang chạy {vaultData.activeStrategies} chiến lược đồng thời
                </p>
              </div>
              
              <div className="border-t border-gray-600 pt-4">
                <div className="flex items-center mb-2">
                  <Globe className="h-4 w-4 text-green-400 mr-2" />
                  <span className="text-sm text-gray-400">Supported Chains</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {vaultData.supportedChains.map((chain) => (
                    <Badge key={chain} variant="outline" className="text-xs border-gray-500 text-gray-300">
                      {chain}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Security Features */}
        <Card className="bg-[var(--crypto-light-gray)] border-gray-600">
          <CardContent className="p-4">
            <div className="flex items-center mb-3">
              <Lock className="h-4 w-4 text-green-400 mr-2" />
              <span className="text-sm font-medium text-gray-300">Security Features</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Badge className="bg-green-500/20 text-green-400 justify-center py-2">
                Forta Monitor
              </Badge>
              <Badge className="bg-blue-500/20 text-blue-400 justify-center py-2">
                Multi-Sig
              </Badge>
              <Badge className="bg-purple-500/20 text-purple-400 justify-center py-2">
                Timelock
              </Badge>
              <Badge className="bg-yellow-500/20 text-yellow-400 justify-center py-2">
                Formal Verification
              </Badge>
            </div>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  );
}