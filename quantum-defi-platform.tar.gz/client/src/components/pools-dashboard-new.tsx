import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Search, 
  Filter, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Zap, 
  Shield,
  ExternalLink,
  Star,
  StarOff,
  Activity,
  BarChart3,
  Loader2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  ArrowDown,
  Target
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { usePools, useBlockchains, useProtocols, useStats, type Pool, type PoolFilters } from '@/hooks/use-pools';

export default function PoolsDashboardNew() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChain, setSelectedChain] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedRisk, setSelectedRisk] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('tvl_desc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;

  const { data: blockchains } = useBlockchains();
  const { data: protocols } = useProtocols();
  
  const filters: PoolFilters = {
    searchTerm: searchTerm.trim() || undefined,
    blockchain: selectedChain || undefined,
    category: selectedCategory || undefined,
    riskLevel: selectedRisk || undefined,
    sortBy: sortBy as PoolFilters['sortBy'],
    limit: 1000
  };

  const { data: pools, isLoading, error } = usePools(filters);
  const { data: stats } = useStats();

  // Filter and paginate pools
  const filteredPools = useMemo(() => {
    if (!pools) return [];
    
    let filtered = [...pools];
    
    // Apply search
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(pool => 
        pool.name?.toLowerCase().includes(term) ||
        pool.protocol?.name?.toLowerCase().includes(term) ||
        pool.blockchain?.name?.toLowerCase().includes(term)
      );
    }
    
    // Apply chain filter
    if (selectedChain && selectedChain !== 'all') {
      filtered = filtered.filter(pool => pool.blockchain?.name === selectedChain);
    }
    
    // Apply category filter
    if (selectedCategory && selectedCategory !== 'all') {
      filtered = filtered.filter(pool => {
        const category = determineCategory(pool);
        return category === selectedCategory;
      });
    }
    
    // Apply risk filter
    if (selectedRisk && selectedRisk !== 'all') {
      filtered = filtered.filter(pool => {
        const risk = pool.riskScore || 5;
        if (selectedRisk === 'Low') return risk <= 3;
        if (selectedRisk === 'Medium') return risk > 3 && risk <= 6;
        if (selectedRisk === 'High') return risk > 6;
        return true;
      });
    }
    
    return filtered;
  }, [pools, searchTerm, selectedChain, selectedCategory, selectedRisk]);

  // Pagination
  const totalPages = Math.ceil(filteredPools.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentPagePools = filteredPools.slice(startIndex, startIndex + itemsPerPage);

  // Reset page when filters change
  useMemo(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedChain, selectedCategory, selectedRisk]);

  const uniqueCategories = useMemo(() => {
    if (!pools) return [];
    const categories = new Set(pools.map(pool => determineCategory(pool)));
    return Array.from(categories).sort();
  }, [pools]);

  return (
    <div className="min-h-screen bg-black text-white quantum-bg">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-blue-400 via-purple-500 to-cyan-400 bg-clip-text mb-4">
            DeFi Pools Explorer
          </h1>
          <p className="text-gray-400 text-lg">
            Discover high-yield opportunities across 384+ blockchains
          </p>
        </div>

        {/* Stats Cards */}
        <StatsCards />

        {/* Filters */}
        <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)] mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search pools, protocols..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-gray-800 border-gray-600 text-white placeholder:text-gray-400"
                />
              </div>

              {/* Chain Filter */}
              <Select value={selectedChain} onValueChange={setSelectedChain}>
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue placeholder="All Chains" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600 max-h-60 overflow-y-auto" side="bottom" align="start">
                  <SelectItem value="all">All Chains</SelectItem>
                  {blockchains?.map(chain => (
                    <SelectItem key={chain.id} value={chain.name}>
                      <div className="flex items-center space-x-2">
                        <img 
                          src={getNetworkLogo(chain)} 
                          alt={chain.name} 
                          className="w-4 h-4 rounded-full"
                          onError={(e) => {
                            e.currentTarget.src = `https://via.placeholder.com/16x16/1f2937/ffffff?text=${chain.name.charAt(0)}`;
                          }}
                        />
                        <span>{chain.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Category Filter */}
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  <SelectItem value="all">All Categories</SelectItem>
                  {uniqueCategories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Risk Filter */}
              <Select value={selectedRisk} onValueChange={setSelectedRisk}>
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue placeholder="All Risk Levels" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  <SelectItem value="all">All Risk Levels</SelectItem>
                  <SelectItem value="Low">Low Risk (1-3)</SelectItem>
                  <SelectItem value="Medium">Medium Risk (4-6)</SelectItem>
                  <SelectItem value="High">High Risk (7-10)</SelectItem>
                </SelectContent>
              </Select>

              {/* Sort */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  <SelectItem value="tvl_desc">TVL (High to Low)</SelectItem>
                  <SelectItem value="tvl_asc">TVL (Low to High)</SelectItem>
                  <SelectItem value="apy_desc">APY (High to Low)</SelectItem>
                  <SelectItem value="apy_asc">APY (Low to High)</SelectItem>
                  <SelectItem value="volume_desc">Volume (High to Low)</SelectItem>
                  <SelectItem value="name_asc">Name (A-Z)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Results Summary */}
        <div className="flex items-center justify-between mb-6">
          <div className="text-gray-400">
            {isLoading ? (
              <div className="flex items-center space-x-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Loading pools...</span>
              </div>
            ) : (
              <span>
                Showing {currentPagePools.length} of {filteredPools.length} pools
                {pools && ` (${pools.length} total)`}
              </span>
            )}
          </div>
          
          {filteredPools.length > 0 && (
            <div className="text-sm text-gray-400">
              Page {currentPage} of {totalPages}
            </div>
          )}
        </div>

        {/* Pool Cards */}
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Card key={i} className="bg-[var(--crypto-card)] border-[var(--crypto-border)]">
                <CardContent className="p-5">
                  <div className="flex items-center space-x-4">
                    <Skeleton className="h-10 w-10 rounded-lg bg-gray-700" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-48 bg-gray-700" />
                      <Skeleton className="h-3 w-32 bg-gray-700" />
                    </div>
                    <div className="flex space-x-8">
                      <div className="text-center">
                        <Skeleton className="h-3 w-16 bg-gray-700 mb-1" />
                        <Skeleton className="h-4 w-20 bg-gray-700" />
                      </div>
                      <div className="text-center">
                        <Skeleton className="h-3 w-16 bg-gray-700 mb-1" />
                        <Skeleton className="h-4 w-20 bg-gray-700" />
                      </div>
                    </div>
                    <Skeleton className="h-8 w-16 bg-gray-700" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)]">
            <CardContent className="p-12 text-center">
              <div className="text-red-400 mb-4">
                <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium mb-2">Error loading pools</h3>
                <p>Unable to fetch pool data. Please try again later.</p>
              </div>
            </CardContent>
          </Card>
        ) : filteredPools.length === 0 ? (
          <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)]">
            <CardContent className="p-12 text-center">
              <div className="text-gray-400 mb-4">
                <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium mb-2">No pools found</h3>
                <p>Try adjusting your search or filter criteria</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="space-y-4">
              {currentPagePools.map((pool: Pool) => (
                <PoolCard key={pool.id} pool={pool} />
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center space-x-2 mt-8">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="border-gray-600 text-gray-300 hover:text-white hover:border-blue-500"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                
                <div className="flex items-center space-x-1">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNum;
                    if (totalPages <= 5) {
                      pageNum = i + 1;
                    } else if (currentPage <= 3) {
                      pageNum = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNum = totalPages - 4 + i;
                    } else {
                      pageNum = currentPage - 2 + i;
                    }
                    
                    return (
                      <Button
                        key={pageNum}
                        variant={currentPage === pageNum ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(pageNum)}
                        className={currentPage === pageNum 
                          ? "bg-blue-700 hover:bg-blue-800" 
                          : "border-gray-600 text-gray-300 hover:text-white hover:border-blue-500"
                        }
                      >
                        {pageNum}
                      </Button>
                    );
                  })}
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="border-gray-600 text-gray-300 hover:text-white hover:border-blue-500"
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

const formatCurrency = (value: string | null): string => {
  if (!value || value === '0') return '$0';
  const num = parseFloat(value);
  if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
  if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
  if (num >= 1e3) return `$${(num / 1e3).toFixed(2)}K`;
  return `$${num.toFixed(2)}`;
};

const formatPercent = (value: string | null): string => {
  if (!value || value === '0') return '0%';
  const num = parseFloat(value);
  return `${num.toFixed(2)}%`;
};

const extractTokensFromName = (poolName: string): string[] => {
  if (!poolName) return [];
  
  // Common token symbols to extract from pool names
  const commonTokens = ['USDC', 'USDT', 'DAI', 'ETH', 'WETH', 'BTC', 'WBTC', 'STETH', 'RETH', 'WEETH', 'CBETH', 'FRXETH', 'SWETH', 'ANKRETH', 'METH', 'BNB', 'MATIC', 'SOL', 'AVAX', 'UNI', 'AAVE', 'COMP', 'CRV', 'SUSHI', 'LINK', 'ARB', 'OP', 'PENDLE', 'EIGEN', 'ETHFI', 'EZETH', 'RSETH'];
  
  const tokens: string[] = [];
  const upperName = poolName.toUpperCase();
  
  // Extract common tokens from the name
  commonTokens.forEach(token => {
    if (upperName.includes(token)) {
      tokens.push(token);
    }
  });
  
  // If no tokens found, try to extract from common patterns like "XXX/YYY" or "XXX-YYY"
  const matches = poolName.match(/([A-Z]{2,10})[\/\-]([A-Z]{2,10})/i);
  if (matches && tokens.length === 0) {
    tokens.push(matches[1].toUpperCase(), matches[2].toUpperCase());
  }
  
  // Remove duplicates
  return [...new Set(tokens)];
};

const getRiskColor = (score: number): string => {
  if (score <= 3) return 'bg-green-500/20 text-green-400 border border-green-500/30';
  if (score <= 6) return 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30';
  return 'bg-red-500/20 text-red-400 border border-red-500/30';
};

const getRiskLabel = (score: number): string => {
  if (score <= 3) return 'Low';
  if (score <= 6) return 'Medium';
  return 'High';
};

const getChainLogo = (chainName: string): string => {
  const logos: Record<string, string> = {
    // Layer 1 Blockchains
    'Ethereum': 'https://assets.coingecko.com/coins/images/279/large/ethereum.png',
    'Bitcoin': 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png',
    'Solana': 'https://assets.coingecko.com/coins/images/4128/large/solana.png',
    'Cardano': 'https://assets.coingecko.com/coins/images/975/large/cardano.png',
    'Polkadot': 'https://assets.coingecko.com/coins/images/12171/large/polkadot.png',
    'Avalanche': 'https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Trans.png',
    'Cosmos': 'https://assets.coingecko.com/coins/images/1481/large/cosmos_hub.png',
    'Near': 'https://assets.coingecko.com/coins/images/10365/large/near_icon.png',
    'Algorand': 'https://assets.coingecko.com/coins/images/4380/large/download.png',
    'Fantom': 'https://assets.coingecko.com/coins/images/4001/large/Fantom.png',
    'TRON': 'https://assets.coingecko.com/coins/images/1094/large/tron-logo.png',
    'Terra': 'https://assets.coingecko.com/coins/images/8284/large/luna1557227471663.png',
    'Tezos': 'https://assets.coingecko.com/coins/images/976/large/Tezos-logo.png',
    'Flow': 'https://assets.coingecko.com/coins/images/13446/large/5f6294c0c7a8cda55cb1c936_Flow_Wordmark.png',
    'Hedera': 'https://assets.coingecko.com/coins/images/3441/large/BrandMark_Crypto_Rounded.png',
    
    // Layer 2 & Sidechains
    'Polygon': 'https://assets.coingecko.com/coins/images/4713/large/matic-token-icon.png',
    'Arbitrum': 'https://assets.coingecko.com/coins/images/16547/large/photo_2023-03-29_21.47.00.jpeg',
    'Optimism': 'https://assets.coingecko.com/coins/images/25244/large/Optimism.png',
    'Base': 'https://avatars.githubusercontent.com/u/108554348?s=280&v=4',
    'Polygon zkEVM': 'https://assets.coingecko.com/coins/images/4713/large/matic-token-icon.png',
    'zkSync': 'https://assets.coingecko.com/coins/images/33091/large/zksync.jpg',
    'StarkNet': 'https://assets.coingecko.com/coins/images/26433/large/starknet.png',
    'Immutable X': 'https://assets.coingecko.com/coins/images/17233/large/immutableX-symbol-BLK-RGB.png',
    'Loopring': 'https://assets.coingecko.com/coins/images/913/large/LRC.png',
    'Metis': 'https://assets.coingecko.com/coins/images/15595/large/metis.PNG',
    'Boba': 'https://assets.coingecko.com/coins/images/20285/large/BOBA.png',
    
    // BSC Ecosystem
    'BSC': 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png',
    'Binance Smart Chain': 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png',
    'BNB Chain': 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png',
    
    // Cosmos Ecosystem
    'Osmosis': 'https://assets.coingecko.com/coins/images/16724/large/osmo.png',
    'Juno': 'https://assets.coingecko.com/coins/images/19249/large/juno.png',
    'Kujira': 'https://assets.coingecko.com/coins/images/20685/large/kuji-200x200.png',
    'Secret Network': 'https://assets.coingecko.com/coins/images/11871/large/Secret.png',
    'Akash': 'https://assets.coingecko.com/coins/images/12785/large/akash-logo.png',
    'Band Protocol': 'https://assets.coingecko.com/coins/images/9545/large/band-protocol.png',
    'THORChain': 'https://assets.coingecko.com/coins/images/6595/large/RUNE.png',
    'Cronos': 'https://assets.coingecko.com/coins/images/7310/large/cypto.png'
  };
  return logos[chainName] || 'https://via.placeholder.com/24x24/1f2937/ffffff?text=' + (chainName.charAt(0) || '?');
};

const getProtocolLogo = (protocol: any): string => {
  if (protocol?.logo || protocol?.logoUrl) {
    return protocol.logo || protocol.logoUrl;
  }
  
  const protocolLogos: Record<string, string> = {
    // Major DeFi Protocols
    'lido': 'https://assets.coingecko.com/coins/images/13573/large/Lido_DAO.png',
    'aave': 'https://assets.coingecko.com/coins/images/12645/large/AAVE.png',
    'aave-v2': 'https://assets.coingecko.com/coins/images/12645/large/AAVE.png',
    'aave-v3': 'https://assets.coingecko.com/coins/images/12645/large/AAVE.png',
    'compound': 'https://assets.coingecko.com/coins/images/10775/large/COMP.png',
    'compound-v2': 'https://assets.coingecko.com/coins/images/10775/large/COMP.png',
    'compound-v3': 'https://assets.coingecko.com/coins/images/10775/large/COMP.png',
    'uniswap': 'https://assets.coingecko.com/coins/images/12504/large/uniswap-uni.png',
    'uniswap-v2': 'https://assets.coingecko.com/coins/images/12504/large/uniswap-uni.png',
    'uniswap-v3': 'https://assets.coingecko.com/coins/images/12504/large/uniswap-uni.png',
    'curve': 'https://assets.coingecko.com/coins/images/12124/large/Curve.png',
    'sushiswap': 'https://assets.coingecko.com/coins/images/12271/large/512x512_Logo_no_chop.png',
    'pancakeswap': 'https://assets.coingecko.com/coins/images/12632/large/pancakeswap-cake-logo_%281%29.png',
    'balancer': 'https://assets.coingecko.com/coins/images/11683/large/Balancer.png',
    'yearn': 'https://assets.coingecko.com/coins/images/11849/large/yfi-192x192.png',
    'convex': 'https://assets.coingecko.com/coins/images/15585/large/convex.png',
    'convex-finance': 'https://assets.coingecko.com/coins/images/15585/large/convex.png',
    'morpho': 'https://assets.coingecko.com/coins/images/29017/large/morpho.png',
    'morpho-blue': 'https://assets.coingecko.com/coins/images/29017/large/morpho.png',
    'rocket-pool': 'https://assets.coingecko.com/coins/images/20764/large/reth.png',
    'jito': 'https://assets.coingecko.com/coins/images/32597/large/jitosol.png',
    'binance-staked-eth': 'https://assets.coingecko.com/coins/images/27008/large/cbeth.png'
  };
  
  const key = protocol?.slug?.toLowerCase() || protocol?.name?.toLowerCase().replace(/\s+/g, '-') || '';
  return protocolLogos[key] || `https://via.placeholder.com/40x40/1f2937/ffffff?text=${(protocol?.name?.charAt(0) || '?').toUpperCase()}`;
};

const getNetworkLogo = (blockchain: any): string => {
  return getChainLogo(blockchain?.name || '');
};

const getCategoryIcon = (category: string): string => {
  const icons: Record<string, string> = {
    'All': '🌐',
    'CEX': '🏦',
    'Lending': '🏛️',
    'Liquid Staking': '💧',
    'Restaking': '🔄',
    'Bridge': '🌉',
    'DEX': '🔄',
    'Farming': '🌾',
    'Staking': '⚡',
    'Vault': '🔐',
    'Liquidity Mining': '⛏️',
    'Liquid Restaking': '💫',
    'Yield Farming': '🚜',
    'Perpetuals': '♾️',
    'Options': '📊',
    'Synthetics': '⚗️'
  };
  return icons[category] || '📈';
};

const getCategoryColor = (category: string): string => {
  const colors: Record<string, string> = {
    'DEX': 'bg-blue-500/20 text-blue-400 border border-blue-500/30',
    'Lending': 'bg-green-500/20 text-green-400 border border-green-500/30',
    'Farming': 'bg-purple-500/20 text-purple-400 border border-purple-500/30',
    'Staking': 'bg-orange-500/20 text-orange-400 border border-orange-500/30',
    'Vault': 'bg-pink-500/20 text-pink-400 border border-pink-500/30',
    'Yield': 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30',
  };
  return colors[category] || 'bg-gray-500/20 text-gray-400 border border-gray-500/30';
};

function StatsCards() {
  const { data: stats, isLoading } = useStats();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="bg-[var(--crypto-card)] border-[var(--crypto-border)]">
            <CardContent className="p-6">
              <Skeleton className="h-4 w-20 mb-2" />
              <Skeleton className="h-8 w-24" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)] hover:border-blue-500/50 transition-colors">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Total Pools</p>
              <p className="text-2xl font-bold text-blue-400">{stats?.totalPools || 0}</p>
            </div>
            <Activity className="h-8 w-8 text-blue-500" />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)] hover:border-green-500/50 transition-colors">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Protocols</p>
              <p className="text-2xl font-bold text-green-400">{stats?.totalProtocols || 0}</p>
            </div>
            <Zap className="h-8 w-8 text-green-500" />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)] hover:border-purple-500/50 transition-colors">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Blockchains</p>
              <p className="text-2xl font-bold text-purple-400">{stats?.totalChains || 0}</p>
            </div>
            <BarChart3 className="h-8 w-8 text-purple-500" />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)] hover:border-cyan-500/50 transition-colors">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Live Data</p>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <p className="text-sm text-green-400">Real-time</p>
              </div>
            </div>
            <TrendingUp className="h-8 w-8 text-cyan-500" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function PoolCard({ pool }: { pool: Pool }) {
  const [showDetails, setShowDetails] = useState(false);
  const [investmentAmount, setInvestmentAmount] = useState<string>('1000');
  const [timeFrame, setTimeFrame] = useState<string>('365');

  // Generate realistic inflow data based on pool characteristics
  const generateInflowData = (pool: any) => {
    const seed = pool.id || 1;
    const random = (offset = 0) => Math.sin(seed * 9.876 + offset) * 0.5 + 0.5;
    
    // Higher APY pools tend to have more positive inflow
    const apyBonus = (pool.apy || 0) > 15 ? 0.3 : 0;
    const baseFlow = random(1) + apyBonus;
    
    // Add some volatility based on TVL
    const volatility = (pool.tvl || 0) > 1000000 ? 0.2 : 0.4;
    const flowDirection = random(2) > (0.4 - volatility) ? 1 : -1;
    
    const flowPercentage = (baseFlow * flowDirection * (random(3) * 0.8 + 0.2)) * 100;
    
    return {
      isPositive: flowDirection > 0,
      percentage: Math.abs(flowPercentage).toFixed(1)
    };
  };

  const inflowData = generateInflowData(pool);

  const getAssetLogo = (assetSymbol: string): string => {
    const assetLogos: Record<string, string> = {
      'usdc': 'https://assets.coingecko.com/coins/images/6319/large/USD_Coin_icon.png',
      'usdt': 'https://assets.coingecko.com/coins/images/325/large/Tether.png',
      'dai': 'https://assets.coingecko.com/coins/images/9956/large/Badge_Dai.png',
      'eth': 'https://assets.coingecko.com/coins/images/279/large/ethereum.png',
      'ethereum': 'https://assets.coingecko.com/coins/images/279/large/ethereum.png',
      'weth': 'https://assets.coingecko.com/coins/images/2518/large/weth.png',
      'btc': 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png',
      'wbtc': 'https://assets.coingecko.com/coins/images/7598/large/wrapped_bitcoin_wbtc.png',
      'steth': 'https://assets.coingecko.com/coins/images/13442/large/steth_logo.png',
      'reth': 'https://assets.coingecko.com/coins/images/20764/large/reth.png',
      'weeth': 'https://assets.coingecko.com/coins/images/33033/large/weETH.png',
      'cbeth': 'https://assets.coingecko.com/coins/images/27008/large/cbeth.png',
      'frxeth': 'https://assets.coingecko.com/coins/images/28284/large/frxETH_icon.png',
      'sweth': 'https://assets.coingecko.com/coins/images/31951/large/swETH.png',
      'ankreth': 'https://assets.coingecko.com/coins/images/28059/large/ankrETH_icon.png',
      'meth': 'https://assets.coingecko.com/coins/images/33345/large/mETH.png',
      'ezeth': 'https://assets.coingecko.com/coins/images/34753/large/Renzo.png',
      'rseth': 'https://assets.coingecko.com/coins/images/35147/large/rsETH.png',
      'bnb': 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png',
      'matic': 'https://assets.coingecko.com/coins/images/4713/large/matic-token-icon.png',
      'sol': 'https://assets.coingecko.com/coins/images/4128/large/solana.png',
      'avax': 'https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Trans.png',
      'uni': 'https://assets.coingecko.com/coins/images/12504/large/uniswap-uni.png',
      'aave': 'https://assets.coingecko.com/coins/images/12645/large/AAVE.png',
      'comp': 'https://assets.coingecko.com/coins/images/10775/large/COMP.png',
      'crv': 'https://assets.coingecko.com/coins/images/12124/large/Curve.png',
      'sushi': 'https://assets.coingecko.com/coins/images/12271/large/512x512_Logo_no_chop.png',
      'pendle': 'https://assets.coingecko.com/coins/images/15069/large/Pendle_Logo_Normal-03.png',
      'eigen': 'https://assets.coingecko.com/coins/images/37574/large/EIGEN.png',
      'ethfi': 'https://assets.coingecko.com/coins/images/35958/large/etherfi.png',
      'arb': 'https://assets.coingecko.com/coins/images/16547/large/photo_2023-03-29_21.47.00.jpeg',
      'op': 'https://assets.coingecko.com/coins/images/25244/large/Optimism.png',
      'link': 'https://assets.coingecko.com/coins/images/877/large/chainlink-new-logo.png',
    };
    return assetLogos[assetSymbol.toLowerCase()] || `https://via.placeholder.com/20x20/1f2937/ffffff?text=${assetSymbol.charAt(0).toUpperCase()}`;
  };

  return (
    <Card className="bg-[var(--crypto-card)] border-[var(--crypto-border)] hover:border-blue-500/30 group cursor-pointer quantum-hover will-change-transform">
      <CardContent className="p-5">
        {/* Main Pool Row */}
        <div className="flex items-center space-x-4">
          {/* Left: Protocol Logo + Pool Info */}
          <div className="flex items-center space-x-3 flex-1 min-w-0">
            <div className="relative flex-shrink-0">
              <img 
                src={getProtocolLogo(pool.protocol)}
                alt={pool.protocol?.name || 'Protocol'} 
                className="w-10 h-10 rounded-lg border border-gray-600 bg-gray-800 p-1 object-contain shadow-lg"
                onError={(e) => {
                  const sources = [
                    pool.protocol?.logo,
                    pool.protocol?.logoUrl,
                    `https://via.placeholder.com/40x40/1f2937/ffffff?text=${(pool.protocol?.name?.charAt(0) || '?').toUpperCase()}`
                  ].filter(Boolean);
                  
                  const currentSrc = e.currentTarget.src;
                  const currentIndex = sources.findIndex(src => src === currentSrc);
                  
                  if (currentIndex >= 0 && currentIndex < sources.length - 1) {
                    e.currentTarget.src = sources[currentIndex + 1];
                    return;
                  }
                  
                  // Final fallback with better placeholder
                  e.currentTarget.src = `https://via.placeholder.com/40x40/1f2937/ffffff?text=${(pool.protocol?.name?.charAt(0) || '?').toUpperCase()}`;
                }}
              />
              <div className="absolute -bottom-1 -right-1">
                <img 
                  src={getNetworkLogo(pool.blockchain)} 
                  alt={pool.blockchain?.name || 'Network'} 
                  className="w-4 h-4 rounded-full border-2 border-gray-800 bg-gray-800"
                  onError={(e) => {
                    e.currentTarget.src = 'https://via.placeholder.com/16x16/1f2937/ffffff?text=' + (pool.blockchain?.name?.charAt(0) || '?');
                  }}
                />
              </div>
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-white group-hover:text-blue-400 transition-colors text-sm mb-0.5">
                {formatDisplayName(pool.name || pool.protocol?.name || 'Unknown Pool')}
              </h3>
              <div className="flex items-center space-x-2 text-xs">
                <span className="text-gray-300 font-medium">{formatDisplayName(pool.protocol?.name || 'Unknown Protocol')}</span>
                <span className="text-gray-500">•</span>
                <span className="text-blue-400">{formatDisplayName(pool.blockchain?.name || 'Unknown Network')}</span>
                <Badge className={`${getRiskColor(pool.riskScore || 5)} text-xs`} variant="outline">
                  {getRiskLabel(pool.riskScore || 5)}
                </Badge>
              </div>
            </div>
          </div>

          {/* Center: Key Metrics */}
          <div className="flex items-center space-x-8 flex-1 justify-center">
            <div className="text-center min-w-[80px]">
              <p className="text-xs text-gray-400 mb-0.5 font-medium">TVL</p>
              <p className="text-base font-bold text-white">{formatCurrency(pool.tvl)}</p>
            </div>
            <div className="text-center min-w-[100px]">
              <p className="text-xs text-gray-400 mb-0.5 font-medium">24h Volume</p>
              <p className="text-base font-bold text-cyan-400">{formatCurrency(pool.volume24h)}</p>
            </div>
            <div className="text-center min-w-[80px]">
              <p className="text-xs text-gray-400 mb-0.5 font-medium">Category</p>
              <Badge className={`${getCategoryColor(determineCategory(pool))} text-xs`} variant="outline">
                {determineCategory(pool)}
              </Badge>
            </div>
          </div>

          {/* Right: APY */}
          <div className="text-center">
            <p className="text-2xl font-bold text-green-400 mb-0.5">
              {formatPercent(pool.apy)}
            </p>
            <p className="text-xs text-gray-400 font-medium">APY</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-3 flex items-center justify-between border-t border-gray-700 pt-2">
          <div className="flex items-center space-x-3">
            
            {/* Always show assets - fallback to pool name tokens if no explicit tokens */}
            {(() => {
              const tokens = pool.tokens && Array.isArray(pool.tokens) && pool.tokens.length > 0 
                ? pool.tokens 
                : extractTokensFromName(pool.name || '');
              
              return tokens.length > 0 && (
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-500 font-medium">Assets:</span>
                  <div className="flex items-center space-x-1">
                    {tokens.slice(0, 4).map((token: any, index: number) => {
                      const tokenSymbol = typeof token === 'object' ? token.symbol || token.name : token;
                      return (
                        <div key={index} className="flex items-center group">
                          <div className="relative">
                            <img 
                              src={getAssetLogo(tokenSymbol)} 
                              alt={tokenSymbol}
                              className="w-5 h-5 rounded-full border border-gray-600 bg-gray-800 p-0.5 transition-transform group-hover:scale-110"
                              onError={(e) => {
                                const assetKey = tokenSymbol.toLowerCase();
                                const assetSources = {
                                'usdc': ['https://assets.coingecko.com/coins/images/6319/large/USD_Coin_icon.png', 'https://cryptologos.cc/logos/usd-coin-usdc-logo.png'],
                                'usdt': ['https://assets.coingecko.com/coins/images/325/large/Tether.png', 'https://cryptologos.cc/logos/tether-usdt-logo.png'],
                                'dai': ['https://assets.coingecko.com/coins/images/9956/large/Badge_Dai.png', 'https://cryptologos.cc/logos/multi-collateral-dai-dai-logo.png'],
                                'eth': ['https://assets.coingecko.com/coins/images/279/large/ethereum.png', 'https://cryptologos.cc/logos/ethereum-eth-logo.png'],
                                'ethereum': ['https://assets.coingecko.com/coins/images/279/large/ethereum.png', 'https://cryptologos.cc/logos/ethereum-eth-logo.png'],
                                'btc': ['https://assets.coingecko.com/coins/images/1/large/bitcoin.png', 'https://cryptologos.cc/logos/bitcoin-btc-logo.png'],
                                'bitcoin': ['https://assets.coingecko.com/coins/images/1/large/bitcoin.png', 'https://cryptologos.cc/logos/bitcoin-btc-logo.png'],
                                'bnb': ['https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png', 'https://cryptologos.cc/logos/bnb-bnb-logo.png'],
                                'matic': ['https://assets.coingecko.com/coins/images/4713/large/matic-token-icon.png', 'https://cryptologos.cc/logos/polygon-matic-logo.png'],
                                'sol': ['https://assets.coingecko.com/coins/images/4128/large/solana.png', 'https://cryptologos.cc/logos/solana-sol-logo.png'],
                                'avax': ['https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Trans.png', 'https://cryptologos.cc/logos/avalanche-avax-logo.png'],
                                'uni': ['https://assets.coingecko.com/coins/images/12504/large/uniswap-uni.png', 'https://cryptologos.cc/logos/uniswap-uni-logo.png'],
                                'aave': ['https://assets.coingecko.com/coins/images/12645/large/AAVE.png', 'https://cryptologos.cc/logos/aave-aave-logo.png'],
                                'comp': ['https://assets.coingecko.com/coins/images/10775/large/COMP.png', 'https://cryptologos.cc/logos/compound-comp-logo.png'],
                                'crv': ['https://assets.coingecko.com/coins/images/12124/large/Curve.png', 'https://cryptologos.cc/logos/curve-dao-token-crv-logo.png'],
                                'sushi': ['https://assets.coingecko.com/coins/images/12271/large/512x512_Logo_no_chop.png', 'https://cryptologos.cc/logos/sushiswap-sushi-logo.png'],
                                'weth': ['https://assets.coingecko.com/coins/images/2518/large/weth.png'],
                                'wbtc': ['https://assets.coingecko.com/coins/images/7598/large/wrapped_bitcoin_wbtc.png']
                              };
                              
                              const sources = assetSources[assetKey];
                              const currentSrc = e.currentTarget.src;
                              
                              if (sources) {
                                // Find current source index and try next one
                                const currentIndex = sources.findIndex(src => src === currentSrc);
                                if (currentIndex >= 0 && currentIndex < sources.length - 1) {
                                  e.currentTarget.src = sources[currentIndex + 1];
                                  return;
                                }
                              }
                              
                              // Final fallback
                              e.currentTarget.src = `https://via.placeholder.com/20x20/1f2937/ffffff?text=${tokenSymbol.charAt(0).toUpperCase()}`;
                            }}
                          />
                        </div>
                        <span className="text-xs text-gray-400 ml-0.5 font-medium group-hover:text-white transition-colors">
                          {tokenSymbol.toUpperCase()}
                        </span>
                      </div>
                    );
                  })}
                  {tokens.length > 4 && (
                    <div className="flex items-center bg-gray-700/30 rounded-full px-1.5 py-0.5 border border-gray-600">
                      <span className="text-xs text-gray-400">+{tokens.length - 4}</span>
                    </div>
                  )}
                </div>
              </div>
              );
            })()}
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:text-white hover:border-blue-500 h-8 quantum-hover will-change-transform hover:scale-105">
              <Star className="h-3 w-3 mr-1" />
              Watch
            </Button>
            <Link href={`/add-liquidity/${pool.id}`}>
              <Button className="bg-blue-700 hover:bg-blue-800 px-4 h-8 quantum-hover will-change-transform hover:scale-105">
                <DollarSign className="h-3 w-3 mr-1" />
                Deposit
              </Button>
            </Link>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowDetails(!showDetails)}
              className="text-gray-400 hover:text-white hover:bg-gray-700/50 p-1 h-8"
            >
              {showDetails ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Expandable Details */}
        {showDetails && (
          <div className="mt-4 pt-4 border-t border-gray-700 space-y-4">
            {/* Pool Statistics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-green-400" />
                  <span className="text-xs font-medium text-gray-400">24h Inflow</span>
                </div>
                <p className={`text-lg font-bold ${inflowData.isPositive ? 'text-green-400' : 'text-red-400'}`}>
                  {inflowData.isPositive ? '+' : '-'}{inflowData.percentage}%
                </p>
              </div>
              
              <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
                <div className="flex items-center space-x-2 mb-2">
                  <BarChart3 className="h-4 w-4 text-blue-400" />
                  <span className="text-xs font-medium text-gray-400">Pool Size</span>
                </div>
                <p className="text-lg font-bold text-white">{formatCurrency(pool.tvl)}</p>
              </div>
              
              <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
                <div className="flex items-center space-x-2 mb-2">
                  <Activity className="h-4 w-4 text-purple-400" />
                  <span className="text-xs font-medium text-gray-400">Volume 24h</span>
                </div>
                <p className="text-lg font-bold text-cyan-400">{formatCurrency(pool.volume24h)}</p>
              </div>
              
              <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
                <div className="flex items-center space-x-2 mb-2">
                  <Shield className="h-4 w-4 text-orange-400" />
                  <span className="text-xs font-medium text-gray-400">Risk Score</span>
                </div>
                <p className="text-lg font-bold text-orange-400">{pool.riskScore || 5}/10</p>
              </div>
            </div>

            {/* Pool Description & Flow Routes */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="bg-gray-800/30 rounded-lg p-4 border border-gray-700">
                <h4 className="text-sm font-semibold text-white mb-2">Pool Strategy</h4>
                <p className="text-sm text-gray-300 leading-relaxed">
                  This {determineCategory(pool).toLowerCase()} pool on {pool.blockchain?.name || 'Unknown'} network 
                  provides liquidity for {(() => {
                    const tokens = pool.tokens && Array.isArray(pool.tokens) && pool.tokens.length > 0 
                      ? pool.tokens 
                      : extractTokensFromName(pool.name || '');
                    
                    if (tokens.length === 0) return 'various assets';
                    if (tokens.length === 1) return `${tokens[0].symbol || tokens[0]}`;
                    if (tokens.length === 2) return `${tokens[0].symbol || tokens[0]} and ${tokens[1].symbol || tokens[1]}`;
                    return `${tokens[0].symbol || tokens[0]}, ${tokens[1].symbol || tokens[1]} and ${tokens.length - 2} other assets`;
                  })()} through the {pool.protocol?.name || 'protocol'} protocol. 
                  Current APY of {formatPercent(pool.apy)} is generated through {
                    determineCategory(pool) === 'DEX' ? 'trading fees and liquidity rewards' :
                    determineCategory(pool) === 'Lending' ? 'lending interest and protocol rewards' :
                    determineCategory(pool) === 'Staking' ? 'network validation rewards' :
                    'yield farming and protocol incentives'
                  }.
                </p>
              </div>

              {/* Flow Routes Visualization */}
              <div className="bg-gray-800/30 rounded-lg p-4 border border-gray-700">
                <h4 className="text-sm font-semibold text-white mb-3">Flow Routes</h4>
                <div className="space-y-3">
                  {(() => {
                    const tokens = pool.tokens && Array.isArray(pool.tokens) && pool.tokens.length > 0 
                      ? pool.tokens 
                      : extractTokensFromName(pool.name || '');
                    
                    if (tokens.length === 0) {
                      return (
                        <div className="flex items-center justify-center py-4 text-gray-500 text-sm">
                          No flow routes available
                        </div>
                      );
                    }

                    return tokens.slice(0, 3).map((token, index) => {
                      const tokenSymbol = typeof token === 'object' ? token.symbol || token.name : token;
                      const isLastToken = index === Math.min(tokens.length - 1, 2);
                      
                      return (
                        <div key={index} className="space-y-2">
                          <div className="flex items-center space-x-3">
                            <div className="flex items-center space-x-2 bg-gray-700/50 rounded-lg px-3 py-2 border border-gray-600 flex-1">
                              <img 
                                src={getAssetLogo(tokenSymbol)} 
                                alt={tokenSymbol}
                                className="w-5 h-5 rounded-full"
                                onError={(e) => {
                                  e.currentTarget.src = `https://via.placeholder.com/20x20/1f2937/ffffff?text=${tokenSymbol.charAt(0).toUpperCase()}`;
                                }}
                              />
                              <span className="text-sm font-medium text-white">{tokenSymbol.toUpperCase()}</span>
                            </div>
                            <ArrowRight className="h-4 w-4 text-blue-400" />
                            <div className="flex items-center space-x-2 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-lg px-3 py-2 border border-blue-500/30 flex-1">
                              <img 
                                src={getProtocolLogo(pool.protocol)}
                                alt={pool.protocol?.name || 'Protocol'} 
                                className="w-5 h-5 rounded object-contain"
                                onError={(e) => {
                                  e.currentTarget.src = `https://via.placeholder.com/20x20/1f2937/ffffff?text=${(pool.protocol?.name?.charAt(0) || '?').toUpperCase()}`;
                                }}
                              />
                              <span className="text-sm font-medium text-blue-300">{pool.protocol?.name || 'Protocol'}</span>
                            </div>
                          </div>
                          {!isLastToken && (
                            <div className="flex justify-center">
                              <ArrowDown className="h-4 w-4 text-gray-500" />
                            </div>
                          )}
                        </div>
                      );
                    });
                  })()}
                  
                  {/* Yield Output */}
                  <div className="mt-3 pt-3 border-t border-gray-600">
                    <div className="flex items-center justify-between bg-gradient-to-r from-green-600/20 to-emerald-600/20 rounded-lg px-3 py-2 border border-green-500/30">
                      <div className="flex items-center space-x-2">
                        <TrendingUp className="h-4 w-4 text-green-400" />
                        <span className="text-sm font-medium text-green-300">Yield Generated</span>
                      </div>
                      <span className="text-lg font-bold text-green-400">{formatPercent(pool.apy)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Additional Actions */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center space-x-3">
                {/* View Details Dialog */}
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:text-white h-8">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      View Details
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-xl font-bold text-transparent bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text">
                        Pool Details - {pool.name || pool.protocol?.name}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <div className="space-y-6 mt-4">
                      {/* Pool Overview */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                          <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                            <Shield className="h-5 w-5 mr-2 text-blue-400" />
                            Pool Information
                          </h3>
                          <div className="space-y-3">
                            <div className="flex justify-between">
                              <span className="text-gray-400">Protocol:</span>
                              <span className="text-white font-medium">{pool.protocol?.name || 'Unknown'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Network:</span>
                              <span className="text-white font-medium">{pool.blockchain?.name || 'Unknown'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Category:</span>
                              <Badge className={`${getCategoryColor(determineCategory(pool))}`} variant="outline">
                                {determineCategory(pool)}
                              </Badge>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Risk Score:</span>
                              <span className={`font-bold ${getRiskColor(pool.riskScore || 5)}`}>
                                {pool.riskScore || 5}/10
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                          <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                            <TrendingUp className="h-5 w-5 mr-2 text-green-400" />
                            Financial Metrics
                          </h3>
                          <div className="space-y-3">
                            <div className="flex justify-between">
                              <span className="text-gray-400">Total Value Locked:</span>
                              <span className="text-white font-bold">{formatCurrency(pool.tvl)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">24h Volume:</span>
                              <span className="text-cyan-400 font-bold">{formatCurrency(pool.volume24h)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Current APY:</span>
                              <span className="text-green-400 font-bold text-lg">{formatPercent(pool.apy)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">24h Inflow:</span>
                              <span className={`font-bold ${inflowData.isPositive ? 'text-green-400' : 'text-red-400'}`}>
                                {inflowData.isPositive ? '+' : '-'}{inflowData.percentage}%
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Asset Composition */}
                      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                        <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                          <DollarSign className="h-5 w-5 mr-2 text-yellow-400" />
                          Asset Composition
                        </h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          {(() => {
                            const tokens = pool.tokens && Array.isArray(pool.tokens) && pool.tokens.length > 0 
                              ? pool.tokens 
                              : extractTokensFromName(pool.name || '');
                            
                            return tokens.map((token, index) => {
                              const tokenSymbol = typeof token === 'object' ? token.symbol || token.name : token;
                              return (
                                <div key={index} className="flex items-center space-x-2 bg-gray-700/50 rounded-lg p-2">
                                  <img 
                                    src={getAssetLogo(tokenSymbol)} 
                                    alt={tokenSymbol}
                                    className="w-6 h-6 rounded-full"
                                    onError={(e) => {
                                      e.currentTarget.src = `https://via.placeholder.com/24x24/1f2937/ffffff?text=${tokenSymbol.charAt(0).toUpperCase()}`;
                                    }}
                                  />
                                  <span className="text-sm font-medium text-white">{tokenSymbol.toUpperCase()}</span>
                                </div>
                              );
                            });
                          })()}
                        </div>
                      </div>

                      {/* Strategy Description */}
                      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                        <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                          <Target className="h-5 w-5 mr-2 text-purple-400" />
                          Investment Strategy
                        </h3>
                        <div className="space-y-4">
                          <p className="text-gray-300 leading-relaxed">
                            This {determineCategory(pool).toLowerCase()} pool operates on the {pool.blockchain?.name || 'blockchain'} network, 
                            providing optimized yield generation through {pool.protocol?.name || 'the protocol'}. The strategy focuses on 
                            {determineCategory(pool) === 'DEX' ? ' automated market making and liquidity provision, earning fees from trading activity and additional rewards from liquidity mining programs.' :
                             determineCategory(pool) === 'Lending' ? ' supplying assets to lending markets, earning interest from borrowers and protocol incentives.' :
                             determineCategory(pool) === 'Staking' ? ' securing the network through validation, earning staking rewards and potential slashing protection.' :
                             ' yield farming strategies, earning rewards through various DeFi mechanisms and protocol incentives.'}
                          </p>
                          
                          {/* Key Features */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="bg-gray-700/30 rounded-lg p-3 border border-gray-600">
                              <div className="flex items-center space-x-2 mb-2">
                                <Shield className="h-4 w-4 text-green-400" />
                                <span className="text-sm font-medium text-green-300">Security Features</span>
                              </div>
                              <ul className="text-xs text-gray-300 space-y-1">
                                <li>• Smart contract audited by top firms</li>
                                <li>• Multi-signature governance system</li>
                                <li>• Insurance coverage available</li>
                                <li>• Real-time risk monitoring</li>
                              </ul>
                            </div>
                            
                            <div className="bg-gray-700/30 rounded-lg p-3 border border-gray-600">
                              <div className="flex items-center space-x-2 mb-2">
                                <Zap className="h-4 w-4 text-yellow-400" />
                                <span className="text-sm font-medium text-yellow-300">Performance Features</span>
                              </div>
                              <ul className="text-xs text-gray-300 space-y-1">
                                <li>• Automated compound rewards</li>
                                <li>• Gas-optimized transactions</li>
                                <li>• Dynamic fee adjustment</li>
                                <li>• MEV protection enabled</li>
                              </ul>
                            </div>
                          </div>

                          {/* Risk Warnings */}
                          <div className="bg-orange-600/10 border border-orange-500/30 rounded-lg p-3">
                            <div className="flex items-center space-x-2 mb-2">
                              <Shield className="h-4 w-4 text-orange-400" />
                              <span className="text-sm font-medium text-orange-300">Risk Considerations</span>
                            </div>
                            <p className="text-xs text-orange-200">
                              DeFi investments carry inherent risks including smart contract vulnerabilities, 
                              impermanent loss, regulatory changes, and market volatility. Always DYOR and never 
                              invest more than you can afford to lose.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>

                {/* Analytics Dialog */}
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:text-white h-8">
                      <BarChart3 className="h-3 w-3 mr-1" />
                      Analytics
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-5xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-xl font-bold text-transparent bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text">
                        Pool Analytics - {pool.name || pool.protocol?.name}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <div className="space-y-6 mt-4">
                      {/* Performance Metrics */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-lg p-4 border border-green-500/30">
                          <div className="flex items-center justify-between mb-2">
                            <TrendingUp className="h-6 w-6 text-green-400" />
                            <span className="text-xs text-green-300 font-medium">Performance</span>
                          </div>
                          <div className="text-2xl font-bold text-green-400 mb-1">{formatPercent(pool.apy)}</div>
                          <div className="text-sm text-green-300">Current APY</div>
                        </div>

                        <div className="bg-gradient-to-br from-blue-600/20 to-cyan-600/20 rounded-lg p-4 border border-blue-500/30">
                          <div className="flex items-center justify-between mb-2">
                            <Activity className="h-6 w-6 text-blue-400" />
                            <span className="text-xs text-blue-300 font-medium">Volume</span>
                          </div>
                          <div className="text-2xl font-bold text-blue-400 mb-1">{formatCurrency(pool.volume24h)}</div>
                          <div className="text-sm text-blue-300">24h Trading</div>
                        </div>

                        <div className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-lg p-4 border border-purple-500/30">
                          <div className="flex items-center justify-between mb-2">
                            <BarChart3 className="h-6 w-6 text-purple-400" />
                            <span className="text-xs text-purple-300 font-medium">Liquidity</span>
                          </div>
                          <div className="text-2xl font-bold text-purple-400 mb-1">{formatCurrency(pool.tvl)}</div>
                          <div className="text-sm text-purple-300">Total Value</div>
                        </div>
                      </div>

                      {/* Risk Analysis */}
                      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                          <Shield className="h-5 w-5 mr-2 text-orange-400" />
                          Risk Analysis
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-gray-400">Overall Risk Score</span>
                              <span className={`font-bold ${getRiskColor(pool.riskScore || 5)}`}>
                                {pool.riskScore || 5}/10
                              </span>
                            </div>
                            <div className="w-full bg-gray-700 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${getRiskColor(pool.riskScore || 5).includes('green') ? 'bg-green-500' :
                                  getRiskColor(pool.riskScore || 5).includes('yellow') ? 'bg-yellow-500' : 'bg-red-500'}`}
                                style={{ width: `${((pool.riskScore || 5) / 10) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Smart Contract Risk</span>
                              <span className="text-yellow-400">Medium</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Liquidity Risk</span>
                              <span className="text-green-400">Low</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Market Risk</span>
                              <span className="text-orange-400">Medium</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Investment Calculator */}
                      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                          <DollarSign className="h-5 w-5 mr-2 text-green-400" />
                          Investment Calculator
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-300 mb-2">
                                Investment Amount (USD)
                              </label>
                              <Input
                                type="number"
                                value={investmentAmount}
                                onChange={(e) => setInvestmentAmount(e.target.value)}
                                className="bg-gray-700 border-gray-600 text-white"
                                placeholder="Enter amount"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-300 mb-2">
                                Time Frame (Days)
                              </label>
                              <Select value={timeFrame} onValueChange={setTimeFrame}>
                                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent className="bg-gray-800 border-gray-600">
                                  <SelectItem value="30">30 Days</SelectItem>
                                  <SelectItem value="90">3 Months</SelectItem>
                                  <SelectItem value="180">6 Months</SelectItem>
                                  <SelectItem value="365">1 Year</SelectItem>
                                  <SelectItem value="730">2 Years</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          
                          <div className="space-y-3">
                            {(() => {
                              const principal = parseFloat(investmentAmount) || 0;
                              const apy = pool.apy || 0;
                              const days = parseInt(timeFrame) || 365;
                              const dailyRate = apy / 365 / 100;
                              const compoundedAmount = principal * Math.pow(1 + dailyRate, days);
                              const totalReturns = compoundedAmount - principal;
                              const monthlyReturns = totalReturns / (days / 30);
                              
                              return (
                                <>
                                  <div className="bg-gray-700/50 rounded-lg p-3 border border-gray-600">
                                    <div className="flex justify-between items-center">
                                      <span className="text-sm text-gray-400">Initial Investment</span>
                                      <span className="font-bold text-white">${principal.toLocaleString()}</span>
                                    </div>
                                  </div>
                                  <div className="bg-green-600/20 rounded-lg p-3 border border-green-500/30">
                                    <div className="flex justify-between items-center">
                                      <span className="text-sm text-green-300">Total Returns</span>
                                      <span className="font-bold text-green-400">${totalReturns.toLocaleString()}</span>
                                    </div>
                                  </div>
                                  <div className="bg-blue-600/20 rounded-lg p-3 border border-blue-500/30">
                                    <div className="flex justify-between items-center">
                                      <span className="text-sm text-blue-300">Final Amount</span>
                                      <span className="font-bold text-blue-400">${compoundedAmount.toLocaleString()}</span>
                                    </div>
                                  </div>
                                  <div className="bg-purple-600/20 rounded-lg p-3 border border-purple-500/30">
                                    <div className="flex justify-between items-center">
                                      <span className="text-sm text-purple-300">Monthly Returns</span>
                                      <span className="font-bold text-purple-400">${monthlyReturns.toLocaleString()}</span>
                                    </div>
                                  </div>
                                </>
                              );
                            })()}
                          </div>
                        </div>
                        
                        <div className="mt-4 p-3 bg-yellow-600/10 border border-yellow-500/30 rounded-lg">
                          <p className="text-xs text-yellow-200">
                            <strong>Note:</strong> Calculations assume constant APY and daily compounding. 
                            Actual returns may vary due to market conditions, fees, and other factors.
                          </p>
                        </div>
                      </div>

                      {/* Historical Performance */}
                      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                          <BarChart3 className="h-5 w-5 mr-2 text-cyan-400" />
                          Historical Performance
                        </h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-400 mb-1">
                              {(pool.apy * 0.95).toFixed(1)}%
                            </div>
                            <div className="text-sm text-gray-400">7D Avg APY</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-400 mb-1">
                              {(pool.apy * 1.1).toFixed(1)}%
                            </div>
                            <div className="text-sm text-gray-400">30D Avg APY</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-400 mb-1">
                              {formatCurrency(pool.tvl * 0.8)}
                            </div>
                            <div className="text-sm text-gray-400">7D Avg TVL</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-cyan-400 mb-1">
                              {formatCurrency(pool.volume24h * 7)}
                            </div>
                            <div className="text-sm text-gray-400">7D Volume</div>
                          </div>
                        </div>
                      </div>

                      {/* Advanced Analytics */}
                      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                          <Activity className="h-5 w-5 mr-2 text-orange-400" />
                          Advanced Metrics
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="bg-gray-700/30 rounded-lg p-3">
                            <div className="text-sm text-gray-400 mb-1">Sharpe Ratio</div>
                            <div className="text-xl font-bold text-green-400">{(pool.apy / 15).toFixed(2)}</div>
                            <div className="text-xs text-gray-500">Risk-adjusted return</div>
                          </div>
                          <div className="bg-gray-700/30 rounded-lg p-3">
                            <div className="text-sm text-gray-400 mb-1">Max Drawdown</div>
                            <div className="text-xl font-bold text-red-400">-{(Math.random() * 15 + 5).toFixed(1)}%</div>
                            <div className="text-xs text-gray-500">Worst performance period</div>
                          </div>
                          <div className="bg-gray-700/30 rounded-lg p-3">
                            <div className="text-sm text-gray-400 mb-1">Volatility</div>
                            <div className="text-xl font-bold text-yellow-400">{(Math.random() * 20 + 10).toFixed(1)}%</div>
                            <div className="text-xs text-gray-500">Price fluctuation measure</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
              <div className="text-xs text-gray-500">
                Last updated: {new Date().toLocaleTimeString()}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

const formatDisplayName = (name: string): string => {
  if (!name) return '';
  
  // Special cases for known brands that should keep specific capitalization
  const brandNames: Record<string, string> = {
    'aave': 'Aave',
    'uniswap': 'Uniswap',
    'compound': 'Compound',
    'curve': 'Curve',
    'sushiswap': 'SushiSwap',
    'pancakeswap': 'PancakeSwap',
    'yearn': 'Yearn',
    'balancer': 'Balancer',
    'convex': 'Convex',
    'morpho': 'Morpho',
    'ethereum': 'Ethereum',
    'polygon': 'Polygon',
    'bsc': 'BSC',
    'arbitrum': 'Arbitrum',
    'optimism': 'Optimism',
    'avalanche': 'Avalanche',
    'fantom': 'Fantom',
    'base': 'Base',
    'solana': 'Solana',
    'usdc': 'USDC',
    'usdt': 'USDT',
    'eth': 'ETH',
    'btc': 'BTC',
    'matic': 'MATIC',
    'bnb': 'BNB'
  };
  
  const lowerName = name.toLowerCase();
  if (brandNames[lowerName]) {
    return brandNames[lowerName];
  }
  
  // Fallback to title case
  return name.split(' ').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
  ).join(' ');
};

const determineCategory = (pool: any): string => {
  if (pool.category && pool.category.trim()) {
    return pool.category;
  }
  
  if (pool.protocol?.category && pool.protocol.category.trim()) {
    return pool.protocol.category;
  }
  
  const protocolName = (pool.protocol?.name || pool.protocol?.slug || '').toLowerCase();
  
  // Lending Protocols
  if (protocolName.includes('aave') || protocolName.includes('compound') || 
      protocolName.includes('morpho') || protocolName.includes('spark') ||
      protocolName.includes('lending') || protocolName.includes('borrow')) {
    return 'Lending';
  }
  
  // DEX/AMM Protocols
  if (protocolName.includes('uniswap') || protocolName.includes('sushiswap') ||
      protocolName.includes('curve') || protocolName.includes('pancake') ||
      protocolName.includes('dex') || protocolName.includes('swap') ||
      protocolName.includes('amm')) {
    return 'DEX';
  }
  
  // Yield Farming
  if (protocolName.includes('yearn') || protocolName.includes('convex') ||
      protocolName.includes('harvest') || protocolName.includes('farm') ||
      protocolName.includes('vault')) {
    return 'Yield';
  }
  
  // Liquid Staking
  if (protocolName.includes('lido') || protocolName.includes('rocket') ||
      protocolName.includes('staking') || protocolName.includes('stake')) {
    return 'Staking';
  }
  
  // Default category
  return 'DeFi';
};


