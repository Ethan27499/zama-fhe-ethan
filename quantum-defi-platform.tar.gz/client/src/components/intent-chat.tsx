import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Send, Bot, User, Sparkles, Brain, Zap } from 'lucide-react';

interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  status?: 'sending' | 'sent' | 'analyzing' | 'proposal_ready';
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: '1',
    type: 'ai',
    content: 'Hello! I\'m your Quantum AI Brain. I can help you find the best DeFi strategies across all chains. Just tell me what you want to achieve - like "I want to earn 15% APY with low risk" or "Help me maximize yield on my $10k USDC".',
    timestamp: new Date(),
    status: 'sent'
  }
];

const SUGGESTED_PROMPTS = [
  "I want to earn high yield on my stablecoins",
  "Find me the best farming opportunities with low risk", 
  "Help me maximize returns on 10 ETH",
  "I need MEV protection for my large trades",
  "Show me arbitrage opportunities across chains"
];

export default function IntentChat() {
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: content.trim(),
      timestamp: new Date(),
      status: 'sent'
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: `I'm analyzing your request: "${content}". Let me scan across 47 protocols on 8 chains to find the optimal strategy for you. This will take about 30 seconds...`,
        timestamp: new Date(),
        status: 'analyzing'
      };
      
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);

      // Simulate strategy analysis
      setTimeout(() => {
        const strategyResponse: ChatMessage = {
          id: (Date.now() + 2).toString(),
          type: 'ai',
          content: `Perfect! I found an optimal strategy for you:\n\n**Multi-Chain Yield Strategy**\n• 45% in Aave V3 on Arbitrum (8.2% APY)\n• 35% in Compound on Polygon (12.1% APY)\n• 20% in Curve on Ethereum (15.3% APY)\n\n**Expected returns:** 11.4% APY\n**Risk level:** Low-Medium\n**Gas optimization:** $23 total fees\n**MEV protection:** Enabled\n\nWould you like me to execute this strategy or show you alternatives?`,
          timestamp: new Date(),
          status: 'proposal_ready'
        };
        
        setMessages(prev => [...prev, strategyResponse]);
      }, 3000);
    }, 1000);
  };

  const handleSuggestedPrompt = (prompt: string) => {
    handleSendMessage(prompt);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-200px)] max-w-4xl mx-auto">
      {/* Chat Header */}
      <div className="quantum-border rounded-t-xl p-4 bg-gradient-to-r from-purple-500/10 to-blue-500/10">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 crypto-gradient rounded-full flex items-center justify-center quantum-glow">
            <Brain className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">Quantum AI Brain</h3>
            <p className="text-sm text-green-400 flex items-center">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2 quantum-pulse"></div>
              Online • Analyzing 47 protocols
            </p>
          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[var(--crypto-gray)] border-x border-gray-700">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex items-start space-x-3 ${
              message.type === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {message.type === 'ai' && (
              <div className="w-8 h-8 crypto-gradient rounded-full flex items-center justify-center flex-shrink-0 quantum-glow">
                <Bot className="h-4 w-4 text-white" />
              </div>
            )}
            
            <div
              className={`max-w-[80%] rounded-xl p-4 ${
                message.type === 'user'
                  ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white quantum-glow'
                  : 'quantum-border text-gray-100'
              }`}
            >
              <div className="whitespace-pre-wrap">{message.content}</div>
              
              {message.status === 'analyzing' && (
                <div className="mt-3 flex items-center space-x-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                  <span className="text-xs text-purple-400">AI Brain analyzing...</span>
                </div>
              )}
              
              {message.status === 'proposal_ready' && (
                <div className="mt-3 flex space-x-2">
                  <Button 
                    size="sm" 
                    className="crypto-gradient crypto-gradient-hover text-white"
                  >
                    <Zap className="mr-1 h-3 w-3" />
                    Execute Strategy
                  </Button>
                  <Button size="sm" variant="outline" className="border-gray-600 text-gray-300">
                    Show Alternatives
                  </Button>
                </div>
              )}
              
              <div className="mt-2 text-xs text-gray-400">
                {message.timestamp.toLocaleTimeString()}
              </div>
            </div>
            
            {message.type === 'user' && (
              <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center flex-shrink-0">
                <User className="h-4 w-4 text-white" />
              </div>
            )}
          </div>
        ))}
        
        {isTyping && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 crypto-gradient rounded-full flex items-center justify-center flex-shrink-0 quantum-glow">
              <Bot className="h-4 w-4 text-white" />
            </div>
            <div className="quantum-border rounded-xl p-4">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts */}
      {messages.length <= 1 && (
        <div className="p-4 border-x border-gray-700 bg-[var(--crypto-gray)]">
          <p className="text-sm text-gray-400 mb-3">Try asking:</p>
          <div className="flex flex-wrap gap-2">
            {SUGGESTED_PROMPTS.map((prompt, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handleSuggestedPrompt(prompt)}
                className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10 quantum-glow-hover"
              >
                <Sparkles className="mr-1 h-3 w-3" />
                {prompt}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="quantum-border rounded-b-xl p-4 bg-[var(--crypto-gray)]">
        <div className="flex space-x-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(inputValue)}
              placeholder="Describe your DeFi goals or ask for investment strategies..."
              className="w-full px-4 py-3 bg-[var(--crypto-light-gray)] border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          <Button
            onClick={() => handleSendMessage(inputValue)}
            disabled={!inputValue.trim() || isTyping}
            className="crypto-gradient crypto-gradient-hover text-white px-6 quantum-glow-hover"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}