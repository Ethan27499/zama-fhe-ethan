import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Brain, Send, User, Bot, Atom, Sparkles, Target } from 'lucide-react';

interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  analysis?: {
    language: string;
    fallacies: any[];
    confidence: number;
    processingTime: number;
  };
  metadata?: {
    sources: string[];
    warnings: string[];
  };
}

interface ChatInterfaceProps {
  className?: string;
}

export function ChatInterface({ className }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      type: 'ai',
      content: 'Xin chào! Tôi là Counter-Argument Engine của Quantum. Tôi có thể giúp bạn phân tích thông tin DeFi một cách khách quan và phát hiện các logical fallacies. Hãy chia sẻ suy nghĩ hoặc câu hỏi của bạn!',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user_${Date.now()}`,
      type: 'user',
      content: input.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input.trim();
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: currentInput
        })
      });

      const data = await response.json();
      
      const aiMessage: ChatMessage = {
        id: `ai_${Date.now()}`,
        type: 'ai',
        content: data.data.response,
        timestamp: new Date(),
        analysis: data.data.analysis,
        metadata: data.data.metadata
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Chat error:', error);
      const errorMessage: ChatMessage = {
        id: `error_${Date.now()}`,
        type: 'ai',
        content: 'Xin lỗi, có lỗi xảy ra khi xử lý tin nhắn của bạn. Vui lòng thử lại.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const quickActions = [
    "Bitcoin sẽ lên $100k năm nay",
    "DeFi có rủi ro hơn traditional finance",
    "Yield farming luôn sinh lời",
    "Smart contracts hoàn toàn an toàn"
  ];

  return (
    <div className={`${className} flex flex-col h-full max-h-screen`}>

      {/* Chat Messages */}
      <div className="flex-1 bg-[var(--crypto-gray)]/30 backdrop-blur-xl border border-blue-500/20 rounded-xl overflow-hidden">
        <ScrollArea ref={scrollAreaRef} className="h-full p-6">
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] ${
                  message.type === 'user' 
                    ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white' 
                    : 'bg-[var(--crypto-gray)]/80 text-gray-100 border border-blue-500/20'
                } rounded-2xl p-4 shadow-lg`}>
                  <div className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      message.type === 'user' 
                        ? 'bg-white/20' 
                        : 'crypto-gradient'
                    }`}>
                      {message.type === 'user' ? (
                        <User className="w-4 h-4" />
                      ) : (
                        <Brain className="w-4 h-4 text-white" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">
                        {message.content}
                      </p>
                      
                      {/* Analysis metadata for AI messages */}
                      {message.type === 'ai' && message.analysis && (
                        <div className="mt-3 pt-3 border-t border-blue-500/20">
                          <div className="flex gap-2 text-xs">
                            <Badge variant="outline" className="text-blue-300 border-blue-400/30">
                              {message.analysis.language}
                            </Badge>
                            <Badge variant="outline" className="text-green-300 border-green-400/30">
                              {Math.round(message.analysis.confidence * 100)}% confidence
                            </Badge>
                            <Badge variant="outline" className="text-purple-300 border-purple-400/30">
                              {message.analysis.processingTime}ms
                            </Badge>
                          </div>
                        </div>
                      )}
                      
                      {/* Warnings */}
                      {message.metadata?.warnings && message.metadata.warnings.length > 0 && (
                        <div className="mt-2 p-2 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                          <div className="flex items-center gap-2 text-xs text-yellow-300">
                            <AlertTriangle className="w-3 h-3" />
                            {message.metadata.warnings[0]}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {/* Loading indicator */}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-[var(--crypto-gray)]/80 border border-blue-500/20 rounded-2xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full crypto-gradient flex items-center justify-center">
                      <Brain className="w-4 h-4 text-white animate-pulse" />
                    </div>
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-100"></div>
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-200"></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Quick Actions */}
      <div className="mt-4 flex flex-wrap gap-2">
        {quickActions.map((action, index) => (
          <button
            key={index}
            onClick={() => setInput(action)}
            className="px-3 py-1 text-xs bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 rounded-lg text-blue-300 transition-all duration-200 hover:scale-105"
          >
            {action}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="mt-4 bg-[var(--crypto-gray)]/50 backdrop-blur-xl border border-blue-500/20 rounded-xl p-4">
        <div className="flex gap-3">
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Nhập tin nhắn của bạn... (hỗ trợ tiếng Việt và English)"
            className="flex-1 bg-[var(--crypto-dark-gray)] border-blue-500/30 text-white placeholder-gray-400 focus:border-blue-400"
            disabled={isLoading}
          />
          <Button
            onClick={sendMessage}
            disabled={!input.trim() || isLoading}
            className="crypto-gradient hover:opacity-90 transition-opacity"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="text-center text-xs text-gray-500 mt-2">
          Powered by OpenAI GPT-3.5, TensorFlow.js & Vietnamese NLP Engine
        </div>
      </div>
    </div>
  );
}