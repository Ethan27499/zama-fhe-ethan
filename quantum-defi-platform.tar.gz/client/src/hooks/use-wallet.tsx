import { useState, useEffect, useCallback, createContext, useContext } from 'react';
import type { WalletInfo, TokenBalance } from '@shared/types';
import { web3Service, SUPPORTED_NETWORKS, COMMON_TOKENS } from '@/lib/web3';
import { useToast } from '@/hooks/use-toast';

interface WalletContextType {
  wallet: WalletInfo | null;
  tokenBalances: TokenBalance[];
  isConnecting: boolean;
  connectWallet: () => Promise<void>;
  disconnect: () => void;
  switchNetwork: (chainId: number) => Promise<void>;
  refreshBalances: () => Promise<void>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [wallet, setWallet] = useState<WalletInfo | null>(null);
  const [tokenBalances, setTokenBalances] = useState<TokenBalance[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  const connectWallet = useCallback(async () => {
    setIsConnecting(true);
    try {
      const { address, chainId } = await web3Service.connectWallet();
      const balance = await web3Service.getBalance(address);
      
      const walletInfo: WalletInfo = {
        address,
        balance,
        chainId,
        isConnected: true,
      };
      
      setWallet(walletInfo);
      await loadTokenBalances(address, chainId);
      
      toast({
        title: "Wallet Connected",
        description: `Connected to ${address.slice(0, 6)}...${address.slice(-4)}`,
      });
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Failed to connect wallet",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  }, [toast]);

  const disconnect = useCallback(() => {
    web3Service.disconnect();
    setWallet(null);
    setTokenBalances([]);
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  }, [toast]);

  const switchNetwork = useCallback(async (chainId: number) => {
    try {
      await web3Service.switchNetwork(chainId);
      if (wallet) {
        const balance = await web3Service.getBalance(wallet.address);
        setWallet({ ...wallet, chainId, balance });
        await loadTokenBalances(wallet.address, chainId);
      }
      
      toast({
        title: "Network Switched",
        description: `Switched to ${SUPPORTED_NETWORKS[chainId]?.name || 'Unknown Network'}`,
      });
    } catch (error) {
      toast({
        title: "Network Switch Failed",
        description: error instanceof Error ? error.message : "Failed to switch network",
        variant: "destructive",
      });
    }
  }, [wallet, toast]);

  const loadTokenBalances = useCallback(async (address: string, chainId: number) => {
    const tokens = COMMON_TOKENS[chainId] || [];
    const balances: TokenBalance[] = [];

    for (const token of tokens) {
      try {
        const tokenBalance = await web3Service.getTokenBalance(token.address, address);
        balances.push({
          symbol: tokenBalance.symbol,
          balance: tokenBalance.balance,
          decimals: tokenBalance.decimals,
          address: token.address,
        });
      } catch (error) {
        console.warn(`Failed to load balance for ${token.symbol}:`, error);
      }
    }

    setTokenBalances(balances);
  }, []);

  const refreshBalances = useCallback(async () => {
    if (!wallet) return;
    
    try {
      const balance = await web3Service.getBalance(wallet.address);
      setWallet({ ...wallet, balance });
      await loadTokenBalances(wallet.address, wallet.chainId);
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh balances",
        variant: "destructive",
      });
    }
  }, [wallet, toast, loadTokenBalances]);

  // Check if wallet is already connected on mount
  useEffect(() => {
    const checkConnection = async () => {
      if (window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts.length > 0) {
            await connectWallet();
          }
        } catch (error) {
          console.warn('Failed to check existing connection:', error);
        }
      }
    };
    
    checkConnection();
  }, [connectWallet]);

  // Listen for account changes
  useEffect(() => {
    if (window.ethereum) {
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length === 0) {
          disconnect();
        } else if (wallet && accounts[0] !== wallet.address) {
          connectWallet();
        }
      };

      const handleChainChanged = (chainId: string) => {
        if (wallet) {
          const newChainId = parseInt(chainId, 16);
          switchNetwork(newChainId);
        }
      };

      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);

      return () => {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, [wallet, disconnect, connectWallet, switchNetwork]);

  const value: WalletContextType = {
    wallet,
    tokenBalances,
    isConnecting,
    connectWallet,
    disconnect,
    switchNetwork,
    refreshBalances,
  };

  return (
    <WalletContext.Provider value={value}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}
