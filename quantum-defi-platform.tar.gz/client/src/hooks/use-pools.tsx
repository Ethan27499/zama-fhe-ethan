import { useQuery, useInfiniteQuery } from '@tanstack/react-query';

export interface Pool {
  id: number;
  name: string;
  poolAddress: string;
  tokens: any[];
  apy: string | null;
  apr: string | null;
  tvl: string | null;
  volume24h: string | null;
  fees24h: string | null;
  poolType: string;
  riskScore: number;
  protocol: {
    name: string;
    category: string;
    logo?: string;
  };
  blockchain: {
    name: string;
    symbol: string;
  };
  metadata: any;
  createdAt: string;
  updatedAt: string;
}

export interface PoolFilters {
  chain?: string;
  category?: string;
  risk?: string;
  sortBy?: 'apy' | 'tvl' | 'volume';
  search?: string;
  limit?: number;
  offset?: number;
}

export function usePools(filters?: PoolFilters) {
  return useQuery({
    queryKey: ['/api/pools', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters?.chain) params.append('chain', filters.chain);
      if (filters?.category) params.append('category', filters.category);
      if (filters?.risk) params.append('risk', filters.risk);
      if (filters?.sortBy) params.append('sortBy', filters.sortBy);
      if (filters?.search) params.append('search', filters.search);
      if (filters?.limit) params.append('limit', filters.limit.toString());
      if (filters?.offset) params.append('offset', filters.offset.toString());

      const response = await fetch(`/api/pools?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch pools');
      }
      const data = await response.json();
      return data.pools as Pool[];
    },
    refetchInterval: 30000, // Refetch every 30 seconds for real-time updates
  });
}

export function useProtocols() {
  return useQuery({
    queryKey: ['/api/protocols'],
    queryFn: async () => {
      const response = await fetch('/api/protocols');
      if (!response.ok) {
        throw new Error('Failed to fetch protocols');
      }
      const data = await response.json();
      return data.protocols;
    },
    refetchInterval: 60000, // Refetch every minute
  });
}

export function useBlockchains() {
  return useQuery({
    queryKey: ['/api/blockchains'],
    queryFn: async () => {
      const response = await fetch('/api/blockchains');
      if (!response.ok) {
        throw new Error('Failed to fetch blockchains');
      }
      const data = await response.json();
      return data.blockchains;
    },
    refetchInterval: 60000,
  });
}

export function useStats() {
  return useQuery({
    queryKey: ['/api/stats'],
    queryFn: async () => {
      const response = await fetch('/api/stats');
      if (!response.ok) {
        throw new Error('Failed to fetch stats');
      }
      return await response.json();
    },
    refetchInterval: 10000, // Refetch every 10 seconds
  });
}

export function useSearchPools(query: string) {
  return useQuery({
    queryKey: ['/api/pools/search', query],
    queryFn: async () => {
      if (!query.trim()) return [];
      
      const response = await fetch(`/api/pools/search?q=${encodeURIComponent(query)}`);
      if (!response.ok) {
        throw new Error('Failed to search pools');
      }
      const data = await response.json();
      return data.pools as Pool[];
    },
    enabled: !!query.trim(),
  });
}