import { ethers } from 'ethers';
import type { NetworkConfig } from '@shared/types';

export const SUPPORTED_NETWORKS: Record<number, NetworkConfig> = {
  1: {
    chainId: 1,
    name: 'Ethereum',
    rpcUrl: 'https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161',
    blockExplorer: 'https://etherscan.io',
    nativeCurrency: {
      name: 'Ethereum',
      symbol: 'ETH',
      decimals: 18,
    },
    isSupported: true,
    type: 'evm',
  },
  42161: {
    chainId: 42161,
    name: 'Arbitrum',
    rpcUrl: 'https://arb1.arbitrum.io/rpc',
    blockExplorer: 'https://arbiscan.io',
    nativeCurrency: {
      name: 'Ethereum',
      symbol: 'ETH',
      decimals: 18,
    },
    isSupported: true,
    type: 'l2',
  },
  137: {
    chainId: 137,
    name: 'Polygon',
    rpcUrl: 'https://polygon-rpc.com',
    blockExplorer: 'https://polygonscan.com',
    nativeCurrency: {
      name: 'Polygon',
      symbol: 'MATIC',
      decimals: 18,
    },
    isSupported: true,
    type: 'sidechain',
  },
  10: {
    chainId: 10,
    name: 'Optimism',
    rpcUrl: 'https://mainnet.optimism.io',
    blockExplorer: 'https://optimistic.etherscan.io',
    nativeCurrency: {
      name: 'Ethereum',
      symbol: 'ETH',
      decimals: 18,
    },
    isSupported: true,
    type: 'l2',
  },
};

export const ERC20_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function totalSupply() view returns (uint256)',
  'function balanceOf(address owner) view returns (uint256)',
  'function transfer(address to, uint256 amount) returns (bool)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'event Transfer(address indexed from, address indexed to, uint256 value)',
  'event Approval(address indexed owner, address indexed spender, uint256 value)',
];

export const COMMON_TOKENS: Record<number, Array<{ symbol: string; address: string; decimals: number }>> = {
  1: [
    { symbol: 'USDC', address: '0xA0b86a33E6417c7fF2F65E54c19b1A86F5e27a8B', decimals: 6 },
    { symbol: 'USDT', address: '0xdAC17F958D2ee523a2206206994597C13D831ec7', decimals: 6 },
    { symbol: 'DAI', address: '0x6B175474E89094C44Da98b954EedeAC495271d0F', decimals: 18 },
  ],
  137: [
    { symbol: 'USDC', address: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', decimals: 6 },
    { symbol: 'USDT', address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', decimals: 6 },
    { symbol: 'DAI', address: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063', decimals: 18 },
  ],
};

export class Web3Service {
  private provider: ethers.BrowserProvider | null = null;
  private signer: ethers.JsonRpcSigner | null = null;

  async connectWallet(): Promise<{ address: string; chainId: number }> {
    if (!window.ethereum) {
      throw new Error('MetaMask is not installed');
    }

    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      await provider.send('eth_requestAccounts', []);
      
      const signer = await provider.getSigner();
      const address = await signer.getAddress();
      const network = await provider.getNetwork();

      this.provider = provider;
      this.signer = signer;

      return {
        address,
        chainId: Number(network.chainId),
      };
    } catch (error) {
      throw new Error(`Failed to connect wallet: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getBalance(address: string): Promise<string> {
    if (!this.provider) throw new Error('Wallet not connected');
    
    try {
      const balance = await this.provider.getBalance(address);
      return ethers.formatEther(balance);
    } catch (error) {
      throw new Error(`Failed to get balance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getTokenBalance(tokenAddress: string, walletAddress: string): Promise<{ balance: string; symbol: string; decimals: number }> {
    if (!this.provider) throw new Error('Wallet not connected');
    
    try {
      const contract = new ethers.Contract(tokenAddress, ERC20_ABI, this.provider);
      
      const [balance, symbol, decimals] = await Promise.all([
        contract.balanceOf(walletAddress),
        contract.symbol(),
        contract.decimals(),
      ]);

      return {
        balance: ethers.formatUnits(balance, decimals),
        symbol,
        decimals,
      };
    } catch (error) {
      throw new Error(`Failed to get token balance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async sendTransaction(to: string, amount: string): Promise<string> {
    if (!this.signer) throw new Error('Wallet not connected');
    
    try {
      const tx = await this.signer.sendTransaction({
        to,
        value: ethers.parseEther(amount),
      });

      return tx.hash;
    } catch (error) {
      throw new Error(`Failed to send transaction: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async sendTokens(tokenAddress: string, to: string, amount: string, decimals: number): Promise<string> {
    if (!this.signer) throw new Error('Wallet not connected');
    
    try {
      const contract = new ethers.Contract(tokenAddress, ERC20_ABI, this.signer);
      const tx = await contract.transfer(to, ethers.parseUnits(amount, decimals));
      
      return tx.hash;
    } catch (error) {
      throw new Error(`Failed to send tokens: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async callContractFunction(contractAddress: string, abi: string[], functionName: string, params: any[]): Promise<any> {
    if (!this.provider) throw new Error('Wallet not connected');
    
    try {
      const contract = new ethers.Contract(contractAddress, abi, this.provider);
      const result = await contract[functionName](...params);
      
      return result;
    } catch (error) {
      throw new Error(`Failed to call contract function: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async executeContractFunction(contractAddress: string, abi: string[], functionName: string, params: any[]): Promise<string> {
    if (!this.signer) throw new Error('Wallet not connected');
    
    try {
      const contract = new ethers.Contract(contractAddress, abi, this.signer);
      const tx = await contract[functionName](...params);
      
      return tx.hash;
    } catch (error) {
      throw new Error(`Failed to execute contract function: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async switchNetwork(chainId: number): Promise<void> {
    if (!window.ethereum) throw new Error('MetaMask is not installed');
    
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${chainId.toString(16)}` }],
      });
    } catch (error: any) {
      if (error.code === 4902) {
        const network = SUPPORTED_NETWORKS[chainId];
        if (network) {
          await this.addNetwork(network);
        }
      } else {
        throw new Error(`Failed to switch network: ${error.message}`);
      }
    }
  }

  private async addNetwork(network: NetworkConfig): Promise<void> {
    if (!window.ethereum) throw new Error('MetaMask is not installed');
    
    await window.ethereum.request({
      method: 'wallet_addEthereumChain',
      params: [{
        chainId: `0x${network.chainId.toString(16)}`,
        chainName: network.name,
        rpcUrls: [network.rpcUrl],
        blockExplorerUrls: [network.blockExplorer],
        nativeCurrency: network.nativeCurrency,
      }],
    });
  }

  disconnect(): void {
    this.provider = null;
    this.signer = null;
  }
}

export const web3Service = new Web3Service();

declare global {
  interface Window {
    ethereum?: any;
  }
}
