import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, decimal, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Blockchain networks table
export const blockchains = pgTable('blockchains', {
  id: integer('id').primaryKey().generatedAlwaysAsIdentity(),
  name: text('name').notNull(),
  chainId: integer('chain_id').notNull().unique(),
  symbol: text('symbol').notNull(),
  rpcUrl: text('rpc_url').notNull(),
  explorerUrl: text('explorer_url'),
  logoUrl: text('logo_url'),
  isActive: boolean('is_active').default(true),
  tvl: decimal('tvl', { precision: 20, scale: 2 }).default('0'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// DeFi protocols table
export const protocols = pgTable('protocols', {
  id: integer('id').primaryKey().generatedAlwaysAsIdentity(),
  name: text('name').notNull(),
  slug: text('slug').notNull().unique(),
  website: text('website'),
  logo: text('logo'),
  logoUrl: text('logo_url'),
  description: text('description'),
  category: text('category').notNull(), // 'DEX', 'Lending', 'Staking', etc.
  tvl: decimal('tvl', { precision: 20, scale: 2 }).default('0'),
  volume24h: decimal('volume_24h', { precision: 20, scale: 2 }).default('0'),
  fees24h: decimal('fees_24h', { precision: 20, scale: 2 }).default('0'),
  isVerified: boolean('is_verified').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// DeFi pools table
export const pools = pgTable('pools', {
  id: integer('id').primaryKey().generatedAlwaysAsIdentity(),
  protocolId: integer('protocol_id').notNull().references(() => protocols.id),
  blockchainId: integer('blockchain_id').notNull().references(() => blockchains.id),
  poolAddress: text('pool_address').notNull(),
  name: text('name').notNull(),
  tokens: jsonb('tokens').notNull(), // Array of token objects
  apy: decimal('apy', { precision: 8, scale: 4 }).default('0'),
  apr: decimal('apr', { precision: 8, scale: 4 }).default('0'),
  tvl: decimal('tvl', { precision: 20, scale: 2 }).default('0'),
  volume24h: decimal('volume_24h', { precision: 20, scale: 2 }).default('0'),
  fees24h: decimal('fees_24h', { precision: 20, scale: 2 }).default('0'),
  poolType: text('pool_type').notNull(), // 'liquidity', 'lending', 'farming', etc.
  riskScore: integer('risk_score').default(5), // 1-10 scale
  isActive: boolean('is_active').default(true),
  metadata: jsonb('metadata'), // Additional pool-specific data
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  poolAddressIdx: index('pool_address_idx').on(table.poolAddress),
  protocolIdx: index('protocol_idx').on(table.protocolId),
  blockchainIdx: index('blockchain_idx').on(table.blockchainId),
  tvlIdx: index('tvl_idx').on(table.tvl),
}));

// Token information table
export const tokens = pgTable('tokens', {
  id: integer('id').primaryKey().generatedAlwaysAsIdentity(),
  address: text('address').notNull(),
  blockchainId: integer('blockchain_id').notNull().references(() => blockchains.id),
  symbol: text('symbol').notNull(),
  name: text('name').notNull(),
  decimals: integer('decimals').notNull(),
  logo: text('logo'),
  price: decimal('price', { precision: 20, scale: 8 }).default('0'),
  marketCap: decimal('market_cap', { precision: 20, scale: 2 }).default('0'),
  volume24h: decimal('volume_24h', { precision: 20, scale: 2 }).default('0'),
  priceChange24h: decimal('price_change_24h', { precision: 8, scale: 4 }).default('0'),
  isVerified: boolean('is_verified').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  addressIdx: index('token_address_idx').on(table.address),
  symbolIdx: index('token_symbol_idx').on(table.symbol),
  blockchainTokenIdx: index('blockchain_token_idx').on(table.blockchainId, table.address),
}));

// Historical data for pools
export const poolHistory = pgTable('pool_history', {
  id: integer('id').primaryKey().generatedAlwaysAsIdentity(),
  poolId: integer('pool_id').notNull().references(() => pools.id),
  apy: decimal('apy', { precision: 8, scale: 4 }),
  tvl: decimal('tvl', { precision: 20, scale: 2 }),
  volume24h: decimal('volume_24h', { precision: 20, scale: 2 }),
  timestamp: timestamp('timestamp').notNull(),
}, (table) => ({
  poolTimestampIdx: index('pool_timestamp_idx').on(table.poolId, table.timestamp),
}));

// API data sources configuration
export const dataSources = pgTable('data_sources', {
  id: integer('id').primaryKey().generatedAlwaysAsIdentity(),
  name: text('name').notNull(),
  apiKey: text('api_key'),
  baseUrl: text('base_url').notNull(),
  isActive: boolean('is_active').default(true),
  rateLimit: integer('rate_limit').default(100), // requests per minute
  lastSync: timestamp('last_sync'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertBlockchainSchema = createInsertSchema(blockchains, { 
  tvl: z.string().optional(),
}).omit({ 
  id: true, 
  createdAt: true,
  updatedAt: true 
});

export const insertProtocolSchema = createInsertSchema(protocols, {
  tvl: z.string().optional(),
  volume24h: z.string().optional(),
  fees24h: z.string().optional(),
}).omit({ 
  id: true, 
  createdAt: true,
  updatedAt: true 
});

export const insertPoolSchema = createInsertSchema(pools, {
  apy: z.string().optional(),
  apr: z.string().optional(),
  tvl: z.string().optional(),
  volume24h: z.string().optional(),
  fees24h: z.string().optional(),
}).omit({ 
  id: true, 
  createdAt: true,
  updatedAt: true 
});

export const insertTokenSchema = createInsertSchema(tokens, {
  price: z.string().optional(),
  marketCap: z.string().optional(),
  volume24h: z.string().optional(),
  priceChange24h: z.string().optional(),
}).omit({ 
  id: true, 
  createdAt: true,
  updatedAt: true 
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Blockchain = typeof blockchains.$inferSelect;
export type InsertBlockchain = z.infer<typeof insertBlockchainSchema>;

export type Protocol = typeof protocols.$inferSelect;
export type InsertProtocol = z.infer<typeof insertProtocolSchema>;

export type Pool = typeof pools.$inferSelect;
export type InsertPool = z.infer<typeof insertPoolSchema>;

export type Token = typeof tokens.$inferSelect;
export type InsertToken = z.infer<typeof insertTokenSchema>;

export type PoolHistory = typeof poolHistory.$inferSelect;
export type DataSource = typeof dataSources.$inferSelect;
