export interface WalletInfo {
  address: string;
  balance: string;
  chainId: number;
  isConnected: boolean;
}

export interface TokenBalance {
  symbol: string;
  balance: string;
  decimals: number;
  address?: string;
  usdValue?: string;
}

export interface Intent {
  id: string;
  type: 'maximize_yield' | 'safe_farming' | 'arbitrage' | 'custom';
  description: string;
  amount: string;
  token: string;
  riskLevel: 'low' | 'medium' | 'high';
  targetAPY?: string;
  duration?: string;
  status: 'pending' | 'analyzing' | 'proposal_ready' | 'executing' | 'active' | 'completed' | 'failed';
  timestamp: number;
}

export interface AIStrategy {
  id: string;
  intentId: string;
  name: string;
  description: string;
  expectedAPY: string;
  riskScore: number;
  protocols: string[];
  chains: string[];
  steps: StrategyStep[];
  mevOpportunity?: MEVOpportunity;
  confidence: number;
  estimatedGas: string;
}

export interface StrategyStep {
  action: 'deposit' | 'stake' | 'farm' | 'swap' | 'bridge';
  protocol: string;
  chain: string;
  amount: string;
  token: string;
  estimatedReturn: string;
}

export interface MEVOpportunity {
  type: 'arbitrage' | 'sandwich' | 'liquidation';
  estimatedProfit: string;
  confidence: number;
  description: string;
}

export interface QuantumVault {
  totalTVL: string;
  totalUsers: number;
  aParameter: number;
  currentAPY: string;
  mevCaptured24h: string;
  securityScore: number;
  activeStrategies: number;
  supportedChains: string[];
}

export interface Transaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  gasUsed: string;
  gasPrice: string;
  timestamp: number;
  status: 'pending' | 'success' | 'failed';
  type: 'intent_execution' | 'rebalance' | 'mev_capture' | 'deposit' | 'withdraw';
  symbol?: string;
  intentId?: string;
}

export interface NetworkConfig {
  chainId: number;
  name: string;
  rpcUrl: string;
  blockExplorer: string;
  nativeCurrency: {
    name: string;
    symbol: string;
    decimals: number;
  };
  isSupported: boolean;
  type: 'evm' | 'non-evm' | 'l2' | 'sidechain';
}
