import { Router } from 'express';
import { counterArgumentEngine } from '../ai/index';

const router = Router();

// Chat endpoint for Counter-Argument Engine
router.post('/api/chat', async (req, res) => {
  try {
    const { message, sessionId } = req.body;
    
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ 
        error: 'Message is required and must be a string' 
      });
    }

    const startTime = Date.now();
    
    // Process user input through Counter-Argument Engine
    const result = await counterArgumentEngine.processUserInput(message);
    
    const responseTime = Date.now() - startTime;
    
    res.json({
      success: true,
      data: {
        response: result.response,
        analysis: {
          language: result.analysis.language,
          fallacies: result.analysis.fallacies,
          confidence: result.analysis.confidence,
          processingTime: responseTime
        },
        metadata: {
          sources: result.metadata.sources,
          warnings: result.metadata.warnings,
          sessionId: sessionId || `session_${Date.now()}`
        }
      }
    });
    
  } catch (error) {
    console.error('Chat API error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error',
      message: 'Xin lỗi, tôi gặp sự cố khi xử lý tin nhắn của bạn. Vui lòng thử lại.'
    });
  }
});

// Health check for Counter-Argument Engine
router.get('/api/chat/health', async (req, res) => {
  try {
    const health = await counterArgumentEngine.healthCheck();
    res.json({
      success: true,
      data: health
    });
  } catch (error) {
    console.error('Health check error:', error);
    res.status(500).json({
      success: false,
      error: 'Health check failed'
    });
  }
});

// Get chat history (placeholder for future implementation)
router.get('/api/chat/history/:sessionId', async (req, res) => {
  const { sessionId } = req.params;
  
  // For now, return empty history
  // In production, this would fetch from database
  res.json({
    success: true,
    data: {
      sessionId,
      messages: [],
      totalMessages: 0
    }
  });
});

export default router;