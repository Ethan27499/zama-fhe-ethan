import { db } from './db';
import { blockchains, protocols, pools, tokens } from '@shared/schema';
import { eq, sql } from 'drizzle-orm';

// DeFi data aggregation service
export class DataFetcher {
  private isRunning = false;
  private updateInterval = 30000; // 30 seconds

  constructor() {
    this.initializeDataSources();
  }

  async initializeDataSources() {
    // Initialize major blockchain networks
    await this.seedBlockchains();
    // Start real-time data fetching
    this.startDataFetching();
  }

  private async seedBlockchains() {
    const chainsData = [
      // Major EVM Chains
      { name: 'Ethereum', chainId: 1, symbol: 'ETH', rpcUrl: 'https://eth.llamarpc.com', explorerUrl: 'https://etherscan.io' },
      { name: 'Polygon', chainId: 137, symbol: 'MATIC', rpcUrl: 'https://polygon.llamarpc.com', explorerUrl: 'https://polygonscan.com' },
      { name: 'BSC', chainId: 56, symbol: 'BNB', rpcUrl: 'https://bsc.llamarpc.com', explorerUrl: 'https://bscscan.com' },
      { name: 'Arbitrum', chainId: 42161, symbol: 'ETH', rpcUrl: 'https://arbitrum.llamarpc.com', explorerUrl: 'https://arbiscan.io' },
      { name: 'Optimism', chainId: 10, symbol: 'ETH', rpcUrl: 'https://optimism.llamarpc.com', explorerUrl: 'https://optimistic.etherscan.io' },
      { name: 'Avalanche', chainId: 43114, symbol: 'AVAX', rpcUrl: 'https://avalanche.drpc.org', explorerUrl: 'https://snowtrace.io' },
      { name: 'Fantom', chainId: 250, symbol: 'FTM', rpcUrl: 'https://fantom.drpc.org', explorerUrl: 'https://ftmscan.com' },
      { name: 'Base', chainId: 8453, symbol: 'ETH', rpcUrl: 'https://base.llamarpc.com', explorerUrl: 'https://basescan.org' },
      
      // Layer 2s and Alt L1s
      { name: 'Solana', chainId: 101, symbol: 'SOL', rpcUrl: 'https://api.mainnet-beta.solana.com', explorerUrl: 'https://solscan.io' },
      { name: 'Cosmos', chainId: 118, symbol: 'ATOM', rpcUrl: 'https://api.cosmos.network', explorerUrl: 'https://mintscan.io' },
      { name: 'Near', chainId: 397, symbol: 'NEAR', rpcUrl: 'https://rpc.mainnet.near.org', explorerUrl: 'https://nearblocks.io' },
      { name: 'Cardano', chainId: 1815, symbol: 'ADA', rpcUrl: 'https://api.mainnet.cardano.org', explorerUrl: 'https://cardanoscan.io' },
      { name: 'Polkadot', chainId: 0, symbol: 'DOT', rpcUrl: 'https://rpc.polkadot.io', explorerUrl: 'https://polkadot.subscan.io' },
      { name: 'Kusama', chainId: 2, symbol: 'KSM', rpcUrl: 'https://kusama-rpc.polkadot.io', explorerUrl: 'https://kusama.subscan.io' },
      { name: 'Algorand', chainId: 416001, symbol: 'ALGO', rpcUrl: 'https://mainnet-api.algonode.cloud', explorerUrl: 'https://algoexplorer.io' },
      
      // Additional major chains
      { name: 'Sui', chainId: 101102, symbol: 'SUI', rpcUrl: 'https://fullnode.mainnet.sui.io', explorerUrl: 'https://suivision.xyz' },
      { name: 'Aptos', chainId: 101103, symbol: 'APT', rpcUrl: 'https://api.mainnet.aptoslabs.com', explorerUrl: 'https://aptoscan.com' },
      { name: 'Hedera', chainId: 295, symbol: 'HBAR', rpcUrl: 'https://mainnet.hashio.io/api', explorerUrl: 'https://hashscan.io' },
      { name: 'TRON', chainId: 728126428, symbol: 'TRX', rpcUrl: 'https://api.trongrid.io', explorerUrl: 'https://tronscan.org' },
      { name: 'Cronos', chainId: 25, symbol: 'CRO', rpcUrl: 'https://evm.cronos.org', explorerUrl: 'https://cronoscan.com' },
      
      // More Layer 2s and Sidechains
      { name: 'Gnosis', chainId: 100, symbol: 'XDAI', rpcUrl: 'https://rpc.gnosischain.com', explorerUrl: 'https://gnosisscan.io' },
      { name: 'Moonbeam', chainId: 1284, symbol: 'GLMR', rpcUrl: 'https://rpc.api.moonbeam.network', explorerUrl: 'https://moonscan.io' },
      { name: 'Moonriver', chainId: 1285, symbol: 'MOVR', rpcUrl: 'https://rpc.api.moonriver.moonbeam.network', explorerUrl: 'https://moonriver.moonscan.io' },
      { name: 'Harmony', chainId: 1666600000, symbol: 'ONE', rpcUrl: 'https://api.harmony.one', explorerUrl: 'https://explorer.harmony.one' },
      { name: 'KCC', chainId: 321, symbol: 'KCS', rpcUrl: 'https://rpc-mainnet.kcc.network', explorerUrl: 'https://explorer.kcc.io' },
      { name: 'OKC', chainId: 66, symbol: 'OKT', rpcUrl: 'https://exchainrpc.okex.org', explorerUrl: 'https://www.oklink.com/en/okc' },
      { name: 'Heco', chainId: 128, symbol: 'HT', rpcUrl: 'https://http-mainnet.hecochain.com', explorerUrl: 'https://hecoinfo.com' },
      { name: 'Celo', chainId: 42220, symbol: 'CELO', rpcUrl: 'https://forno.celo.org', explorerUrl: 'https://explorer.celo.org' },
      { name: 'Aurora', chainId: 1313161554, symbol: 'ETH', rpcUrl: 'https://mainnet.aurora.dev', explorerUrl: 'https://aurorascan.dev' },
      { name: 'Boba', chainId: 288, symbol: 'ETH', rpcUrl: 'https://mainnet.boba.network', explorerUrl: 'https://bobascan.com' },
      { name: 'Metis', chainId: 1088, symbol: 'METIS', rpcUrl: 'https://andromeda.metis.io', explorerUrl: 'https://andromeda-explorer.metis.io' },
      { name: 'Milkomeda', chainId: 2001, symbol: 'milkADA', rpcUrl: 'https://rpc-mainnet-cardano-evm.c1.milkomeda.com', explorerUrl: 'https://explorer-mainnet-cardano-evm.c1.milkomeda.com' },
      { name: 'Fuse', chainId: 122, symbol: 'FUSE', rpcUrl: 'https://rpc.fuse.io', explorerUrl: 'https://explorer.fuse.io' },
      { name: 'Velas', chainId: 106, symbol: 'VLX', rpcUrl: 'https://evmexplorer.velas.com/rpc', explorerUrl: 'https://evmexplorer.velas.com' },
      
      // Additional Layer 1s
      { name: 'IoTeX', chainId: 4689, symbol: 'IOTX', rpcUrl: 'https://babel-api.mainnet.iotex.io', explorerUrl: 'https://iotexscan.io' },
      { name: 'Kava', chainId: 2222, symbol: 'KAVA', rpcUrl: 'https://evm.kava.io', explorerUrl: 'https://explorer.kava.io' },
      { name: 'Telos', chainId: 40, symbol: 'TLOS', rpcUrl: 'https://mainnet.telos.net/evm', explorerUrl: 'https://teloscan.io' },
      { name: 'Klaytn', chainId: 8217, symbol: 'KLAY', rpcUrl: 'https://cypress.klaytn.com', explorerUrl: 'https://scope.klaytn.com' },
      { name: 'Secret', chainId: 132902, symbol: 'SCRT', rpcUrl: 'https://api.secretnetwork.io', explorerUrl: 'https://secretnodes.com' },
      { name: 'Osmosis', chainId: 132903, symbol: 'OSMO', rpcUrl: 'https://rpc.osmosis.zone', explorerUrl: 'https://www.mintscan.io/osmosis' },
      { name: 'Juno', chainId: 132904, symbol: 'JUNO', rpcUrl: 'https://rpc-juno.cosmostation.io', explorerUrl: 'https://www.mintscan.io/juno' },
      { name: 'Terra', chainId: 132905, symbol: 'LUNA', rpcUrl: 'https://lcd.terra.dev', explorerUrl: 'https://finder.terra.money' },
      { name: 'Injective', chainId: 132906, symbol: 'INJ', rpcUrl: 'https://public.api.injective.network', explorerUrl: 'https://explorer.injective.network' },
      { name: 'Stargaze', chainId: 132907, symbol: 'STARS', rpcUrl: 'https://rpc.stargaze-apis.com', explorerUrl: 'https://www.mintscan.io/stargaze' },
      
      // Additional EVM Compatible Chains
      { name: 'Evmos', chainId: 9001, symbol: 'EVMOS', rpcUrl: 'https://eth.bd.evmos.org:8545', explorerUrl: 'https://evm.evmos.org' },
      { name: 'Canto', chainId: 7700, symbol: 'CANTO', rpcUrl: 'https://canto.slingshot.finance', explorerUrl: 'https://evm.canto.io' },
      { name: 'Theta', chainId: 361, symbol: 'TFUEL', rpcUrl: 'https://eth-rpc-api.thetatoken.org/rpc', explorerUrl: 'https://explorer.thetatoken.org' },
      { name: 'Syscoin', chainId: 57, symbol: 'SYS', rpcUrl: 'https://rpc.syscoin.org', explorerUrl: 'https://explorer.syscoin.org' },
      { name: 'Wanchain', chainId: 888, symbol: 'WAN', rpcUrl: 'https://gwan-ssl.wandevs.org:56891', explorerUrl: 'https://wanscan.org' },
      { name: 'ThunderCore', chainId: 108, symbol: 'TT', rpcUrl: 'https://mainnet-rpc.thundercore.com', explorerUrl: 'https://scan.thundercore.com' },
      { name: 'TomoChain', chainId: 88, symbol: 'TOMO', rpcUrl: 'https://rpc.tomochain.com', explorerUrl: 'https://scan.tomochain.com' },
      { name: 'Elastos', chainId: 20, symbol: 'ELA', rpcUrl: 'https://api.elastos.io/eth', explorerUrl: 'https://esc.elastos.io' },
      { name: 'EnergyWeb', chainId: 246, symbol: 'EWT', rpcUrl: 'https://rpc.energyweb.org', explorerUrl: 'https://explorer.energyweb.org' },
      { name: 'Songbird', chainId: 19, symbol: 'SGB', rpcUrl: 'https://songbird-api.flare.network/ext/C/rpc', explorerUrl: 'https://songbird-explorer.flare.network' },
      { name: 'Flare', chainId: 14, symbol: 'FLR', rpcUrl: 'https://flare-api.flare.network/ext/C/rpc', explorerUrl: 'https://flare-explorer.flare.network' },
      { name: 'Godwoken', chainId: 71402, symbol: 'CKB', rpcUrl: 'https://v1.mainnet.godwoken.io/rpc', explorerUrl: 'https://v1.gwscan.com' },
      { name: 'Smartchain', chainId: 56001, symbol: 'BNB', rpcUrl: 'https://bsc-dataseed.binance.org', explorerUrl: 'https://bscscan.com' },
      
      // Additional Testnets and Development Chains
      { name: 'Ropsten', chainId: 3, symbol: 'ETH', rpcUrl: 'https://ropsten.infura.io/v3/', explorerUrl: 'https://ropsten.etherscan.io' },
      { name: 'Rinkeby', chainId: 4, symbol: 'ETH', rpcUrl: 'https://rinkeby.infura.io/v3/', explorerUrl: 'https://rinkeby.etherscan.io' },
      { name: 'Goerli', chainId: 5, symbol: 'ETH', rpcUrl: 'https://goerli.infura.io/v3/', explorerUrl: 'https://goerli.etherscan.io' },
      { name: 'Kovan', chainId: 42, symbol: 'ETH', rpcUrl: 'https://kovan.infura.io/v3/', explorerUrl: 'https://kovan.etherscan.io' },
      { name: 'Mumbai', chainId: 80001, symbol: 'MATIC', rpcUrl: 'https://rpc-mumbai.maticvigil.com', explorerUrl: 'https://mumbai.polygonscan.com' },
      { name: 'Sepolia', chainId: 11155111, symbol: 'ETH', rpcUrl: 'https://sepolia.infura.io/v3/', explorerUrl: 'https://sepolia.etherscan.io' },
      
      // More experimental and new chains
      { name: 'Shiden', chainId: 336, symbol: 'SDN', rpcUrl: 'https://shiden.api.onfinality.io/public', explorerUrl: 'https://shiden.subscan.io' },
      { name: 'Astar', chainId: 592, symbol: 'ASTR', rpcUrl: 'https://astar.api.onfinality.io/public', explorerUrl: 'https://astar.subscan.io' },
      { name: 'Acala', chainId: 787, symbol: 'ACA', rpcUrl: 'https://eth-rpc-acala.aca-api.network', explorerUrl: 'https://acala.subscan.io' },
      { name: 'Karura', chainId: 686, symbol: 'KAR', rpcUrl: 'https://eth-rpc-karura.aca-api.network', explorerUrl: 'https://karura.subscan.io' },
      { name: 'Bifrost', chainId: 49088, symbol: 'BNC', rpcUrl: 'https://hk.p.bifrost-rpc.liebi.com', explorerUrl: 'https://bifrost.subscan.io' },
    ];

    for (const chainData of chainsData) {
      try {
        const existing = await db.select().from(blockchains).where(eq(blockchains.chainId, chainData.chainId)).limit(1);
        if (existing.length === 0) {
          await db.insert(blockchains).values(chainData);
          console.log(`✓ Added blockchain: ${chainData.name}`);
        }
      } catch (error) {
        console.error(`Error seeding blockchain ${chainData.name}:`, error);
      }
    }
  }

  // Fetch data from CoinGecko DEX API
  async fetchCoinGeckoData() {
    try {
      // Get trending pools from multiple networks
      const networks = ['eth', 'polygon_pos', 'arbitrum_one', 'optimistic_ethereum', 'base', 'avalanche_c_chain'];
      
      for (const network of networks) {
        const response = await fetch(`https://api.geckoterminal.com/api/v2/networks/${network}/trending_pools`);
        if (!response.ok) continue;
        
        const data = await response.json();
        await this.processCoinGeckoPoolData(data.data, network);
        
        // Rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    } catch (error) {
      console.error('Error fetching CoinGecko data:', error);
    }
  }

  private async processCoinGeckoPoolData(poolsData: any[], networkName: string) {
    for (const poolData of poolsData) {
      try {
        const attributes = poolData.attributes;
        const tokens = poolData.relationships?.tokens?.data || [];
        
        // Find or create protocol
        let protocol = await db.select().from(protocols)
          .where(eq(protocols.slug, attributes.dex_id))
          .limit(1);
        
        if (protocol.length === 0) {
          try {
            // Validate required fields
            if (!attributes.dex_id) continue;
            
            const newProtocol = await db.insert(protocols).values({
              name: attributes.dex_id,
              slug: attributes.dex_id,
              category: 'DEX',
              isVerified: true,
            }).returning();
            protocol = newProtocol;
          } catch (error) {
            // If duplicate, try to fetch again - silent handling  
            protocol = await db.select().from(protocols)
              .where(eq(protocols.slug, attributes.dex_id))
              .limit(1);
            if (protocol.length === 0) continue; // Skip this pool silently
          }
        }

        // Find blockchain
        const blockchain = await db.select().from(blockchains)
          .where(eq(blockchains.name, this.mapNetworkName(networkName)))
          .limit(1);

        if (blockchain.length === 0) continue;

        // Create or update pool
        const poolTokens = tokens.map((t: any) => ({
          address: t.id,
          symbol: t.attributes?.symbol || 'UNKNOWN',
          name: t.attributes?.name || 'Unknown Token'
        }));

        const poolEntry = {
          protocolId: protocol[0].id,
          blockchainId: blockchain[0].id,
          poolAddress: poolData.id,
          name: attributes.name,
          tokens: poolTokens,
          tvl: attributes.reserve_in_usd || '0',
          volume24h: attributes.volume_usd?.h24 || '0',
          poolType: 'liquidity',
          riskScore: this.calculateRiskScore(attributes),
          metadata: {
            fdv_usd: attributes.fdv_usd,
            market_cap_usd: attributes.market_cap_usd,
            price_change_percentage: attributes.price_change_percentage
          }
        };

        // Check if pool exists
        const existingPool = await db.select().from(pools)
          .where(eq(pools.poolAddress, poolData.id))
          .limit(1);

        if (existingPool.length === 0) {
          await db.insert(pools).values(poolEntry);
        } else {
          await db.update(pools)
            .set({
              tvl: poolEntry.tvl,
              volume24h: poolEntry.volume24h,
              updatedAt: new Date(),
            })
            .where(eq(pools.poolAddress, poolData.id));
        }

      } catch (error) {
        // Only log non-duplicate errors
        if (!error.message?.includes('duplicate key value violates unique constraint') && 
            !error.message?.includes('null value in column')) {
          console.error('Error processing pool data:', error);
        }
      }
    }
  }

  // Fetch data from DeFiLlama API
  async fetchDeFiLlamaData() {
    try {
      // Get all protocols
      const protocolsResponse = await fetch('https://api.llama.fi/protocols');
      if (!protocolsResponse.ok) return;
      
      const protocolsData = await protocolsResponse.json();
      
      for (const protocolData of protocolsData.slice(0, 100)) { // Limit to top 100
        try {
          // Find or create protocol
          let protocol = await db.select().from(protocols)
            .where(eq(protocols.slug, protocolData.slug))
            .limit(1);
          
          if (protocol.length === 0) {
            try {
              const newProtocol = await db.insert(protocols).values({
                name: protocolData.name,
                slug: protocolData.slug,
                website: protocolData.url,
                logo: protocolData.logo,
                description: protocolData.description,
                category: protocolData.category || 'Unknown',
                tvl: protocolData.tvl?.toString() || '0',
                isVerified: true,
              }).returning();
              protocol = newProtocol;
            } catch (error) {
              // If duplicate, try to fetch again - silent handling
              protocol = await db.select().from(protocols)
                .where(eq(protocols.slug, protocolData.slug))
                .limit(1);
              if (protocol.length === 0) continue;
            }
          } else {
            // Update TVL
            await db.update(protocols)
              .set({
                tvl: protocolData.tvl?.toString() || '0',
                updatedAt: new Date(),
              })
              .where(eq(protocols.id, protocol[0].id));
          }

        } catch (error) {
          // Only log non-duplicate errors
          if (!error.message?.includes('duplicate key value violates unique constraint')) {
            console.error('Error processing protocol:', error);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching DeFiLlama data:', error);
    }
  }

  // Fetch yield farming data from multiple sources
  async fetchYieldData() {
    try {
      // Get yield pools from DeFiLlama
      const yieldsResponse = await fetch('https://yields.llama.fi/pools');
      if (!yieldsResponse.ok) return;
      
      const yieldsData = await yieldsResponse.json();
      
      for (const yieldPool of yieldsData.data.slice(0, 500)) { // Top 500 pools
        try {
          // Find blockchain
          const blockchain = await db.select().from(blockchains)
            .where(eq(blockchains.name, this.mapChainName(yieldPool.chain)))
            .limit(1);

          if (blockchain.length === 0) continue;

          // Find or create protocol
          let protocol = await db.select().from(protocols)
            .where(eq(protocols.slug, yieldPool.project.toLowerCase().replace(/\s+/g, '-')))
            .limit(1);
          
          if (protocol.length === 0) {
            try {
              const newProtocol = await db.insert(protocols).values({
                name: yieldPool.project,
                slug: yieldPool.project.toLowerCase().replace(/\s+/g, '-'),
                category: yieldPool.category || 'Yield',
                isVerified: true,
              }).returning();
              protocol = newProtocol;
            } catch (error) {
              // If duplicate, try to fetch again - silent handling
              protocol = await db.select().from(protocols)
                .where(eq(protocols.slug, yieldPool.project.toLowerCase().replace(/\s+/g, '-')))
                .limit(1);
              if (protocol.length === 0) continue; // Skip this pool silently
            }
          }

          const poolEntry = {
            protocolId: protocol[0].id,
            blockchainId: blockchain[0].id,
            poolAddress: yieldPool.pool || `${yieldPool.project}-${yieldPool.symbol}`,
            name: yieldPool.symbol,
            tokens: [{ symbol: yieldPool.symbol, name: yieldPool.symbol }],
            apy: yieldPool.apy?.toString() || '0',
            apr: yieldPool.apyBase?.toString() || '0',
            tvl: yieldPool.tvlUsd?.toString() || '0',
            volume24h: yieldPool.volumeUsd1d?.toString() || (yieldPool.tvlUsd * 0.1)?.toString() || '0',
            poolType: 'farming',
            riskScore: this.calculateYieldRiskScore(yieldPool),
            metadata: {
              apyReward: yieldPool.apyReward,
              il7d: yieldPool.il7d,
              apyBase7d: yieldPool.apyBase7d,
              predictedClass: yieldPool.predictedClass,
              volumeUsd1d: yieldPool.volumeUsd1d
            }
          };

          // Check if pool exists
          const existingPool = await db.select().from(pools)
            .where(eq(pools.poolAddress, poolEntry.poolAddress))
            .limit(1);

          if (existingPool.length === 0) {
            await db.insert(pools).values(poolEntry);
          } else {
            await db.update(pools)
              .set({
                apy: poolEntry.apy,
                apr: poolEntry.apr,
                tvl: poolEntry.tvl,
                volume24h: poolEntry.volume24h,
                updatedAt: new Date(),
              })
              .where(eq(pools.poolAddress, poolEntry.poolAddress));
          }

        } catch (error) {
          // Only log non-duplicate errors
          if (!error.message?.includes('duplicate key value violates unique constraint')) {
            console.error('Error processing yield pool:', error);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching yield data:', error);
    }
  }

  private calculateRiskScore(attributes: any): number {
    let score = 5; // Default medium risk
    
    if (attributes.reserve_in_usd > 10000000) score -= 1; // High TVL = lower risk
    if (attributes.volume_usd?.h24 > 1000000) score -= 1; // High volume = lower risk
    if (attributes.price_change_percentage?.h24 && Math.abs(attributes.price_change_percentage.h24) > 20) {
      score += 2; // High volatility = higher risk
    }
    
    return Math.max(1, Math.min(10, score));
  }

  private calculateYieldRiskScore(yieldPool: any): number {
    let score = 5;
    
    if (yieldPool.apy > 100) score += 3; // Very high APY = high risk
    if (yieldPool.apy > 50) score += 2;
    if (yieldPool.apy < 5) score -= 1; // Low APY = lower risk
    if (yieldPool.tvlUsd > 50000000) score -= 1; // High TVL = lower risk
    if (yieldPool.il7d && yieldPool.il7d > 2) score += 2; // Impermanent loss risk
    
    return Math.max(1, Math.min(10, score));
  }

  private mapNetworkName(networkName: string): string {
    const mapping: Record<string, string> = {
      'eth': 'Ethereum',
      'polygon_pos': 'Polygon',
      'arbitrum_one': 'Arbitrum',
      'optimistic_ethereum': 'Optimism',
      'base': 'Base',
      'avalanche_c_chain': 'Avalanche',
      'bsc': 'BSC',
      'fantom': 'Fantom'
    };
    return mapping[networkName] || networkName;
  }

  private mapChainName(chainName: string): string {
    const mapping: Record<string, string> = {
      'ethereum': 'Ethereum',
      'polygon': 'Polygon',
      'arbitrum': 'Arbitrum',
      'optimism': 'Optimism',
      'base': 'Base',
      'avalanche': 'Avalanche',
      'bsc': 'BSC',
      'fantom': 'Fantom',
      'solana': 'Solana'
    };
    return mapping[chainName.toLowerCase()] || chainName;
  }

  private async startDataFetching() {
    if (this.isRunning) return;
    this.isRunning = true;

    console.log('🚀 Starting real-time data fetching...');

    const fetchData = async () => {
      try {
        console.log('📊 Fetching DeFi data...');
        
        // Parallel data fetching for performance
        await Promise.allSettled([
          this.fetchCoinGeckoData(),
          this.fetchDeFiLlamaData(),
          this.fetchYieldData(),
          this.fetchVolumeUpdates(),
        ]);

        console.log('✅ Data fetch completed');
      } catch (error) {
        console.error('❌ Error in data fetching cycle:', error);
      }
    };

    // Initial fetch
    await fetchData();

    // Set up interval for continuous updates
    setInterval(fetchData, this.updateInterval);
  }

  // Fetch real-time volume updates for major tokens
  async fetchVolumeUpdates() {
    try {
      // Get top tokens by market cap for volume updates
      const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=24h');
      if (!response.ok) return;
      
      const tokensData = await response.json();
      
      for (const token of tokensData) {
        try {
          // Update pools that contain this token with fresh volume data
          const tokenSymbol = token.symbol.toUpperCase();
          const volume24h = String(token.total_volume || 0);
          
          // Find pools with this token symbol in their name or tokens array
          const poolsToUpdate = await db.select().from(pools)
            .where(sql`
              UPPER(${pools.name}) LIKE ${`%${tokenSymbol}%`} OR
              UPPER(${pools.name}) LIKE ${`%${token.name.toUpperCase()}%`}
            `);
          
          for (const pool of poolsToUpdate) {
            // Update volume with a realistic calculation based on TVL and market activity
            const estimatedVolume = Math.max(
              parseFloat(volume24h) * 0.1, // 10% of token volume
              parseFloat(pool.tvl || '0') * 0.05 // 5% of pool TVL as minimum volume
            );
            
            await db.update(pools)
              .set({
                volume24h: String(estimatedVolume),
                updatedAt: new Date(),
              })
              .where(eq(pools.id, pool.id));
          }
          
        } catch (error) {
          // Silent error handling to avoid spam
          if (!error.message?.includes('duplicate key value violates unique constraint')) {
            console.error('Error updating volume for token:', token.symbol, error);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching volume updates:', error);
    }
  }

  async getPoolStats() {
    try {
      const totalPools = await db.select().from(pools);
      const totalProtocols = await db.select().from(protocols);
      const totalChains = await db.select().from(blockchains).where(eq(blockchains.isActive, true));

      return {
        totalPools: totalPools.length,
        totalProtocols: totalProtocols.length,
        totalChains: totalChains.length,
        lastUpdated: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error getting pool stats:', error);
      return { totalPools: 0, totalProtocols: 0, totalChains: 0, lastUpdated: new Date().toISOString() };
    }
  }
}

// Global instance
export const dataFetcher = new DataFetcher();