import { db } from './db';
import { protocols, blockchains } from '@shared/schema';
import { eq } from 'drizzle-orm';

interface CoinGeckoProtocol {
  id: string;
  name: string;
  image?: string;
}

interface CoinGeckoBlockchain {
  id: string;
  name: string;
  image?: string;
}

export class LogoFetcher {
  private readonly COINGECKO_API = 'https://api.coingecko.com/api/v3';
  
  async fetchProtocolLogos() {
    console.log('🔄 Fetching protocol logos from CoinGecko...');
    
    try {
      // Get protocols from CoinGecko
      const response = await fetch(`${this.COINGECKO_API}/coins/list?include_platform=false`);
      const coinGeckoCoins: CoinGeckoProtocol[] = await response.json();
      
      // Get our protocols from database
      const ourProtocols = await db.select().from(protocols);
      
      console.log(`📊 Found ${ourProtocols.length} protocols in database`);
      console.log(`📊 Found ${coinGeckoCoins.length} protocols from CoinGecko`);
      
      let updated = 0;
      
      for (const protocol of ourProtocols) {
        // Improve matching algorithm
        const protocolNameLower = protocol.name.toLowerCase();
        const protocolSlug = protocolNameLower.replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
        
        const matchedCoin = coinGeckoCoins.find(coin => {
          const coinNameLower = coin.name.toLowerCase();
          const coinIdLower = coin.id.toLowerCase();
          
          return (
            coinNameLower === protocolNameLower ||
            coinIdLower === protocolSlug ||
            coinIdLower.includes(protocolSlug) ||
            protocolSlug.includes(coinIdLower) ||
            (protocolNameLower.includes('aave') && coinIdLower.includes('aave')) ||
            (protocolNameLower.includes('uniswap') && coinIdLower.includes('uniswap')) ||
            (protocolNameLower.includes('compound') && coinIdLower.includes('compound')) ||
            (protocolNameLower.includes('curve') && coinIdLower.includes('curve')) ||
            (protocolNameLower.includes('sushi') && coinIdLower.includes('sushi')) ||
            (protocolNameLower.includes('pancake') && coinIdLower.includes('pancake')) ||
            (protocolNameLower.includes('balancer') && coinIdLower.includes('balancer')) ||
            (protocolNameLower.includes('yearn') && coinIdLower.includes('yearn')) ||
            (protocolNameLower.includes('morpho') && coinIdLower.includes('morpho')) ||
            (protocolNameLower.includes('convex') && coinIdLower.includes('convex'))
          );
        });
        
        if (matchedCoin) {
          // Get detailed coin info with logo
          try {
            const detailResponse = await fetch(`${this.COINGECKO_API}/coins/${matchedCoin.id}`);
            const coinDetail = await detailResponse.json();
            
            if (coinDetail.image?.large) {
              await db.update(protocols)
                .set({ logoUrl: coinDetail.image.large })
                .where(eq(protocols.id, protocol.id));
              
              console.log(`✅ Updated logo for ${protocol.name}: ${coinDetail.image.large}`);
              updated++;
            }
            
            // Add delay to respect rate limits
            await new Promise(resolve => setTimeout(resolve, 100));
          } catch (error) {
            console.log(`⚠️ Failed to get details for ${protocol.name}:`, error);
          }
        } else {
          console.log(`❌ No match found for protocol: ${protocol.name}`);
        }
      }
      
      console.log(`🎉 Updated ${updated} protocol logos`);
      return updated;
    } catch (error) {
      console.error('❌ Error fetching protocol logos:', error);
      return 0;
    }
  }
  
  async fetchBlockchainLogos() {
    console.log('🔄 Fetching blockchain logos from CoinGecko...');
    
    // Comprehensive blockchain logo mappings
    const blockchainLogos: Record<string, string> = {
      'ethereum': 'https://assets.coingecko.com/coins/images/279/large/ethereum.png',
      'bitcoin': 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png',
      'binance smart chain': 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png',
      'polygon': 'https://assets.coingecko.com/coins/images/4713/large/matic-token-icon.png',
      'arbitrum': 'https://assets.coingecko.com/coins/images/16547/large/photo_2023-03-29_21.47.00.jpeg',
      'optimism': 'https://assets.coingecko.com/coins/images/25244/large/Optimism.png',
      'avalanche': 'https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Trans.png',
      'solana': 'https://assets.coingecko.com/coins/images/4128/large/solana.png',
      'cardano': 'https://assets.coingecko.com/coins/images/975/large/cardano.png',
      'polkadot': 'https://assets.coingecko.com/coins/images/12171/large/polkadot.png',
      'cosmos': 'https://assets.coingecko.com/coins/images/1481/large/cosmos_hub.png',
      'near': 'https://assets.coingecko.com/coins/images/10365/large/near_icon.png',
      'fantom': 'https://assets.coingecko.com/coins/images/4001/large/Fantom.png',
      'cronos': 'https://assets.coingecko.com/coins/images/7310/large/cro_token_logo.png',
      'bsc': 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png',
      'matic': 'https://assets.coingecko.com/coins/images/4713/large/matic-token-icon.png',
      'avax': 'https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Trans.png',
      'base': 'https://avatars.githubusercontent.com/u/108554348?s=280&v=4',
      'zksync': 'https://assets.coingecko.com/coins/images/24091/large/zksync-era.png',
      'linea': 'https://assets.coingecko.com/coins/images/31265/large/Linea.png',
      'scroll': 'https://assets.coingecko.com/coins/images/26125/large/scroll.png',
      'kusama': 'https://assets.coingecko.com/coins/images/9568/large/m4zRhP5e_400x400.jpg',
      'algorand': 'https://assets.coingecko.com/coins/images/4380/large/download.png',
      'hedera': 'https://assets.coingecko.com/coins/images/3441/large/Hedera_Hashgraph.png',
      'tron': 'https://assets.coingecko.com/coins/images/1094/large/tron-logo.png'
    };
    
    try {
      const ourBlockchains = await db.select().from(blockchains);
      console.log(`📊 Found ${ourBlockchains.length} blockchains in database`);
      
      let updated = 0;
      
      for (const blockchain of ourBlockchains) {
        const blockchainKey = blockchain.name.toLowerCase();
        const logoUrl = blockchainLogos[blockchainKey] || 
                       blockchainLogos[blockchainKey.replace(/\s+/g, '')] ||
                       blockchainLogos[blockchainKey.split(' ')[0]];
        
        if (logoUrl) {
          await db.update(blockchains)
            .set({ logoUrl })
            .where(eq(blockchains.id, blockchain.id));
          
          console.log(`✅ Updated logo for ${blockchain.name}: ${logoUrl}`);
          updated++;
        } else {
          console.log(`❌ No logo found for blockchain: ${blockchain.name}`);
        }
      }
      
      console.log(`🎉 Updated ${updated} blockchain logos`);
      return updated;
    } catch (error) {
      console.error('❌ Error fetching blockchain logos:', error);
      return 0;
    }
  }
  
  async fetchAllLogos() {
    console.log('🚀 Starting logo fetching process...');
    
    const protocolsUpdated = await this.fetchProtocolLogos();
    const blockchainsUpdated = await this.fetchBlockchainLogos();
    
    console.log(`\n📊 Logo Fetching Summary:`);
    console.log(`   • Protocols updated: ${protocolsUpdated}`);
    console.log(`   • Blockchains updated: ${blockchainsUpdated}`);
    console.log(`   • Total updated: ${protocolsUpdated + blockchainsUpdated}`);
    
    return {
      protocols: protocolsUpdated,
      blockchains: blockchainsUpdated,
      total: protocolsUpdated + blockchainsUpdated
    };
  }
}