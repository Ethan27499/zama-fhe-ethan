// Advanced NLP Processing for Vietnamese and English
import * as natural from 'natural';
import { NlpManager } from 'node-nlp';
import * as compromise from 'compromise';
import * as sentiment from 'sentiment';

interface AdvancedNLPResult {
  language: string;
  tokens: string[];
  pos: Array<{word: string; pos: string}>;
  entities: Array<{entity: string; type: string; confidence: number}>;
  sentiment: {score: number; comparative: number; tokens: string[]};
  keywords: Array<{word: string; score: number}>;
  topics: string[];
  complexity: number;
  readability: number;
  intent: {intent: string; confidence: number};
}

interface VietnameseNLPFeatures {
  wordSegmentation: string[];
  phoneticAnalysis: any;
  toneAnalysis: any;
  dialectAnalysis: any;
}

export class AdvancedNLPProcessor {
  private nlpManager: NlpManager;
  private sentimentAnalyzer: any;
  private vietnameseTokenizer: any;
  private keywordExtractor: any;

  constructor() {
    this.initializeNLP();
  }

  private initializeNLP(): void {
    // Initialize NLP Manager with multiple languages
    this.nlpManager = new NlpManager({ 
      languages: ['en', 'vi'],
      forceNER: true
    });

    // Initialize sentiment analyzer
    this.sentimentAnalyzer = new sentiment();

    // Initialize Vietnamese-specific processing
    this.initializeVietnameseNLP();

    // Initialize keyword extraction
    this.keywordExtractor = natural.TfIdf;
  }

  private initializeVietnameseNLP(): void {
    // Vietnamese word segmentation patterns
    this.vietnameseTokenizer = {
      segment: (text: string): string[] => {
        // Simple Vietnamese word segmentation
        // In production, use more sophisticated libraries like pyvi
        const words = text.split(/\s+/);
        const segmented: string[] = [];
        
        for (const word of words) {
          if (this.isVietnameseWord(word)) {
            segmented.push(...this.segmentVietnameseWord(word));
          } else {
            segmented.push(word);
          }
        }
        
        return segmented;
      }
    };
  }

  private isVietnameseWord(word: string): boolean {
    // Check if word contains Vietnamese characters
    const vietnameseChars = /[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/i;
    return vietnameseChars.test(word);
  }

  private segmentVietnameseWord(word: string): string[] {
    // Simple Vietnamese word segmentation
    // This would be more sophisticated in production
    return [word]; // For now, return as is
  }

  async processText(text: string): Promise<AdvancedNLPResult> {
    const language = await this.detectLanguage(text);
    
    const [
      tokens,
      pos,
      entities,
      sentimentResult,
      keywords,
      topics,
      complexity,
      readability,
      intent
    ] = await Promise.all([
      this.tokenize(text, language),
      this.posTagging(text, language),
      this.extractEntities(text, language),
      this.analyzeSentiment(text, language),
      this.extractKeywords(text),
      this.extractTopics(text),
      this.calculateComplexity(text),
      this.calculateReadability(text),
      this.classifyIntent(text, language)
    ]);

    return {
      language,
      tokens,
      pos,
      entities,
      sentiment: sentimentResult,
      keywords,
      topics,
      complexity,
      readability,
      intent
    };
  }

  private async detectLanguage(text: string): Promise<string> {
    // Simple language detection based on character patterns
    const vietnameseChars = (text.match(/[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/g) || []).length;
    const totalChars = text.replace(/[^a-zA-Zàáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/g, '').length;
    
    if (totalChars === 0) return 'unknown';
    
    const vietnameseRatio = vietnameseChars / totalChars;
    
    if (vietnameseRatio > 0.1) {
      return 'vietnamese';
    }
    
    return 'english';
  }

  private async tokenize(text: string, language: string): Promise<string[]> {
    if (language === 'vietnamese') {
      return this.vietnameseTokenizer.segment(text);
    }
    
    const tokenizer = new natural.WordTokenizer();
    return tokenizer.tokenize(text) || [];
  }

  private async posTagging(text: string, language: string): Promise<Array<{word: string; pos: string}>> {
    if (language === 'vietnamese') {
      return this.vietnamesePOSTagging(text);
    }
    
    // English POS tagging using compromise
    const doc = compromise(text);
    const terms = doc.terms().out('array');
    
    return terms.map(term => ({
      word: term,
      pos: this.getEnglishPOS(term, doc)
    }));
  }

  private vietnamesePOSTagging(text: string): Array<{word: string; pos: string}> {
    // Simple Vietnamese POS tagging
    // In production, use Vietnamese NLP libraries
    const words = this.vietnameseTokenizer.segment(text);
    
    return words.map(word => ({
      word,
      pos: this.guessVietnamesePOS(word)
    }));
  }

  private guessVietnamesePOS(word: string): string {
    // Simple heuristics for Vietnamese POS
    if (word.match(/^(là|được|có|sẽ|đã|đang)$/)) return 'VERB';
    if (word.match(/^(và|hoặc|nhưng|nên|vì)$/)) return 'CONJ';
    if (word.match(/^(tôi|bạn|anh|chị|họ)$/)) return 'PRON';
    if (word.match(/^(rất|khá|hơi|quá)$/)) return 'ADV';
    if (word.match(/^(một|hai|ba|nhiều)$/)) return 'NUM';
    
    return 'NOUN'; // Default to noun
  }

  private getEnglishPOS(term: string, doc: any): string {
    if (doc.match(term).isVerb().length > 0) return 'VERB';
    if (doc.match(term).isNoun().length > 0) return 'NOUN';
    if (doc.match(term).isAdjective().length > 0) return 'ADJ';
    if (doc.match(term).isAdverb().length > 0) return 'ADV';
    if (doc.match(term).isPreposition().length > 0) return 'PREP';
    
    return 'UNKNOWN';
  }

  private async extractEntities(text: string, language: string): Promise<Array<{entity: string; type: string; confidence: number}>> {
    const entities: Array<{entity: string; type: string; confidence: number}> = [];
    
    // Extract crypto/DeFi entities
    const cryptoEntities = this.extractCryptoEntities(text);
    entities.push(...cryptoEntities);
    
    // Extract person names
    const personEntities = this.extractPersonEntities(text, language);
    entities.push(...personEntities);
    
    // Extract organizations
    const orgEntities = this.extractOrganizationEntities(text);
    entities.push(...orgEntities);
    
    // Extract financial terms
    const finEntities = this.extractFinancialEntities(text);
    entities.push(...finEntities);
    
    return entities;
  }

  private extractCryptoEntities(text: string): Array<{entity: string; type: string; confidence: number}> {
    const cryptoPatterns = [
      // Cryptocurrencies
      { pattern: /\b(bitcoin|btc)\b/gi, type: 'CRYPTOCURRENCY' },
      { pattern: /\b(ethereum|eth)\b/gi, type: 'CRYPTOCURRENCY' },
      { pattern: /\b(uniswap|uni)\b/gi, type: 'PROTOCOL' },
      { pattern: /\b(compound|comp)\b/gi, type: 'PROTOCOL' },
      { pattern: /\b(aave)\b/gi, type: 'PROTOCOL' },
      
      // DeFi terms
      { pattern: /\b(yield farming|liquidity mining)\b/gi, type: 'DEFI_CONCEPT' },
      { pattern: /\b(impermanent loss)\b/gi, type: 'DEFI_CONCEPT' },
      { pattern: /\b(smart contract)\b/gi, type: 'BLOCKCHAIN_CONCEPT' },
      
      // Vietnamese crypto terms
      { pattern: /\b(tài chính phi tập trung|defi)\b/gi, type: 'DEFI_CONCEPT' },
      { pattern: /\b(hợp đồng thông minh)\b/gi, type: 'BLOCKCHAIN_CONCEPT' },
      { pattern: /\b(canh tác lợi nhuận)\b/gi, type: 'DEFI_CONCEPT' }
    ];

    const entities: Array<{entity: string; type: string; confidence: number}> = [];
    
    for (const { pattern, type } of cryptoPatterns) {
      const matches = text.matchAll(pattern);
      for (const match of matches) {
        entities.push({
          entity: match[0],
          type,
          confidence: 0.9
        });
      }
    }
    
    return entities;
  }

  private extractPersonEntities(text: string, language: string): Array<{entity: string; type: string; confidence: number}> {
    const personPatterns = language === 'vietnamese' ? [
      /\b(anh|chị|ông|bà)\s+([A-Z][a-z]+)\b/g,
      /\b([A-Z][a-z]+\s+[A-Z][a-z]+)\b/g
    ] : [
      /\b([A-Z][a-z]+\s+[A-Z][a-z]+)\b/g,
      /\b(Mr|Ms|Dr)\.\s+([A-Z][a-z]+)\b/g
    ];

    const entities: Array<{entity: string; type: string; confidence: number}> = [];
    
    for (const pattern of personPatterns) {
      const matches = text.matchAll(pattern);
      for (const match of matches) {
        const entity = match[2] || match[1];
        if (entity && entity.length > 2) {
          entities.push({
            entity: entity.trim(),
            type: 'PERSON',
            confidence: 0.7
          });
        }
      }
    }
    
    return entities;
  }

  private extractOrganizationEntities(text: string): Array<{entity: string; type: string; confidence: number}> {
    const orgPatterns = [
      /\b([A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]+)*)\s+(Foundation|Labs|Protocol|Network|DAO)\b/g,
      /\b(Coinbase|Binance|Kraken|FTX|Gemini)\b/gi
    ];

    const entities: Array<{entity: string; type: string; confidence: number}> = [];
    
    for (const pattern of orgPatterns) {
      const matches = text.matchAll(pattern);
      for (const match of matches) {
        entities.push({
          entity: match[0],
          type: 'ORGANIZATION',
          confidence: 0.8
        });
      }
    }
    
    return entities;
  }

  private extractFinancialEntities(text: string): Array<{entity: string; type: string; confidence: number}> {
    const financialPatterns = [
      { pattern: /\$\d+(?:,\d{3})*(?:\.\d{2})?/g, type: 'MONEY' },
      { pattern: /\d+(?:\.\d+)?%/g, type: 'PERCENTAGE' },
      { pattern: /\d+(?:,\d{3})*\s*(USD|EUR|BTC|ETH)/gi, type: 'MONEY' },
      { pattern: /\b(APY|TVL|ROI|P\/E)\b/gi, type: 'FINANCIAL_METRIC' }
    ];

    const entities: Array<{entity: string; type: string; confidence: number}> = [];
    
    for (const { pattern, type } of financialPatterns) {
      const matches = text.matchAll(pattern);
      for (const match of matches) {
        entities.push({
          entity: match[0],
          type,
          confidence: 0.9
        });
      }
    }
    
    return entities;
  }

  private async analyzeSentiment(text: string, language: string): Promise<{score: number; comparative: number; tokens: string[]}> {
    if (language === 'vietnamese') {
      return this.analyzeVietnameseSentiment(text);
    }
    
    return this.sentimentAnalyzer.analyze(text);
  }

  private analyzeVietnameseSentiment(text: string): {score: number; comparative: number; tokens: string[]} {
    // Simple Vietnamese sentiment analysis
    const positiveWords = ['tốt', 'hay', 'tuyệt', 'xuất sắc', 'tăng', 'lãi', 'thành công'];
    const negativeWords = ['xấu', 'tệ', 'giảm', 'lỗ', 'thất bại', 'rủi ro', 'nguy hiểm'];
    
    const words = text.toLowerCase().split(/\s+/);
    let score = 0;
    const tokens: string[] = [];
    
    for (const word of words) {
      if (positiveWords.includes(word)) {
        score += 1;
        tokens.push(word);
      } else if (negativeWords.includes(word)) {
        score -= 1;
        tokens.push(word);
      }
    }
    
    return {
      score,
      comparative: words.length > 0 ? score / words.length : 0,
      tokens
    };
  }

  private async extractKeywords(text: string): Promise<Array<{word: string; score: number}>> {
    const tfidf = new natural.TfIdf();
    tfidf.addDocument(text);
    
    const keywords: Array<{word: string; score: number}> = [];
    
    tfidf.listTerms(0).forEach(item => {
      if (item.term.length > 2) {
        keywords.push({
          word: item.term,
          score: item.tfidf
        });
      }
    });
    
    return keywords.sort((a, b) => b.score - a.score).slice(0, 10);
  }

  private async extractTopics(text: string): Promise<string[]> {
    const doc = compromise(text);
    const topics = new Set<string>();
    
    // Extract nouns as potential topics
    const nouns = doc.nouns().out('array');
    nouns.forEach(noun => {
      if (noun.length > 2) {
        topics.add(noun.toLowerCase());
      }
    });
    
    // Extract named entities as topics
    const people = doc.people().out('array');
    const places = doc.places().out('array');
    const organizations = doc.organizations().out('array');
    
    [...people, ...places, ...organizations].forEach(entity => {
      topics.add(entity.toLowerCase());
    });
    
    return Array.from(topics).slice(0, 5);
  }

  private async calculateComplexity(text: string): Promise<number> {
    const words = text.split(/\s+/);
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const avgWordsPerSentence = words.length / sentences.length;
    
    // Calculate syllable complexity
    const avgSyllables = words.reduce((sum, word) => {
      return sum + this.countSyllables(word);
    }, 0) / words.length;
    
    // Normalize complexity score (0-1)
    let complexity = 0;
    
    // Sentence length factor
    if (avgWordsPerSentence > 20) complexity += 0.4;
    else if (avgWordsPerSentence > 15) complexity += 0.3;
    else if (avgWordsPerSentence > 10) complexity += 0.2;
    
    // Syllable complexity factor
    if (avgSyllables > 2) complexity += 0.3;
    else if (avgSyllables > 1.5) complexity += 0.2;
    
    // Technical term density
    const technicalTerms = this.countTechnicalTerms(text);
    complexity += Math.min(0.3, technicalTerms / words.length * 10);
    
    return Math.min(1.0, complexity);
  }

  private countSyllables(word: string): number {
    // Simple syllable counting
    const vowels = 'aeiouy';
    let syllables = 0;
    let prevWasVowel = false;
    
    for (const char of word.toLowerCase()) {
      const isVowel = vowels.includes(char);
      if (isVowel && !prevWasVowel) {
        syllables++;
      }
      prevWasVowel = isVowel;
    }
    
    return Math.max(1, syllables);
  }

  private countTechnicalTerms(text: string): number {
    const technicalTerms = [
      'defi', 'blockchain', 'cryptocurrency', 'smart contract', 'yield farming',
      'liquidity', 'staking', 'apy', 'tvl', 'impermanent loss', 'governance',
      'protocol', 'token', 'wallet', 'exchange', 'market cap'
    ];
    
    const lowerText = text.toLowerCase();
    return technicalTerms.filter(term => lowerText.includes(term)).length;
  }

  private async calculateReadability(text: string): Promise<number> {
    // Flesch Reading Ease approximation
    const words = text.split(/\s+/);
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const syllables = words.reduce((sum, word) => sum + this.countSyllables(word), 0);
    
    if (sentences.length === 0 || words.length === 0) return 0;
    
    const avgWordsPerSentence = words.length / sentences.length;
    const avgSyllablesPerWord = syllables / words.length;
    
    // Simplified Flesch formula
    const score = 206.835 - (1.015 * avgWordsPerSentence) - (84.6 * avgSyllablesPerWord);
    
    // Normalize to 0-1 scale
    return Math.max(0, Math.min(1, score / 100));
  }

  private async classifyIntent(text: string, language: string): Promise<{intent: string; confidence: number}> {
    const intentPatterns = {
      question: {
        en: [/\b(what|how|why|when|where|who|which|can|could|would|should|is|are|do|does)\b/i, /\?$/],
        vi: [/\b(gì|như thế nào|tại sao|khi nào|ở đâu|ai|cái nào|có thể|nên|là|có|làm)\b/i, /\?$/]
      },
      complaint: {
        en: [/\b(hate|terrible|awful|worst|disappointed|frustrated|angry)\b/i],
        vi: [/\b(ghét|tệ|kinh khủng|thất vọng|tức giận|bực mình)\b/i]
      },
      compliment: {
        en: [/\b(love|great|awesome|best|amazing|excellent|fantastic)\b/i],
        vi: [/\b(yêu|tuyệt|xuất sắc|tốt nhất|tuyệt vời|tuyệt diệu)\b/i]
      },
      request: {
        en: [/\b(please|can you|could you|help|need|want)\b/i],
        vi: [/\b(làm ơn|bạn có thể|giúp|cần|muốn)\b/i]
      }
    };

    const patterns = language === 'vietnamese' ? 
      Object.fromEntries(Object.entries(intentPatterns).map(([intent, langs]) => [intent, langs.vi])) :
      Object.fromEntries(Object.entries(intentPatterns).map(([intent, langs]) => [intent, langs.en]));

    for (const [intent, patternList] of Object.entries(patterns)) {
      for (const pattern of patternList) {
        if (pattern.test(text)) {
          return { intent, confidence: 0.8 };
        }
      }
    }

    return { intent: 'statement', confidence: 0.6 };
  }
}