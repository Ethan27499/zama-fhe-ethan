import OpenAI from 'openai';
import type { DetectedFallacy, ArgumentStructure } from './types';

interface FallacyPattern {
  patterns: string[];
  vietnamesePatterns: string[];
  weight: number;
  contextRequired: boolean;
  description: string;
  examples: string[];
}

export class LogicalFallacyDetector {
  private openai: OpenAI;
  private defiFallacyPatterns: Record<string, FallacyPattern> = {};
  private argumentParser: ArgumentStructureParser;

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
    this.initializeFallacyPatterns();
    this.argumentParser = new ArgumentStructureParser();
  }

  private initializeFallacyPatterns(): void {
    this.defiFallacyPatterns = {
      'appeal_to_authority': {
        patterns: [
          'vitalik (said|believes|thinks)',
          'satoshi (would|said|intended)',
          '(influencer|youtuber|tiktoker) (recommends|suggests)',
          '(top trader|whale|og) (always|never)',
          'trust me (bro|i am|because)',
          '(expert|guru|master) (told|said|believes)'
        ],
        vietnamesePatterns: [
          'vitalik (nói|tin|nghĩ)',
          'satoshi (sẽ|nói|dự định)',
          '(influencer|youtuber) (việt nam|vn) (nói|khuyên)',
          '(cao thủ|chuyên gia|guru) (luôn|không bao giờ)',
          '(tin anh|tin tôi) (nhé|đi)',
          '(anh|chị|ông) \\w+ (nói|khuyên|bảo)'
        ],
        weight: 0.8,
        contextRequired: true,
        description: 'Lập luận dựa vào uy tín thay vì bằng chứng',
        examples: [
          'Vitalik nói ETH sẽ lên $10k nên mua ngay',
          'Guru X khuyên nên all-in vào token này'
        ]
      },

      'false_dichotomy': {
        patterns: [
          '(either|only) .*(or|never)',
          '(must choose|no alternative|only option)',
          '(all or nothing|black and white)',
          'if you don\'t .* you will',
          '(buy now or|hodl or) (miss out|regret)',
          'there are only (two|2) (options|choices)'
        ],
        vietnamesePatterns: [
          '(chỉ có|không có lựa chọn nào khác)',
          '(hoặc là|không thì)',
          '(trắng đen|tất cả hoặc không)',
          'nếu không .* thì sẽ',
          '(mua ngay hoặc|hodl hoặc) (lỡ cơ hội|hối hận)',
          'chỉ có (hai|2) (lựa chọn|cách)'
        ],
        weight: 0.9,
        contextRequired: false,
        description: 'Đưa ra chỉ 2 lựa chọn trong khi có nhiều khả năng khác',
        examples: [
          'Hoặc là bạn mua Bitcoin ngay hoặc mất cơ hội làm giàu',
          'Chỉ có hodl hoặc mất hết tiền'
        ]
      },

      'cherry_picking': {
        patterns: [
          '(look at|consider only|focus on) .*(ignore|dismiss)',
          '(best case|perfect example|ideal scenario)',
          '(convenient|selective|handpicked) (data|evidence)',
          'for example .* (but ignore|don\'t mention)',
          '(pick|choose) the (best|worst) (case|example)',
          'only show(ing)? (good|positive|successful) (results|cases)'
        ],
        vietnamesePatterns: [
          '(chỉ nhìn vào|chỉ xét) .*(bỏ qua|không kể)',
          '(trường hợp tốt nhất|ví dụ hoàn hảo)',
          '(chọn lọc|có chủ đích) (dữ liệu|bằng chứng)',
          'ví dụ .* (nhưng bỏ qua|không nói)',
          '(chọn|lấy) (trường hợp|ví dụ) (tốt|xấu) nhất',
          'chỉ cho thấy (kết quả|trường hợp) (tốt|thành công)'
        ],
        weight: 0.7,
        contextRequired: true,
        description: 'Chỉ đưa ra bằng chứng có lợi, bỏ qua thông tin phản bác',
        examples: [
          'Nhìn vào Ethereum tăng 1000% năm 2021, không nói về việc giảm 80%',
          'Chỉ kể những người làm giàu từ DeFi, không nói ai mất tiền'
        ]
      },

      'post_hoc': {
        patterns: [
          '(because|since|due to) .* (therefore|so|thus)',
          '(after|following|subsequent to) .* (caused|resulted)',
          '(correlation|relationship) (proves|demonstrates|shows)',
          'happened right after .* so .* caused',
          'when .* went up, .* also went up, so',
          'every time .* happens, .* follows'
        ],
        vietnamesePatterns: [
          '(bởi vì|do) .* (nên|vì thế)',
          '(sau khi|theo sau) .* (gây ra|dẫn đến)',
          '(tương quan|mối quan hệ) (chứng minh|cho thấy)',
          'xảy ra ngay sau .* nên .* gây ra',
          'khi .* tăng, .* cũng tăng, vậy',
          'mỗi khi .* xảy ra, .* theo sau'
        ],
        weight: 0.6,
        contextRequired: true,
        description: 'Cho rằng sự kiện xảy ra sau là do sự kiện trước gây ra',
        examples: [
          'Bitcoin tăng sau khi Elon tweet, vậy tweet của Elon làm Bitcoin tăng',
          'DeFi khởi sắc sau COVID, vậy COVID là nguyên nhân'
        ]
      },

      'bandwagon': {
        patterns: [
          '(everyone|everybody) is (buying|using|investing)',
          '(all|most) (people|investors|traders) (agree|believe)',
          'join the (trend|movement|revolution)',
          'don\'t (miss out|be left behind)',
          'fomo (in|into) .* like everyone',
          '(popular|trending|viral) so must be good'
        ],
        vietnamesePatterns: [
          '(mọi người|ai cũng) đang (mua|dùng|đầu tư)',
          '(tất cả|hầu hết) (người|nhà đầu tư) (đồng ý|tin)',
          'tham gia (xu hướng|phong trào|cuộc cách mạng)',
          'đừng (bỏ lỡ|bị bỏ lại)',
          'fomo (vào|theo) .* như mọi người',
          '(phổ biến|thịnh hành|viral) nên phải tốt'
        ],
        weight: 0.8,
        contextRequired: false,
        description: 'Cho rằng điều gì phổ biến thì đúng/tốt',
        examples: [
          'Ai cũng đang mua NFT, bạn cũng nên mua',
          'Hầu hết người đều tin vào dự án này'
        ]
      },

      'strawman': {
        patterns: [
          'critics (say|claim|argue) that .* (but actually|in reality)',
          'people who don\'t understand .* think',
          'skeptics (believe|think) .* is just',
          '(opponents|haters) (say|claim) .* but',
          'traditional (finance|banking) thinks .* but'
        ],
        vietnamesePatterns: [
          'những người chỉ trích (nói|cho rằng) .* (nhưng thực tế|trên thực tế)',
          'người không hiểu .* nghĩ',
          'những người hoài nghi (tin|nghĩ) .* chỉ là',
          '(kẻ thù|anti) (nói|cho rằng) .* nhưng',
          'tài chính truyền thống nghĩ .* nhưng'
        ],
        weight: 0.7,
        contextRequired: true,
        description: 'Bóp méo quan điểm đối phương để dễ phản bác',
        examples: [
          'Những người phản đối Bitcoin nói nó chỉ để mua drugs',
          'Banks nghĩ DeFi là scam nhưng họ chỉ sợ cạnh tranh'
        ]
      },

      'slippery_slope': {
        patterns: [
          'if .* then .* will lead to',
          'this will cause .* which will result in',
          'starts with .* ends with',
          'once .* happens, .* is inevitable',
          'first .* then .* finally'
        ],
        vietnamesePatterns: [
          'nếu .* thì .* sẽ dẫn đến',
          'điều này sẽ gây ra .* dẫn đến',
          'bắt đầu với .* kết thúc với',
          'một khi .* xảy ra, .* là không tránh khỏi',
          'đầu tiên .* sau đó .* cuối cùng'
        ],
        weight: 0.6,
        contextRequired: true,
        description: 'Cho rằng một sự kiện sẽ dẫn đến chuỗi hậu quả tiêu cực',
        examples: [
          'Nếu regulators cấm DeFi thì crypto sẽ chết hết',
          'Bắt đầu với stable coin, cuối cùng chính phủ sẽ kiểm soát tất cả'
        ]
      },

      'ad_hominem': {
        patterns: [
          '(he|she|they) (is|are) (stupid|dumb|ignorant)',
          'coming from someone who',
          'typical (noob|newbie|normie)',
          'you don\'t understand .* so',
          'only (idiots|fools) (believe|think)'
        ],
        vietnamesePatterns: [
          '(anh|chị|họ) (ngu|tệ|không biết gì)',
          'đến từ người mà',
          'điển hình (noob|newbie|gà)',
          'bạn không hiểu .* nên',
          'chỉ có (kẻ ngu|đần) mới (tin|nghĩ)'
        ],
        weight: 0.9,
        contextRequired: false,
        description: 'Tấn công cá nhân thay vì phản bác lập luận',
        examples: [
          'Anh ta chỉ là noob nên không hiểu DeFi',
          'Chỉ có những kẻ ngu mới tin vào Bitcoin'
        ]
      }
    };
  }

  async detectFallacies(argumentText: string, language: string = "auto"): Promise<{
    detectedFallacies: DetectedFallacy[];
    confidenceScores: Record<string, number>;
    argumentStructure: ArgumentStructure;
    recommendations: string[];
    overallScore: number;
  }> {
    // Detect language if not specified
    if (language === "auto") {
      language = this.detectLanguage(argumentText);
    }

    // Parse argument structure
    const argumentStructure = await this.argumentParser.parse(argumentText);

    // Detect fallacies using multiple methods
    const [patternFallacies, mlFallacies, structuralFallacies] = await Promise.all([
      this.detectPatternFallacies(argumentText, language),
      this.classifyFallaciesML(argumentText),
      this.analyzeArgumentStructure(argumentStructure)
    ]);

    // Combine and rank results
    const allFallacies = [...patternFallacies, ...mlFallacies, ...structuralFallacies];
    const rankedFallacies = this.rankFallacies(allFallacies);
    const confidenceScores = this.calculateConfidenceScores(rankedFallacies);
    const recommendations = this.generateRecommendations(rankedFallacies);
    const overallScore = this.calculateOverallScore(rankedFallacies);

    return {
      detectedFallacies: rankedFallacies,
      confidenceScores,
      argumentStructure,
      recommendations,
      overallScore
    };
  }

  private detectPatternFallacies(text: string, language: string): DetectedFallacy[] {
    const detected: DetectedFallacy[] = [];
    const lowerText = text.toLowerCase();

    for (const [fallacyType, config] of Object.entries(this.defiFallacyPatterns)) {
      const patterns = language === 'vi' ? config.vietnamesePatterns : config.patterns;

      for (const pattern of patterns) {
        const regex = new RegExp(pattern, 'gi');
        const matches = Array.from(lowerText.matchAll(regex));

        for (const match of matches) {
          if (match.index !== undefined) {
            const confidence = config.weight * this.calculateContextBoost(text, match);
            
            detected.push({
              type: fallacyType,
              method: 'pattern',
              match: match[0],
              position: [match.index, match.index + match[0].length],
              confidence,
              explanation: this.getFallacyExplanation(fallacyType, language),
              severity: this.calculateSeverity(confidence),
              suggestions: this.getFallacySuggestions(fallacyType, language)
            });
          }
        }
      }
    }

    return detected;
  }

  private async classifyFallaciesML(text: string): Promise<DetectedFallacy[]> {
    try {
      // Skip ML classification when circuit breaker is open
      const { ResponseGenerator } = await import('./response-generator');
      const response = await (ResponseGenerator as any).circuitBreaker.execute(async () => {
        return await this.openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [{
          role: "system",
          content: `You are an expert in logical fallacies, especially in DeFi/crypto discussions. Analyze the text for these fallacies:

1. Appeal to Authority: Relying on unqualified authority
2. False Dichotomy: Presenting only two options when more exist  
3. Cherry Picking: Selecting favorable evidence, ignoring contrary
4. Post Hoc: Assuming causation from correlation
5. Bandwagon: Appeal to popularity
6. Strawman: Misrepresenting opponent's argument
7. Slippery Slope: Chain of unlikely consequences
8. Ad Hominem: Personal attacks instead of addressing argument

Return JSON array:
[{
  "type": "fallacy_name",
  "confidence": 0.8,
  "explanation": "Why this is a fallacy",
  "evidence": "Specific text showing the fallacy",
  "severity": "high/medium/low"
}]`
        }, {
          role: "user",
          content: text
        }],
          temperature: 0
        });
      });

      const result = response.choices[0].message.content;
      const mlResults = JSON.parse(result || '[]');

      return mlResults.map((result: any) => ({
        type: result.type,
        method: 'ml' as const,
        confidence: result.confidence,
        explanation: result.explanation,
        severity: result.severity,
        suggestions: this.getFallacySuggestions(result.type, 'en')
      }));
    } catch (error: any) {
      if (error.message.includes('Circuit breaker is open')) {
        // Circuit breaker is open, skip ML classification silently
        return [];
      }
      console.error('ML fallacy detection failed:', error);
      return [];
    }
  }

  private async analyzeArgumentStructure(structure: ArgumentStructure): Promise<DetectedFallacy[]> {
    const detected: DetectedFallacy[] = [];

    // Check for weak argument structure
    if (structure.premises.length === 0) {
      detected.push({
        type: 'unsupported_claim',
        method: 'structural',
        confidence: 0.9,
        explanation: 'Claim made without supporting premises',
        severity: 'high',
        suggestions: ['Provide evidence', 'Add supporting arguments', 'Cite sources']
      });
    }

    // Check for missing logical connectors
    if (structure.logicalConnectors.length === 0 && structure.premises.length > 1) {
      detected.push({
        type: 'poor_logical_flow',
        method: 'structural', 
        confidence: 0.7,
        explanation: 'Arguments lack clear logical connections',
        severity: 'medium',
        suggestions: ['Use logical connectors', 'Clarify reasoning', 'Structure arguments better']
      });
    }

    // Check for weak evidence
    if (structure.evidenceTypes.length === 0) {
      detected.push({
        type: 'lack_of_evidence',
        method: 'structural',
        confidence: 0.8,
        explanation: 'No evidence provided to support claims',
        severity: 'high',
        suggestions: ['Add credible sources', 'Provide data/statistics', 'Include expert opinions']
      });
    }

    return detected;
  }

  private calculateContextBoost(text: string, match: RegExpMatchArray): number {
    if (!match.index) return 1.0;
    
    // Extract context around the match
    const contextStart = Math.max(0, match.index - 50);
    const contextEnd = Math.min(text.length, match.index + match[0].length + 50);
    const context = text.slice(contextStart, contextEnd).toLowerCase();
    
    // Look for supporting or contradicting context
    const supportingTerms = ['because', 'therefore', 'thus', 'so', 'since', 'bởi vì', 'vì thế', 'do đó'];
    const contradictingTerms = ['however', 'but', 'although', 'despite', 'tuy nhiên', 'nhưng', 'mặc dù'];
    
    let boost = 1.0;
    
    for (const term of supportingTerms) {
      if (context.includes(term)) boost += 0.1;
    }
    
    for (const term of contradictingTerms) {
      if (context.includes(term)) boost -= 0.1;
    }
    
    return Math.max(0.3, Math.min(1.3, boost));
  }

  private rankFallacies(fallacies: DetectedFallacy[]): DetectedFallacy[] {
    return fallacies
      .sort((a, b) => b.confidence - a.confidence)
      .filter((fallacy, index, arr) => {
        // Remove duplicates with lower confidence
        return !arr.slice(0, index).some(existing => 
          existing.type === fallacy.type && existing.confidence > fallacy.confidence
        );
      });
  }

  private calculateConfidenceScores(fallacies: DetectedFallacy[]): Record<string, number> {
    const scores: Record<string, number> = {};
    
    for (const fallacy of fallacies) {
      if (!scores[fallacy.type] || scores[fallacy.type] < fallacy.confidence) {
        scores[fallacy.type] = fallacy.confidence;
      }
    }
    
    return scores;
  }

  private generateRecommendations(fallacies: DetectedFallacy[]): string[] {
    const recommendations = new Set<string>();
    
    for (const fallacy of fallacies) {
      fallacy.suggestions.forEach(suggestion => recommendations.add(suggestion));
    }
    
    // Add general recommendations based on detected patterns
    if (fallacies.some(f => f.type === 'appeal_to_authority')) {
      recommendations.add('Focus on evidence and data rather than who said it');
    }
    
    if (fallacies.some(f => f.type === 'cherry_picking')) {
      recommendations.add('Present both positive and negative aspects for balance');
    }
    
    if (fallacies.length > 3) {
      recommendations.add('Reconsider the fundamental logic of your argument');
    }
    
    return Array.from(recommendations);
  }

  private calculateOverallScore(fallacies: DetectedFallacy[]): number {
    if (fallacies.length === 0) return 10;
    
    let totalDeduction = 0;
    const severityWeights = { low: 0.5, medium: 1.0, high: 2.0 };
    
    for (const fallacy of fallacies) {
      totalDeduction += fallacy.confidence * severityWeights[fallacy.severity];
    }
    
    return Math.max(0, 10 - totalDeduction);
  }

  private getFallacyExplanation(fallacyType: string, language: string): string {
    const explanations: Record<string, Record<string, string>> = {
      'appeal_to_authority': {
        'en': 'Arguing that something is true because an authority figure said it, without considering the evidence.',
        'vi': 'Lập luận dựa vào uy tín của ai đó thay vì xem xét bằng chứng thực tế.'
      },
      'false_dichotomy': {
        'en': 'Presenting only two options when there are actually more alternatives available.',
        'vi': 'Chỉ đưa ra hai lựa chọn trong khi thực tế có nhiều khả năng khác.'
      },
      'cherry_picking': {
        'en': 'Selecting only favorable evidence while ignoring contradictory information.',
        'vi': 'Chỉ chọn những bằng chứng có lợi và bỏ qua thông tin trái chiều.'
      }
      // Add more explanations...
    };
    
    return explanations[fallacyType]?.[language] || explanations[fallacyType]?.['en'] || 'Logical fallacy detected';
  }

  private getFallacySuggestions(fallacyType: string, language: string): string[] {
    const suggestions: Record<string, Record<string, string[]>> = {
      'appeal_to_authority': {
        'en': ['Provide evidence independent of authority', 'Check if the authority is qualified in this domain', 'Look for peer-reviewed sources'],
        'vi': ['Đưa ra bằng chứng độc lập', 'Kiểm tra xem người đó có chuyên môn không', 'Tìm nguồn được kiểm định']
      },
      'false_dichotomy': {
        'en': ['Consider more alternatives', 'Explore middle-ground options', 'Question the binary framing'],
        'vi': ['Xem xét thêm các lựa chọn khác', 'Tìm hiểu các phương án trung gian', 'Đặt câu hỏi về cách đặt vấn đề']
      }
      // Add more suggestions...
    };
    
    return suggestions[fallacyType]?.[language] || suggestions[fallacyType]?.['en'] || ['Consider alternative perspectives'];
  }

  private calculateSeverity(confidence: number): 'low' | 'medium' | 'high' {
    if (confidence >= 0.8) return 'high';
    if (confidence >= 0.6) return 'medium';
    return 'low';
  }

  private detectLanguage(text: string): string {
    const vietnameseChars = (text.match(/[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/gi) || []).length;
    return vietnameseChars > 0 ? 'vi' : 'en';
  }
}

class ArgumentStructureParser {
  async parse(text: string): Promise<ArgumentStructure> {
    // This would typically use more sophisticated NLP parsing
    // For now, simple implementation
    
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const premises = sentences.slice(0, -1);
    const conclusion = sentences[sentences.length - 1] || '';
    
    const evidenceTypes = this.extractEvidenceTypes(text);
    const logicalConnectors = this.extractLogicalConnectors(text);
    const strength = this.assessArgumentStrength(premises, conclusion, evidenceTypes);
    
    return {
      premises,
      conclusion,
      evidenceTypes,
      logicalConnectors,
      strength
    };
  }

  private extractEvidenceTypes(text: string): string[] {
    const evidencePatterns = [
      { type: 'statistics', patterns: ['\\d+%', 'data shows', 'studies indicate', 'số liệu', 'thống kê'] },
      { type: 'expert_opinion', patterns: ['expert says', 'research suggests', 'chuyên gia', 'nghiên cứu'] },
      { type: 'examples', patterns: ['for example', 'such as', 'ví dụ', 'chẳng hạn'] },
      { type: 'sources', patterns: ['according to', 'source:', 'theo như', 'nguồn:'] }
    ];
    
    const found: string[] = [];
    const lowerText = text.toLowerCase();
    
    for (const evidence of evidencePatterns) {
      for (const pattern of evidence.patterns) {
        if (new RegExp(pattern).test(lowerText)) {
          found.push(evidence.type);
          break;
        }
      }
    }
    
    return found;
  }

  private extractLogicalConnectors(text: string): string[] {
    const connectors = [
      'therefore', 'thus', 'so', 'because', 'since', 'however', 'but', 'although',
      'vì thế', 'do đó', 'bởi vì', 'tuy nhiên', 'nhưng', 'mặc dù'
    ];
    
    const found: string[] = [];
    const lowerText = text.toLowerCase();
    
    for (const connector of connectors) {
      if (lowerText.includes(connector)) {
        found.push(connector);
      }
    }
    
    return found;
  }

  private assessArgumentStrength(premises: string[], conclusion: string, evidenceTypes: string[]): number {
    let strength = 0;
    
    // Base score for having premises and conclusion
    if (premises.length > 0 && conclusion.length > 0) strength += 0.3;
    
    // Bonus for multiple premises
    strength += Math.min(0.3, premises.length * 0.1);
    
    // Bonus for evidence types
    strength += Math.min(0.4, evidenceTypes.length * 0.1);
    
    return Math.min(1.0, strength);
  }
}