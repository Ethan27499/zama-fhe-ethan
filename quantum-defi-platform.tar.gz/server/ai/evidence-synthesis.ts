// Evidence Synthesis and Source Credibility Assessment
import * as _ from 'lodash';

interface EvidenceSource {
  id: string;
  name: string;
  type: 'academic' | 'news' | 'blog' | 'official' | 'social' | 'forum' | 'data_provider';
  credibilityScore: number;
  biasScore: number; // -1 (left bias) to 1 (right bias), 0 neutral
  reliabilityHistory: number[];
  lastUpdated: Date;
  expertise: string[]; // Domain expertise areas
}

interface Evidence {
  id: string;
  claim: string;
  supportingData: string;
  source: EvidenceSource;
  confidence: number;
  context: string;
  timestamp: Date;
  verificationStatus: 'verified' | 'unverified' | 'disputed' | 'debunked';
  contradictions: string[]; // IDs of contradicting evidence
}

interface SynthesizedEvidence {
  claim: string;
  supportingEvidence: Evidence[];
  contradictingEvidence: Evidence[];
  overallConfidence: number;
  consensus: 'strong_support' | 'weak_support' | 'neutral' | 'weak_opposition' | 'strong_opposition';
  keyPoints: string[];
  uncertainties: string[];
  recommendations: string[];
}

export class EvidenceSynthesizer {
  private sources: Map<string, EvidenceSource> = new Map();
  private evidenceDatabase: Map<string, Evidence> = new Map();

  constructor() {
    this.initializeCredibleSources();
  }

  private initializeCredibleSources(): void {
    const sources: EvidenceSource[] = [
      // Academic & Research
      {
        id: 'defi_pulse',
        name: 'DeFi Pulse',
        type: 'data_provider',
        credibilityScore: 0.9,
        biasScore: 0.1,
        reliabilityHistory: [0.9, 0.9, 0.8, 0.9, 0.9],
        lastUpdated: new Date(),
        expertise: ['defi', 'tvl', 'protocols', 'analytics']
      },
      {
        id: 'defillama',
        name: 'DeFiLlama',
        type: 'data_provider',
        credibilityScore: 0.95,
        biasScore: 0.0,
        reliabilityHistory: [0.95, 0.9, 0.95, 0.9, 0.95],
        lastUpdated: new Date(),
        expertise: ['defi', 'tvl', 'yields', 'cross_chain', 'analytics']
      },
      {
        id: 'messari',
        name: 'Messari',
        type: 'data_provider',
        credibilityScore: 0.85,
        biasScore: 0.0,
        reliabilityHistory: [0.85, 0.8, 0.9, 0.85, 0.8],
        lastUpdated: new Date(),
        expertise: ['crypto', 'research', 'fundamentals', 'governance']
      },
      {
        id: 'dune_analytics',
        name: 'Dune Analytics',
        type: 'data_provider',
        credibilityScore: 0.9,
        biasScore: 0.0,
        reliabilityHistory: [0.9, 0.85, 0.9, 0.9, 0.85],
        lastUpdated: new Date(),
        expertise: ['on_chain_data', 'analytics', 'dashboards', 'metrics']
      },

      // Official Sources
      {
        id: 'ethereum_foundation',
        name: 'Ethereum Foundation',
        type: 'official',
        credibilityScore: 0.95,
        biasScore: 0.2, // Slight positive bias toward Ethereum
        reliabilityHistory: [0.95, 0.9, 0.95, 0.95, 0.9],
        lastUpdated: new Date(),
        expertise: ['ethereum', 'blockchain', 'smart_contracts', 'development']
      },
      {
        id: 'uniswap_labs',
        name: 'Uniswap Labs',
        type: 'official',
        credibilityScore: 0.9,
        biasScore: 0.3, // Positive bias toward Uniswap
        reliabilityHistory: [0.9, 0.85, 0.9, 0.9, 0.85],
        lastUpdated: new Date(),
        expertise: ['uniswap', 'amm', 'dex', 'liquidity']
      },

      // News & Media
      {
        id: 'coindesk',
        name: 'CoinDesk',
        type: 'news',
        credibilityScore: 0.75,
        biasScore: 0.1,
        reliabilityHistory: [0.8, 0.7, 0.75, 0.8, 0.7],
        lastUpdated: new Date(),
        expertise: ['crypto_news', 'market_analysis', 'regulation', 'adoption']
      },
      {
        id: 'cointelegraph',
        name: 'Cointelegraph',
        type: 'news',
        credibilityScore: 0.7,
        biasScore: 0.2,
        reliabilityHistory: [0.7, 0.65, 0.7, 0.75, 0.7],
        lastUpdated: new Date(),
        expertise: ['crypto_news', 'technology', 'interviews', 'trends']
      },

      // Research & Analysis
      {
        id: 'bankless',
        name: 'Bankless',
        type: 'blog',
        credibilityScore: 0.8,
        biasScore: 0.3, // Pro-crypto bias
        reliabilityHistory: [0.8, 0.75, 0.8, 0.85, 0.8],
        lastUpdated: new Date(),
        expertise: ['defi', 'education', 'strategy', 'analysis']
      },
      {
        id: 'the_block',
        name: 'The Block',
        type: 'news',
        credibilityScore: 0.85,
        biasScore: 0.0,
        reliabilityHistory: [0.85, 0.8, 0.9, 0.85, 0.8],
        lastUpdated: new Date(),
        expertise: ['institutional', 'data', 'research', 'regulation']
      },

      // Security & Auditing
      {
        id: 'consensys_diligence',
        name: 'ConsenSys Diligence',
        type: 'official',
        credibilityScore: 0.9,
        biasScore: 0.0,
        reliabilityHistory: [0.9, 0.9, 0.85, 0.9, 0.9],
        lastUpdated: new Date(),
        expertise: ['security', 'audits', 'smart_contracts', 'vulnerabilities']
      },
      {
        id: 'trail_of_bits',
        name: 'Trail of Bits',
        type: 'official',
        credibilityScore: 0.95,
        biasScore: 0.0,
        reliabilityHistory: [0.95, 0.9, 0.95, 0.95, 0.9],
        lastUpdated: new Date(),
        expertise: ['security', 'audits', 'blockchain', 'cryptography']
      }
    ];

    sources.forEach(source => {
      this.sources.set(source.id, source);
    });
  }

  // Add new evidence to the database
  addEvidence(evidence: Omit<Evidence, 'id'>): string {
    const id = this.generateEvidenceId();
    const fullEvidence: Evidence = {
      id,
      ...evidence
    };
    
    this.evidenceDatabase.set(id, fullEvidence);
    return id;
  }

  private generateEvidenceId(): string {
    return `evidence_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Synthesize evidence for a given claim
  synthesizeEvidence(claim: string): SynthesizedEvidence {
    const relatedEvidence = this.findRelatedEvidence(claim);
    const { supporting, contradicting } = this.categorizeEvidence(relatedEvidence, claim);
    
    const overallConfidence = this.calculateOverallConfidence(supporting, contradicting);
    const consensus = this.determineConsensus(supporting, contradicting, overallConfidence);
    const keyPoints = this.extractKeyPoints(supporting, contradicting);
    const uncertainties = this.identifyUncertainties(supporting, contradicting);
    const recommendations = this.generateRecommendations(consensus, uncertainties);

    return {
      claim,
      supportingEvidence: supporting,
      contradictingEvidence: contradicting,
      overallConfidence,
      consensus,
      keyPoints,
      uncertainties,
      recommendations
    };
  }

  private findRelatedEvidence(claim: string): Evidence[] {
    const claimWords = this.extractKeywords(claim.toLowerCase());
    const related: Array<{evidence: Evidence; relevance: number}> = [];

    for (const evidence of this.evidenceDatabase.values()) {
      const relevance = this.calculateRelevance(claim, evidence, claimWords);
      if (relevance > 0.3) { // Threshold for relevance
        related.push({ evidence, relevance });
      }
    }

    // Sort by relevance and return top evidence
    return related
      .sort((a, b) => b.relevance - a.relevance)
      .slice(0, 20) // Limit to most relevant evidence
      .map(item => item.evidence);
  }

  private extractKeywords(text: string): string[] {
    const words = text.split(/\s+/).filter(word => word.length > 2);
    const stopWords = new Set(['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by']);
    return words.filter(word => !stopWords.has(word.toLowerCase()));
  }

  private calculateRelevance(claim: string, evidence: Evidence, claimWords: string[]): number {
    let relevance = 0;

    // Direct text similarity
    const evidenceWords = this.extractKeywords(evidence.claim.toLowerCase() + ' ' + evidence.supportingData.toLowerCase());
    const commonWords = claimWords.filter(word => evidenceWords.includes(word));
    relevance += (commonWords.length / claimWords.length) * 0.4;

    // Context similarity
    const contextWords = this.extractKeywords(evidence.context.toLowerCase());
    const contextCommon = claimWords.filter(word => contextWords.includes(word));
    relevance += (contextCommon.length / claimWords.length) * 0.3;

    // Source expertise alignment
    const claimDomain = this.inferDomain(claim);
    if (evidence.source.expertise.includes(claimDomain)) {
      relevance += 0.2;
    }

    // Recency boost
    const daysSinceEvidence = (Date.now() - evidence.timestamp.getTime()) / (1000 * 60 * 60 * 24);
    if (daysSinceEvidence < 30) {
      relevance += 0.1;
    }

    return Math.min(1.0, relevance);
  }

  private inferDomain(claim: string): string {
    const domainKeywords = {
      'defi': ['defi', 'decentralized finance', 'yield', 'farming', 'liquidity', 'amm'],
      'security': ['hack', 'exploit', 'vulnerability', 'audit', 'secure', 'risk'],
      'governance': ['vote', 'proposal', 'dao', 'governance', 'token holder'],
      'market': ['price', 'trading', 'volume', 'market cap', 'volatility'],
      'technology': ['blockchain', 'smart contract', 'protocol', 'algorithm']
    };

    const lowerClaim = claim.toLowerCase();
    for (const [domain, keywords] of Object.entries(domainKeywords)) {
      if (keywords.some(keyword => lowerClaim.includes(keyword))) {
        return domain;
      }
    }

    return 'general';
  }

  private categorizeEvidence(evidence: Evidence[], claim: string): {
    supporting: Evidence[];
    contradicting: Evidence[];
  } {
    const supporting: Evidence[] = [];
    const contradicting: Evidence[] = [];

    for (const item of evidence) {
      const stance = this.determineStance(item, claim);
      if (stance > 0.1) {
        supporting.push(item);
      } else if (stance < -0.1) {
        contradicting.push(item);
      }
      // Neutral evidence (stance near 0) is ignored
    }

    return { supporting, contradicting };
  }

  private determineStance(evidence: Evidence, claim: string): number {
    // Simple sentiment-based stance detection
    // In production, this would use more sophisticated NLP
    
    const positiveIndicators = ['confirm', 'support', 'prove', 'demonstrate', 'show', 'validate'];
    const negativeIndicators = ['contradict', 'disprove', 'refute', 'challenge', 'question', 'doubt'];
    
    const evidenceText = (evidence.claim + ' ' + evidence.supportingData).toLowerCase();
    
    let stance = 0;
    
    positiveIndicators.forEach(indicator => {
      if (evidenceText.includes(indicator)) stance += 0.2;
    });
    
    negativeIndicators.forEach(indicator => {
      if (evidenceText.includes(indicator)) stance -= 0.2;
    });
    
    // Adjust based on evidence confidence
    stance *= evidence.confidence;
    
    return Math.max(-1, Math.min(1, stance));
  }

  private calculateOverallConfidence(supporting: Evidence[], contradicting: Evidence[]): number {
    if (supporting.length === 0 && contradicting.length === 0) {
      return 0;
    }

    const supportingWeight = supporting.reduce((sum, evidence) => {
      return sum + evidence.confidence * evidence.source.credibilityScore;
    }, 0);

    const contradictingWeight = contradicting.reduce((sum, evidence) => {
      return sum + evidence.confidence * evidence.source.credibilityScore;
    }, 0);

    const totalWeight = supportingWeight + contradictingWeight;
    
    if (totalWeight === 0) return 0;

    // Confidence is higher when evidence strongly leans one way
    const supportingRatio = supportingWeight / totalWeight;
    const confidence = Math.abs(supportingRatio - 0.5) * 2; // 0 when balanced, 1 when one-sided
    
    return confidence;
  }

  private determineConsensus(
    supporting: Evidence[], 
    contradicting: Evidence[], 
    confidence: number
  ): 'strong_support' | 'weak_support' | 'neutral' | 'weak_opposition' | 'strong_opposition' {
    const supportingCount = supporting.length;
    const contradictingCount = contradicting.length;
    const totalCount = supportingCount + contradictingCount;
    
    if (totalCount === 0) return 'neutral';
    
    const supportRatio = supportingCount / totalCount;
    
    if (supportRatio >= 0.8 && confidence > 0.7) return 'strong_support';
    if (supportRatio >= 0.6) return 'weak_support';
    if (supportRatio <= 0.2 && confidence > 0.7) return 'strong_opposition';
    if (supportRatio <= 0.4) return 'weak_opposition';
    
    return 'neutral';
  }

  private extractKeyPoints(supporting: Evidence[], contradicting: Evidence[]): string[] {
    const keyPoints: string[] = [];
    
    // Extract key points from supporting evidence
    if (supporting.length > 0) {
      const topSupporting = supporting
        .sort((a, b) => (b.confidence * b.source.credibilityScore) - (a.confidence * a.source.credibilityScore))
        .slice(0, 3);
      
      keyPoints.push(`Supporting evidence from ${topSupporting.length} high-credibility sources`);
      topSupporting.forEach(evidence => {
        keyPoints.push(`• ${evidence.claim} (${evidence.source.name})`);
      });
    }
    
    // Extract key points from contradicting evidence
    if (contradicting.length > 0) {
      const topContradicting = contradicting
        .sort((a, b) => (b.confidence * b.source.credibilityScore) - (a.confidence * a.source.credibilityScore))
        .slice(0, 3);
      
      keyPoints.push(`Contradicting evidence from ${topContradicting.length} sources`);
      topContradicting.forEach(evidence => {
        keyPoints.push(`• ${evidence.claim} (${evidence.source.name})`);
      });
    }
    
    return keyPoints;
  }

  private identifyUncertainties(supporting: Evidence[], contradicting: Evidence[]): string[] {
    const uncertainties: string[] = [];
    
    // Check for low confidence evidence
    const lowConfidenceEvidence = [...supporting, ...contradicting]
      .filter(evidence => evidence.confidence < 0.6);
    
    if (lowConfidenceEvidence.length > 0) {
      uncertainties.push(`${lowConfidenceEvidence.length} pieces of evidence have low confidence scores`);
    }
    
    // Check for conflicting sources
    if (supporting.length > 0 && contradicting.length > 0) {
      uncertainties.push('Evidence sources present conflicting information');
    }
    
    // Check for verification status
    const unverifiedEvidence = [...supporting, ...contradicting]
      .filter(evidence => evidence.verificationStatus === 'unverified');
    
    if (unverifiedEvidence.length > 0) {
      uncertainties.push(`${unverifiedEvidence.length} pieces of evidence are unverified`);
    }
    
    // Check for source bias
    const biasedSources = [...supporting, ...contradicting]
      .filter(evidence => Math.abs(evidence.source.biasScore) > 0.3);
    
    if (biasedSources.length > 0) {
      uncertainties.push('Some sources may have significant bias');
    }
    
    return uncertainties;
  }

  private generateRecommendations(
    consensus: string, 
    uncertainties: string[]
  ): string[] {
    const recommendations: string[] = [];
    
    switch (consensus) {
      case 'strong_support':
        recommendations.push('Evidence strongly supports the claim');
        recommendations.push('Consider this information reliable for decision-making');
        break;
      case 'weak_support':
        recommendations.push('Evidence leans toward supporting the claim');
        recommendations.push('Seek additional verification before making critical decisions');
        break;
      case 'neutral':
        recommendations.push('Evidence is mixed or insufficient');
        recommendations.push('Gather more information before drawing conclusions');
        break;
      case 'weak_opposition':
        recommendations.push('Evidence suggests the claim may be questionable');
        recommendations.push('Exercise caution and seek alternative perspectives');
        break;
      case 'strong_opposition':
        recommendations.push('Evidence strongly contradicts the claim');
        recommendations.push('Consider this claim likely false based on available evidence');
        break;
    }
    
    // Add uncertainty-based recommendations
    if (uncertainties.length > 0) {
      recommendations.push('Key uncertainties identified - verify information independently');
      recommendations.push('Cross-reference with additional credible sources');
    }
    
    recommendations.push('Always perform your own research (DYOR) before making financial decisions');
    
    return recommendations;
  }

  // Get source credibility score
  getSourceCredibility(sourceId: string): number {
    const source = this.sources.get(sourceId);
    return source ? source.credibilityScore : 0;
  }

  // Update source credibility based on accuracy
  updateSourceCredibility(sourceId: string, accuracyScore: number): void {
    const source = this.sources.get(sourceId);
    if (source) {
      source.reliabilityHistory.push(accuracyScore);
      if (source.reliabilityHistory.length > 10) {
        source.reliabilityHistory.shift(); // Keep only last 10 scores
      }
      
      // Recalculate credibility score
      const avgReliability = source.reliabilityHistory.reduce((sum, score) => sum + score, 0) / source.reliabilityHistory.length;
      source.credibilityScore = avgReliability;
      source.lastUpdated = new Date();
    }
  }
}

// Export singleton instance
export const evidenceSynthesizer = new EvidenceSynthesizer();