import OpenAI from 'openai';
import { VietnameseNLPProcessor } from './vietnamese-nlp';
import { LogicalFallacyDetector } from './fallacy-detector';
import { DeFiKnowledgeGraph } from './knowledge-graph';
import type { ResponseContext, GeneratedResponse } from './types';

// Circuit breaker to prevent excessive API calls when quota exceeded
class CircuitBreaker {
  private isOpen = false;
  private lastFailureTime = 0;
  private failureCount = 0;
  private resetTimeout = 300000; // 5 minutes
  private failureThreshold = 3;

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.isOpen) {
      if (Date.now() - this.lastFailureTime > this.resetTimeout) {
        this.reset();
      } else {
        throw new Error('Circuit breaker is open - quota exceeded');
      }
    }

    try {
      const result = await fn();
      this.reset();
      return result;
    } catch (error: any) {
      if (error.code === 'insufficient_quota' || error.status === 429) {
        this.recordFailure();
      }
      throw error;
    }
  }

  private recordFailure() {
    this.failureCount++;
    this.lastFailureTime = Date.now();
    if (this.failureCount >= this.failureThreshold) {
      this.isOpen = true;
      console.log('🔴 Circuit breaker opened - OpenAI quota exceeded, using fallback responses');
    }
  }

  private reset() {
    this.failureCount = 0;
    this.isOpen = false;
    this.lastFailureTime = 0;
  }
}

export class ResponseGenerator {
  private openai: OpenAI;
  private nlpProcessor: VietnameseNLPProcessor;
  private fallacyDetector: LogicalFallacyDetector;
  private knowledgeGraph: DeFiKnowledgeGraph;
  private static circuitBreaker: CircuitBreaker = new CircuitBreaker();

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
    this.nlpProcessor = new VietnameseNLPProcessor();
    this.fallacyDetector = new LogicalFallacyDetector();
    this.knowledgeGraph = new DeFiKnowledgeGraph();
  }

  async generateResponse(userQuery: string): Promise<GeneratedResponse> {
    // Step 1: Analyze the user query
    const context = await this.analyzeQuery(userQuery);
    
    // Step 2: Select response strategy
    const strategy = this.selectResponseStrategy(context);
    
    // Step 3: Generate tailored response
    const response = await this.generateTailoredResponse(context, strategy);
    
    return response;
  }

  private quickLanguageDetection(text: string): string {
    const query = text.toLowerCase();
    
    // Check for Vietnamese diacritics first
    const hasVietnameseDiacritics = /[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/.test(query);
    
    // Vietnamese words that are strong indicators
    const vietnameseWords = ['sẽ', 'năm', 'này', 'có', 'không', 'tôi', 'lên', 'về', 'rủi ro', 'của', 'trong', 'trên', 'được', 'cho', 'với'];
    const vietnameseWordCount = vietnameseWords.filter(word => query.includes(word)).length;
    
    // English words that are strong indicators
    const englishWords = ['what', 'are', 'the', 'of', 'and', 'or', 'how', 'when', 'where', 'why', 'risks', 'defi', 'yield', 'farming'];
    const englishWordCount = englishWords.filter(word => query.includes(word)).length;
    
    // Decision logic
    if (hasVietnameseDiacritics || vietnameseWordCount >= 2) {
      return 'vietnamese';
    }
    
    if (englishWordCount >= 2) {
      return 'english';
    }
    
    // Default to English if unclear
    return 'english';
  }

  private async analyzeQuery(userQuery: string): Promise<ResponseContext> {
    // Parallel processing for efficiency
    const [nlpResult, fallacyResult] = await Promise.all([
      this.nlpProcessor.processVietnameseText(userQuery),
      this.fallacyDetector.detectFallacies(userQuery)
    ]);

    // Get relevant knowledge
    const relevantKnowledge = this.knowledgeGraph.analyzeTopicComprehensively(userQuery);
    
    // Find counter evidence if claims are made
    const counterEvidence = this.knowledgeGraph.findCounterEvidence(userQuery);

    return {
      userQuery,
      language: nlpResult.language,
      intent: nlpResult.intent.type,
      complexity: nlpResult.complexity,
      detectedFallacies: fallacyResult.detectedFallacies,
      relevantKnowledge,
      counterEvidence
    };
  }

  private selectResponseStrategy(context: ResponseContext): string {
    // Strategy selection based on context analysis
    if (context.detectedFallacies.length > 0) {
      return 'corrective_educational';
    }
    
    if (context.intent === 'question') {
      return 'educational_supportive';
    }
    
    if (context.intent === 'claim' || context.intent === 'argument') {
      return 'analytical_balanced';
    }
    
    if (context.complexity > 0.7) {
      return 'educational_simplified';
    }
    
    return 'supportive_informative';
  }

  private async generateTailoredResponse(
    context: ResponseContext, 
    strategy: string
  ): Promise<GeneratedResponse> {
    const systemPrompt = this.buildSystemPrompt(strategy, context.language);
    const userPrompt = this.buildUserPrompt(context);

    try {
      const response = await ResponseGenerator.circuitBreaker.execute(async () => {
        return await this.openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
          ],
          temperature: 0.7,
          max_tokens: 1000
        });
      });

      const content = response.choices[0].message.content || '';
      
      return {
        content,
        tone: this.determineTone(strategy),
        confidence: this.calculateConfidence(context),
        sources: this.extractSources(context),
        followUpQuestions: this.generateFollowUpQuestions(context),
        warnings: this.generateWarnings(context)
      };
    } catch (error) {
      // Circuit breaker or API error - use fallback
      const fallbackContext = {
        ...context,
        language: this.quickLanguageDetection(context.userQuery)
      };
      return this.generateFallbackResponse(fallbackContext);
    }
  }

  private buildSystemPrompt(strategy: string, language: string): string {
    const basePrompt = language === 'vietnamese' ? 
      'Bạn là một chuyên gia DeFi thông minh và thận trọng.' :
      'You are an intelligent and cautious DeFi expert.';

    const strategyPrompts = {
      'corrective_educational': language === 'vietnamese' ? 
        `${basePrompt} Nhiệm vụ của bạn là:
        1. Nhẹ nhàng chỉ ra các logical fallacies trong lập luận
        2. Giáo dục về DeFi một cách chính xác và cân bằng
        3. Đưa ra bằng chứng và nguồn đáng tin cậy
        4. Khuyến khích tư duy phản biện
        5. Tránh giọng điệu condescending, hãy supportive và educational` :
        `${basePrompt} Your tasks are:
        1. Gently point out logical fallacies in arguments
        2. Educate about DeFi accurately and balanced
        3. Provide evidence and credible sources
        4. Encourage critical thinking
        5. Avoid condescending tone, be supportive and educational`,
        
      'educational_supportive': language === 'vietnamese' ?
        `${basePrompt} Hãy:
        1. Trả lời câu hỏi một cách rõ ràng và dễ hiểu
        2. Đưa ra thông tin chính xác về DeFi
        3. Giải thích các khái niệm phức tạp một cách đơn giản
        4. Cảnh báo về rủi ro khi cần thiết
        5. Khuyến khích học hỏi thêm` :
        `${basePrompt} Please:
        1. Answer questions clearly and understandably
        2. Provide accurate DeFi information
        3. Explain complex concepts simply
        4. Warn about risks when necessary
        5. Encourage further learning`,
        
      'analytical_balanced': language === 'vietnamese' ?
        `${basePrompt} Phân tích:
        1. Đánh giá claim/argument một cách khách quan
        2. Đưa ra cả mặt tích cực và tiêu cực
        3. Cung cấp data và evidence cụ thể
        4. Giải thích reasoning logic
        5. Đề xuất cách tiếp cận cân bằng hơn` :
        `${basePrompt} Analyze:
        1. Evaluate claims/arguments objectively
        2. Present both positive and negative aspects
        3. Provide specific data and evidence
        4. Explain logical reasoning
        5. Suggest more balanced approaches`
    };

    return strategyPrompts[strategy as keyof typeof strategyPrompts] || strategyPrompts['educational_supportive'];
  }

  private buildUserPrompt(context: ResponseContext): string {
    let prompt = `User Query: "${context.userQuery}"\n\n`;
    
    if (context.detectedFallacies.length > 0) {
      prompt += `Detected Logical Issues:\n`;
      context.detectedFallacies.forEach(fallacy => {
        prompt += `- ${fallacy.type}: ${fallacy.explanation}\n`;
      });
      prompt += `\n`;
    }
    
    if (context.relevantKnowledge.risks.length > 0) {
      prompt += `Relevant Risks:\n`;
      context.relevantKnowledge.risks.forEach((risk: any) => {
        prompt += `- ${risk.name}: ${risk.description}\n`;
      });
      prompt += `\n`;
    }
    
    if (context.counterEvidence.length > 0) {
      prompt += `Counter Evidence Available:\n`;
      context.counterEvidence.slice(0, 3).forEach(evidence => {
        prompt += `- ${evidence.counterClaim}\n`;
      });
      prompt += `\n`;
    }
    
    prompt += `Please provide a thoughtful, balanced response that addresses the query while considering the above context.`;
    
    return prompt;
  }

  private determineTone(strategy: string): 'educational' | 'corrective' | 'supportive' | 'analytical' {
    const toneMap: Record<string, 'educational' | 'corrective' | 'supportive' | 'analytical'> = {
      'corrective_educational': 'corrective',
      'educational_supportive': 'educational',
      'analytical_balanced': 'analytical',
      'educational_simplified': 'educational',
      'supportive_informative': 'supportive'
    };
    
    return toneMap[strategy] || 'educational';
  }

  private calculateConfidence(context: ResponseContext): number {
    let confidence = 0.7; // Base confidence
    
    // Boost confidence if we have relevant knowledge
    if (context.relevantKnowledge.relevantNodes.length > 0) {
      confidence += 0.1;
    }
    
    // Boost confidence if we have evidence
    if (context.relevantKnowledge.evidence.length > 0) {
      confidence += 0.1;
    }
    
    // Reduce confidence for high complexity topics
    if (context.complexity > 0.8) {
      confidence -= 0.1;
    }
    
    // Boost confidence if we detected fallacies (we can address them)
    if (context.detectedFallacies.length > 0) {
      confidence += 0.05;
    }
    
    return Math.max(0.5, Math.min(1.0, confidence));
  }

  private extractSources(context: ResponseContext): string[] {
    const sources = new Set<string>();
    
    // Add sources from evidence
    context.relevantKnowledge.evidence.forEach((evidence: any) => {
      sources.add(evidence.source);
    });
    
    // Add sources from counter evidence
    context.counterEvidence.forEach(counter => {
      counter.evidence.forEach((evidence: any) => {
        sources.add(evidence.source);
      });
    });
    
    return Array.from(sources);
  }

  private generateFollowUpQuestions(context: ResponseContext): string[] {
    const questions: string[] = [];
    const isVietnamese = context.language === 'vietnamese';
    
    if (context.intent === 'question') {
      questions.push(
        isVietnamese ? 
        'Bạn có muốn tìm hiểu thêm về rủi ro của chiến lược này không?' :
        'Would you like to learn more about the risks of this strategy?'
      );
    }
    
    if (context.detectedFallacies.length > 0) {
      questions.push(
        isVietnamese ?
        'Bạn có muốn tôi giải thích thêm về cách đánh giá thông tin DeFi một cách khách quan không?' :
        'Would you like me to explain more about how to evaluate DeFi information objectively?'
      );
    }
    
    if (context.relevantKnowledge.relevantNodes.length > 0) {
      questions.push(
        isVietnamese ?
        'Có khía cạnh nào khác của chủ đề này bạn muốn khám phá không?' :
        'Are there other aspects of this topic you\'d like to explore?'
      );
    }
    
    return questions;
  }

  private generateWarnings(context: ResponseContext): string[] {
    const warnings: string[] = [];
    // Always use English for UI warnings since the web interface is in English
    
    // Add risk warnings if relevant
    if (context.relevantKnowledge.risks.length > 0) {
      warnings.push('Warning: DeFi involves significant risks, please research thoroughly before investing');
    }
    
    // Add fallacy warnings
    if (context.detectedFallacies.some((f: any) => f.severity === 'high')) {
      warnings.push('Warning: This information may contain logical fallacies, please verify from multiple sources');
    }
    
    return warnings;
  }

  private generateFallbackResponse(context: ResponseContext): GeneratedResponse {
    // Enhanced language detection for fallback response
    const query = context.userQuery.toLowerCase();
    const isVietnamese = context.language === 'vietnamese' || 
                        query.includes('sẽ') || query.includes('năm') || query.includes('này') || 
                        query.includes('có') || query.includes('không') || query.includes('tôi') ||
                        query.includes('lên') || query.includes('về') || query.includes('rủi ro') ||
                        /[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/.test(query);
    
    let content = '';
    
    // Generate intelligent fallback based on context analysis
    
    if (query.includes('bitcoin') || query.includes('btc') || query.includes('lên') || query.includes('$100k')) {
      content = isVietnamese ? 
        `Về Bitcoin: Đây là cryptocurrency đầu tiên và lớn nhất. Giá Bitcoin rất biến động và phụ thuộc vào nhiều yếu tố như nhu cầu thị trường, quy định, và tâm lý nhà đầu tư. Việc dự đoán giá chính xác là rất khó khăn. 
        
        📊 Về dự đoán "$100k năm nay":
        • Không ai có thể dự đoán chính xác giá crypto
        • Thị trường phụ thuộc vào nhiều biến số không kiểm soát được
        • Các prediction thường mang tính speculation cao
        
        💡 Lời khuyên đầu tư:
        • Nghiên cứu kỹ trước khi đầu tư
        • Chỉ đầu tư số tiền có thể chấp nhận mất
        • Đa dạng hóa portfolio  
        • Theo dõi tin tức và phân tích từ nhiều nguồn
        • Tránh FOMO (Fear of Missing Out)` :
        `About Bitcoin: It's the first and largest cryptocurrency. Bitcoin price is highly volatile and depends on market demand, regulations, and investor sentiment. Accurate price prediction is very difficult.
        
        📊 About "$100k this year" prediction:
        • No one can accurately predict crypto prices
        • Market depends on many uncontrollable variables
        • Such predictions are often highly speculative
        
        💡 Investment Advice:
        • Research thoroughly before investing
        • Only invest what you can afford to lose
        • Diversify your portfolio
        • Follow news and analysis from multiple sources
        • Avoid FOMO (Fear of Missing Out)`;
        
    } else if (query.includes('defi') || query.includes('yield') || query.includes('farming')) {
      content = isVietnamese ?
        `Về DeFi và Yield Farming: DeFi (Decentralized Finance) mang lại cơ hội cao nhưng cũng có rủi ro lớn:
        
        🔴 Rủi ro chính:
        • Impermanent Loss khi cung cấp thanh khoản
        • Smart contract bugs và hacks
        • Token price volatility
        • Regulatory risks
        
        💡 Lời khuyên:
        • Hiểu rõ protocol trước khi tham gia
        • Bắt đầu với số tiền nhỏ
        • Đa dạng hóa across multiple protocols
        • Monitor positions thường xuyên` :
        `About DeFi and Yield Farming: DeFi offers high opportunities but also high risks:
        
        🔴 Main Risks:
        • Impermanent Loss when providing liquidity
        • Smart contract bugs and hacks
        • Token price volatility
        • Regulatory risks
        
        💡 Advice:
        • Understand protocols before participating
        • Start with small amounts
        • Diversify across multiple protocols
        • Monitor positions regularly`;
        
    } else if (query.includes('safe') || query.includes('an toàn') || query.includes('risk') || query.includes('rủi ro')) {
      content = isVietnamese ?
        `Về an toàn trong DeFi: Không có đầu tư nào hoàn toàn an toàn, đặc biệt trong DeFi:
        
        ⚠️ Các rủi ro thường gặp:
        • Smart contract vulnerabilities
        • Rug pulls và exit scams
        • Flash loan attacks
        • Bridge hacks
        • Regulatory changes
        
        🛡️ Cách giảm rủi ro:
        • Chỉ sử dụng protocols đã được audit
        • Kiểm tra team và community
        • Đọc documentation kỹ
        • Bắt đầu với established protocols
        • Never invest more than you can afford to lose` :
        `About DeFi Safety: No investment is completely safe, especially in DeFi:
        
        ⚠️ Common Risks:
        • Smart contract vulnerabilities
        • Rug pulls and exit scams
        • Flash loan attacks
        • Bridge hacks
        • Regulatory changes
        
        🛡️ Risk Mitigation:
        • Only use audited protocols
        • Check team and community
        • Read documentation carefully
        • Start with established protocols
        • Never invest more than you can afford to lose`;
        
    } else {
      content = isVietnamese ?
        `Tôi hiện đang gặp vấn đề kỹ thuật với AI engine chính. Tuy nhiên, tôi có thể giúp bạn với:
        
        • Phân tích logical fallacies trong lập luận DeFi
        • Thông tin cơ bản về protocols và risks
        • Hướng dẫn về yield farming và staking
        • Giải thích các khái niệm DeFi
        
        Bạn có thể hỏi cụ thể hơn về chủ đề nào đó không?` :
        `I'm currently experiencing technical issues with the main AI engine. However, I can help you with:
        
        • Analyzing logical fallacies in DeFi arguments
        • Basic information about protocols and risks
        • Guidance on yield farming and staking
        • Explaining DeFi concepts
        
        Could you ask more specifically about a particular topic?`;
    }
    
    // Detect and warn about potential fallacies
    const warnings = this.generateWarnings(context);
    if (context.detectedFallacies.length > 0) {
      // Always use English for UI warnings since the web interface is in English
      const fallacyWarning = 'Note: Logical fallacy detected in the question. Be careful with the reasoning.';
      warnings.unshift(fallacyWarning);
    }
    
    return {
      content,
      tone: 'educational',
      confidence: 0.8,
      sources: ['Fallback knowledge base', 'DeFi risk assessment'],
      followUpQuestions: this.generateFollowUpQuestions(context),
      warnings
    };
  }
}