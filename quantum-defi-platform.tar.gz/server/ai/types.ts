// Shared types for Counter-Argument Engine
export interface CryptoTerm {
  vietnamese: string;
  english: string;
  category: string;
  definition: string;
  confidence: number;
}

export interface ProcessedText {
  tokens: string[];
  entities: Array<{
    text: string;
    type: string;
    position: [number, number];
    confidence: number;
  }>;
  sentiment: {
    score: number;
    label: 'positive' | 'negative' | 'neutral';
    confidence: number;
  };
  cryptoTerms: CryptoTerm[];
  intent: {
    type: string;
    confidence: number;
    category: string;
  };
  complexity: number;
  language: 'vietnamese' | 'english' | 'mixed';
}

export interface DetectedFallacy {
  type: string;
  method: 'pattern' | 'ml' | 'structural';
  match?: string;
  position?: [number, number];
  confidence: number;
  explanation: string;
  severity: 'low' | 'medium' | 'high';
  suggestions: string[];
}

export interface ArgumentStructure {
  premises: string[];
  conclusion: string;
  evidenceTypes: string[];
  logicalConnectors: string[];
  strength: number;
}

export interface DeFiKnowledgeNode {
  id: string;
  type: 'protocol' | 'concept' | 'risk' | 'mechanism' | 'token' | 'network';
  name: string;
  description: string;
  properties: Record<string, any>;
  relationships: string[];
  evidenceStrength: number;
  lastUpdated: Date;
}

export interface EvidenceItem {
  id: string;
  claim: string;
  evidence: string;
  source: string;
  credibility: number;
  type: 'data' | 'expert_opinion' | 'research' | 'historical' | 'theoretical';
  dateAdded: Date;
  supportingNodes: string[];
}

export interface CounterEvidence {
  originalClaim: string;
  counterClaim: string;
  evidence: EvidenceItem[];
  strength: number;
  reasoning: string;
}

export interface ResponseContext {
  userQuery: string;
  language: 'vietnamese' | 'english' | 'mixed';
  intent: string;
  complexity: number;
  detectedFallacies: DetectedFallacy[];
  relevantKnowledge: any;
  counterEvidence: CounterEvidence[];
}

export interface GeneratedResponse {
  content: string;
  tone: 'educational' | 'corrective' | 'supportive' | 'analytical';
  confidence: number;
  sources: string[];
  followUpQuestions: string[];
  warnings: string[];
}