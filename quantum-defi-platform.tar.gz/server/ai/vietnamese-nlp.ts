import OpenAI from 'openai';
import type { CryptoTerm, ProcessedText } from './types';

export class VietnameseNLPProcessor {
  private openai: OpenAI;
  private cryptoVocabulary: CryptoTerm[] = [];
  private defiConcepts: Map<string, any> = new Map();

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
    this.initializeCryptoVocabulary();
    this.initializeDefiConcepts();
  }

  private initializeCryptoVocabulary(): void {
    this.cryptoVocabulary = [
      // DeFi Terms
      { vietnamese: 'tài chính phi tập trung', english: 'decentralized finance', category: 'defi', definition: 'Hệ thống tài chính không có trung gian', confidence: 1.0 },
      { vietnamese: 'defi', english: 'defi', category: 'defi', definition: 'Decentralized Finance', confidence: 1.0 },
      { vietnamese: 'yield farming', english: 'yield farming', category: 'defi', definition: 'Hoạt động kiếm lợi nhuận từ việc cung cấp thanh khoản', confidence: 1.0 },
      { vietnamese: 'canh tác lợi nhuận', english: 'yield farming', category: 'defi', definition: 'Hoạt động kiếm lợi nhuận từ việc cung cấp thanh khoản', confidence: 1.0 },
      { vietnamese: 'thanh khoản', english: 'liquidity', category: 'defi', definition: 'Khả năng chuyển đổi tài sản thành tiền mặt', confidence: 1.0 },
      { vietnamese: 'staking', english: 'staking', category: 'defi', definition: 'Khóa token để kiếm phần thưởng', confidence: 1.0 },
      { vietnamese: 'đặt cược', english: 'staking', category: 'defi', definition: 'Khóa token để kiếm phần thưởng', confidence: 1.0 },
      
      // Trading Terms
      { vietnamese: 'apy', english: 'apy', category: 'finance', definition: 'Annual Percentage Yield - Lợi suất hàng năm', confidence: 1.0 },
      { vietnamese: 'lợi suất hàng năm', english: 'annual percentage yield', category: 'finance', definition: 'Lợi nhuận dự kiến trong một năm', confidence: 1.0 },
      { vietnamese: 'impermanent loss', english: 'impermanent loss', category: 'defi', definition: 'Tổn thất tạm thời khi cung cấp thanh khoản', confidence: 1.0 },
      { vietnamese: 'tổn thất tạm thời', english: 'impermanent loss', category: 'defi', definition: 'Tổn thất tạm thời khi cung cấp thanh khoản', confidence: 1.0 },
      { vietnamese: 'slippage', english: 'slippage', category: 'trading', definition: 'Chênh lệch giá khi thực hiện giao dịch', confidence: 1.0 },
      { vietnamese: 'trượt giá', english: 'slippage', category: 'trading', definition: 'Chênh lệch giá khi thực hiện giao dịch', confidence: 1.0 },

      // Blockchain Terms  
      { vietnamese: 'hợp đồng thông minh', english: 'smart contract', category: 'blockchain', definition: 'Chương trình tự động thực thi trên blockchain', confidence: 1.0 },
      { vietnamese: 'smart contract', english: 'smart contract', category: 'blockchain', definition: 'Chương trình tự động thực thi trên blockchain', confidence: 1.0 },
      { vietnamese: 'gas fee', english: 'gas fee', category: 'blockchain', definition: 'Phí giao dịch trên blockchain', confidence: 1.0 },
      { vietnamese: 'phí gas', english: 'gas fee', category: 'blockchain', definition: 'Phí giao dịch trên blockchain', confidence: 1.0 },
      { vietnamese: 'mev', english: 'mev', category: 'blockchain', definition: 'Maximal Extractable Value', confidence: 1.0 },
      { vietnamese: 'giá trị khai thác tối đa', english: 'maximal extractable value', category: 'blockchain', definition: 'Giá trị tối đa có thể trích xuất từ block', confidence: 1.0 },

      // Protocol Names
      { vietnamese: 'uniswap', english: 'uniswap', category: 'protocol', definition: 'Sàn giao dịch phi tập trung hàng đầu', confidence: 1.0 },
      { vietnamese: 'compound', english: 'compound', category: 'protocol', definition: 'Giao thức cho vay phi tập trung', confidence: 1.0 },
      { vietnamese: 'aave', english: 'aave', category: 'protocol', definition: 'Nền tảng cho vay và đi vay phi tập trung', confidence: 1.0 },
      { vietnamese: 'makerdao', english: 'makerdao', category: 'protocol', definition: 'Giao thức tạo stablecoin DAI', confidence: 1.0 },

      // Risk Terms
      { vietnamese: 'rủi ro', english: 'risk', category: 'risk', definition: 'Khả năng tổn thất trong đầu tư', confidence: 1.0 },
      { vietnamese: 'audit', english: 'audit', category: 'security', definition: 'Kiểm toán bảo mật smart contract', confidence: 1.0 },
      { vietnamese: 'kiểm toán', english: 'audit', category: 'security', definition: 'Kiểm tra bảo mật smart contract', confidence: 1.0 },
      { vietnamese: 'rug pull', english: 'rug pull', category: 'risk', definition: 'Lừa đảo rút thanh khoản đột ngột', confidence: 1.0 },
      { vietnamese: 'lừa đảo', english: 'scam', category: 'risk', definition: 'Hành vi gian lận, lừa đảo', confidence: 1.0 },
    ];
  }

  private initializeDefiConcepts(): void {
    this.defiConcepts = new Map([
      ['yield_farming', {
        definition: 'Hoạt động cung cấp thanh khoản để kiếm phần thưởng',
        risks: ['impermanent loss', 'smart contract risk', 'market volatility'],
        benefits: ['passive income', 'high apy potential', 'protocol rewards'],
        complexity: 'intermediate'
      }],
      ['staking', {
        definition: 'Khóa token để bảo mật mạng và kiếm phần thưởng',
        risks: ['slashing risk', 'lock-up period', 'validator risk'],
        benefits: ['network security', 'predictable rewards', 'governance rights'],
        complexity: 'beginner'
      }],
      ['impermanent_loss', {
        definition: 'Tổn thất tạm thời khi giá token trong pool thay đổi',
        causes: ['price divergence', 'arbitrage activity', 'market volatility'],
        mitigation: ['stable pairs', 'correlated assets', 'short duration'],
        complexity: 'advanced'
      }]
    ]);
  }

  async processVietnameseText(text: string): Promise<ProcessedText> {
    const [
      tokens,
      entities,
      sentiment,
      cryptoTerms,
      intent,
      complexity,
      language
    ] = await Promise.all([
      this.tokenizeVietnamese(text),
      this.extractEntities(text),
      this.analyzeSentiment(text),
      this.identifyCryptoTerms(text),
      this.classifyIntent(text),
      this.assessComplexity(text),
      this.detectLanguage(text)
    ]);

    return {
      tokens,
      entities,
      sentiment,
      cryptoTerms,
      intent,
      complexity,
      language
    };
  }

  private async tokenizeVietnamese(text: string): Promise<string[]> {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{
          role: "system",
          content: `You are a Vietnamese tokenizer. Split the text into meaningful Vietnamese words and phrases. Return only a JSON array of tokens.`
        }, {
          role: "user", 
          content: text
        }],
        temperature: 0
      });

      const result = response.choices[0].message.content;
      return JSON.parse(result || '[]');
    } catch (error) {
      // Fallback: simple space-based tokenization
      return text.split(/\s+/).filter(token => token.length > 0);
    }
  }

  private async extractEntities(text: string): Promise<Array<{text: string, type: string, position: [number, number], confidence: number}>> {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{
          role: "system",
          content: `Extract named entities from Vietnamese/English text. Focus on:
          - PERSON: People names, influencers, developers
          - ORG: Companies, protocols, exchanges  
          - CRYPTO: Cryptocurrencies, tokens
          - PROTOCOL: DeFi protocols, platforms
          - CONCEPT: DeFi/blockchain concepts
          
          Return JSON array: [{"text": "entity", "type": "TYPE", "position": [start, end], "confidence": 0.9}]`
        }, {
          role: "user",
          content: text
        }],
        temperature: 0
      });

      const result = response.choices[0].message.content;
      return JSON.parse(result || '[]');
    } catch (error) {
      return [];
    }
  }

  private async analyzeSentiment(text: string): Promise<{score: number, label: 'positive' | 'negative' | 'neutral', confidence: number}> {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{
          role: "system",
          content: `Analyze sentiment of Vietnamese/English text about DeFi/crypto. Consider:
          - Positive: bullish, optimistic, confident
          - Negative: bearish, fearful, skeptical  
          - Neutral: informational, balanced
          
          Return JSON: {"score": float(-1 to 1), "label": "positive/negative/neutral", "confidence": float(0-1)}`
        }, {
          role: "user",
          content: text
        }],
        temperature: 0
      });

      const result = response.choices[0].message.content;
      return JSON.parse(result || '{"score": 0, "label": "neutral", "confidence": 0.5}');
    } catch (error) {
      return { score: 0, label: 'neutral', confidence: 0.5 };
    }
  }

  private identifyCryptoTerms(text: string): CryptoTerm[] {
    const identified: CryptoTerm[] = [];
    const lowerText = text.toLowerCase();

    for (const term of this.cryptoVocabulary) {
      const vietnameseMatch = lowerText.includes(term.vietnamese.toLowerCase());
      const englishMatch = lowerText.includes(term.english.toLowerCase());
      
      if (vietnameseMatch || englishMatch) {
        identified.push({
          ...term,
          confidence: this.calculateTermConfidence(text, term)
        });
      }
    }

    return identified;
  }

  private calculateTermConfidence(text: string, term: CryptoTerm): number {
    const contextWords = this.extractContext(text, term);
    let confidence = term.confidence;

    // Boost confidence if term appears with related context
    const relatedTerms = this.getRelatedTerms(term.category);
    for (const related of relatedTerms) {
      if (contextWords.includes(related)) {
        confidence = Math.min(1.0, confidence + 0.1);
      }
    }

    return confidence;
  }

  private extractContext(text: string, term: CryptoTerm): string[] {
    const termPosition = text.toLowerCase().indexOf(term.vietnamese.toLowerCase()) || 
                        text.toLowerCase().indexOf(term.english.toLowerCase());
    
    if (termPosition === -1) return [];

    const contextStart = Math.max(0, termPosition - 50);
    const contextEnd = Math.min(text.length, termPosition + 50);
    const context = text.slice(contextStart, contextEnd);
    
    return context.toLowerCase().split(/\s+/);
  }

  private getRelatedTerms(category: string): string[] {
    const relatedTermsMap: Record<string, string[]> = {
      'defi': ['protocol', 'yield', 'liquidity', 'farming', 'pool'],
      'trading': ['price', 'volume', 'exchange', 'swap', 'order'],
      'blockchain': ['transaction', 'block', 'network', 'node', 'consensus'],
      'risk': ['loss', 'volatility', 'security', 'audit', 'safe'],
      'finance': ['interest', 'return', 'profit', 'investment', 'capital']
    };

    return relatedTermsMap[category] || [];
  }

  private async classifyIntent(text: string): Promise<{type: string, confidence: number, category: string}> {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{
          role: "system",
          content: `Classify the intent of Vietnamese/English text about DeFi/crypto:

          TYPES:
          - question: Asking for information or clarification
          - claim: Making a statement or assertion  
          - argument: Presenting reasoning or evidence
          - opinion: Expressing personal views
          - instruction: Giving directions or advice
          - complaint: Expressing dissatisfaction
          - compliment: Expressing praise or satisfaction

          CATEGORIES:
          - investment: Investment advice, strategies, returns
          - technical: Protocol mechanics, blockchain technology
          - risk: Security, audits, potential losses
          - market: Price analysis, trends, predictions
          - education: Learning, explanations, tutorials
          - speculation: Rumors, unverified claims
          
          Return JSON: {"type": "TYPE", "confidence": float(0-1), "category": "CATEGORY"}`
        }, {
          role: "user",
          content: text
        }],
        temperature: 0
      });

      const result = response.choices[0].message.content;
      return JSON.parse(result || '{"type": "question", "confidence": 0.5, "category": "general"}');
    } catch (error) {
      return { type: 'question', confidence: 0.5, category: 'general' };
    }
  }

  private assessComplexity(text: string): number {
    // Simple complexity scoring based on:
    // - Text length
    // - Technical terms count
    // - Sentence structure
    
    const words = text.split(/\s+/);
    const sentences = text.split(/[.!?]+/);
    const avgWordsPerSentence = words.length / sentences.length;
    
    const technicalTerms = this.identifyCryptoTerms(text);
    const technicalDensity = technicalTerms.length / words.length;
    
    let complexity = 0;
    
    // Length factor (0-0.3)
    if (words.length > 100) complexity += 0.3;
    else if (words.length > 50) complexity += 0.2;
    else if (words.length > 20) complexity += 0.1;
    
    // Technical density factor (0-0.4)
    complexity += technicalDensity * 4;
    
    // Sentence complexity factor (0-0.3)  
    if (avgWordsPerSentence > 20) complexity += 0.3;
    else if (avgWordsPerSentence > 15) complexity += 0.2;
    else if (avgWordsPerSentence > 10) complexity += 0.1;
    
    return Math.min(1.0, complexity);
  }

  private detectLanguage(text: string): 'vietnamese' | 'english' | 'mixed' {
    // Enhanced Vietnamese detection with common words and diacritics
    const vietnameseChars = (text.match(/[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/gi) || []).length;
    
    // Common Vietnamese words that strongly indicate Vietnamese language
    const vietnameseWords = [
      'tôi', 'bạn', 'anh', 'chị', 'em', 'chúng', 'mình', 'năm', 'này', 'đó', 'thì', 'là', 'có', 'không', 'được', 'cho', 'với', 'của', 'trong', 'trên', 'dưới', 
      'sẽ', 'đã', 'đang', 'vừa', 'về', 'từ', 'đến', 'nên', 'phải', 'thể', 'những', 'các', 'nhiều', 'ít', 'lớn', 'nhỏ', 'tốt', 'xấu', 'cao', 'thấp',
      'bitcoin', 'defi', 'rủi ro', 'an toàn', 'lên', 'xuống', 'mua', 'bán', 'đầu tư'
    ];
    
    const lowerText = text.toLowerCase();
    let vietnameseWordCount = 0;
    
    for (const word of vietnameseWords) {
      if (lowerText.includes(word)) {
        vietnameseWordCount++;
      }
    }
    
    const totalChars = text.replace(/[^a-zA-Zàáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/gi, '').length;
    
    // If we have Vietnamese words or diacritics, it's likely Vietnamese
    if (vietnameseWordCount >= 2 || vietnameseChars > 0) {
      return 'vietnamese';
    }
    
    if (totalChars === 0) return 'english';
    
    const vietnameseRatio = vietnameseChars / totalChars;
    
    if (vietnameseRatio > 0.1) return 'mixed';
    return 'english';
  }
}