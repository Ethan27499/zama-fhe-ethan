// Counter-Argument Engine - Main Interface
export { VietnameseNLPProcessor } from './vietnamese-nlp';
export { LogicalFallacyDetector } from './fallacy-detector';  
export { DeFiKnowledgeGraph } from './knowledge-graph';
export { ResponseGenerator } from './response-generator';

// Re-export types (commented out for now to avoid circular dependencies)
// export type {
//   ProcessedText,
//   CryptoTerm,
//   DetectedFallacy,
//   ArgumentStructure,
//   DeFiKnowledgeNode,
//   EvidenceItem,
//   CounterEvidence,
//   ResponseContext,
//   GeneratedResponse
// } from './vietnamese-nlp';

import { ResponseGenerator } from './response-generator';

// Main Counter-Argument Engine class that orchestrates all components
export class CounterArgumentEngine {
  private responseGenerator: ResponseGenerator;

  constructor() {
    this.responseGenerator = new ResponseGenerator();
  }

  async processUserInput(input: string): Promise<{
    response: string;
    analysis: {
      language: string;
      fallacies: any[];
      knowledge: any;
      confidence: number;
    };
    metadata: {
      processingTime: number;
      sources: string[];
      warnings: string[];
    };
  }> {
    const startTime = Date.now();
    
    try {
      const result = await this.responseGenerator.generateResponse(input);
      
      const processingTime = Date.now() - startTime;
      
      return {
        response: result.content,
        analysis: {
          language: this.detectLanguageFromInput(input),
          fallacies: [], // Will be populated by actual analysis
          knowledge: {}, // Will be populated by knowledge graph
          confidence: result.confidence
        },
        metadata: {
          processingTime,
          sources: result.sources,
          warnings: result.warnings
        }
      };
    } catch (error) {
      console.error('Counter-Argument Engine error:', error);
      
      // Detect language for error message
      const isVietnamese = input.includes('sẽ') || input.includes('năm') || input.includes('này') || 
                          input.includes('có') || input.includes('không') || input.includes('tôi') ||
                          /[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/.test(input);
      
      return {
        response: isVietnamese ? 
          'Xin lỗi, tôi gặp sự cố khi xử lý yêu cầu của bạn. Vui lòng thử lại.' :
          'Sorry, I encountered an error processing your request. Please try again.',
        analysis: {
          language: isVietnamese ? 'vietnamese' : 'english',
          fallacies: [],
          knowledge: {},
          confidence: 0
        },
        metadata: {
          processingTime: Date.now() - startTime,
          sources: [],
          warnings: ['System error occurred']
        }
      };
    }
  }

  private detectLanguageFromInput(input: string): string {
    const query = input.toLowerCase();
    
    // Check for Vietnamese diacritics first
    const hasVietnameseDiacritics = /[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/.test(query);
    
    // Vietnamese words that are strong indicators
    const vietnameseWords = ['sẽ', 'năm', 'này', 'có', 'không', 'tôi', 'lên', 'về', 'rủi ro', 'của', 'trong', 'trên', 'được', 'cho', 'với'];
    const vietnameseWordCount = vietnameseWords.filter(word => query.includes(word)).length;
    
    // English words that are strong indicators
    const englishWords = ['what', 'are', 'the', 'of', 'and', 'or', 'how', 'when', 'where', 'why', 'risks', 'defi', 'yield', 'farming'];
    const englishWordCount = englishWords.filter(word => query.includes(word)).length;
    
    // Decision logic
    if (hasVietnameseDiacritics || vietnameseWordCount >= 2) {
      return 'vietnamese';
    }
    
    if (englishWordCount >= 2) {
      return 'english';
    }
    
    // Default to English if unclear
    return 'english';
  }

  // Health check method for the engine
  async healthCheck(): Promise<{
    status: 'healthy' | 'degraded' | 'unhealthy';
    components: Record<string, boolean>;
    version: string;
  }> {
    try {
      // Test each component
      const testInput = "Bitcoin is the best investment";
      const result = await this.responseGenerator.generateResponse(testInput);
      
      return {
        status: 'healthy',
        components: {
          nlpProcessor: true,
          fallacyDetector: true,
          knowledgeGraph: true,
          responseGenerator: true,
          openaiApi: result.confidence > 0
        },
        version: '1.0.0'
      };
    } catch (error) {
      return {
        status: 'unhealthy', 
        components: {
          nlpProcessor: false,
          fallacyDetector: false,
          knowledgeGraph: false,
          responseGenerator: false,
          openaiApi: false
        },
        version: '1.0.0'
      };
    }
  }
}

// Export singleton instance
export const counterArgumentEngine = new CounterArgumentEngine();