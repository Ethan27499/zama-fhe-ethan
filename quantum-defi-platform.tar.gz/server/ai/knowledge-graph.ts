import type { DeFiKnowledgeNode, EvidenceItem, CounterEvidence } from './types';

export class DeFiKnowledgeGraph {
  private nodes: Map<string, DeFiKnowledgeNode>;
  private evidenceDatabase: Map<string, EvidenceItem>;
  private relationships: Map<string, string[]>;

  constructor() {
    this.nodes = new Map();
    this.evidenceDatabase = new Map();
    this.relationships = new Map();
    this.initializeKnowledgeBase();
  }

  private initializeKnowledgeBase(): void {
    // Initialize core DeFi concepts
    this.addProtocolNodes();
    this.addConceptNodes();
    this.addRiskNodes();
    this.addMechanismNodes();
    this.addTokenNodes();
    this.addNetworkNodes();
    this.addEvidenceItems();
    this.establishRelationships();
  }

  private addProtocolNodes(): void {
    const protocols = [
      {
        id: 'uniswap',
        name: 'Uniswap',
        description: 'Automated Market Maker (AMM) protocol for token swapping',
        properties: {
          type: 'DEX',
          tvl: 'variable',
          auditStatus: 'audited',
          governance: 'DAO',
          risks: ['impermanent_loss', 'smart_contract_risk'],
          benefits: ['permissionless', 'composable', 'decentralized']
        }
      },
      {
        id: 'compound',
        name: 'Compound',
        description: 'Algorithmic money market protocol for lending and borrowing',
        properties: {
          type: 'Lending',
          mechanism: 'algorithmic_interest_rates',
          governance: 'token_based',
          risks: ['liquidation_risk', 'interest_rate_volatility'],
          benefits: ['passive_income', 'collateralized_loans']
        }
      },
      {
        id: 'aave',
        name: 'Aave',
        description: 'Open-source liquidity protocol for earning interest and borrowing',
        properties: {
          type: 'Lending',
          features: ['flash_loans', 'stable_rates', 'variable_rates'],
          governance: 'AAVE_token',
          risks: ['smart_contract_risk', 'liquidation_risk', 'governance_risk'],
          benefits: ['diverse_assets', 'innovative_features', 'strong_community']
        }
      }
    ];

    protocols.forEach(protocol => {
      this.nodes.set(protocol.id, {
        id: protocol.id,
        type: 'protocol',
        name: protocol.name,
        description: protocol.description,
        properties: protocol.properties,
        relationships: [],
        evidenceStrength: 0.9,
        lastUpdated: new Date()
      });
    });
  }

  private addConceptNodes(): void {
    const concepts = [
      {
        id: 'yield_farming',
        name: 'Yield Farming',
        description: 'Strategy of earning rewards by providing liquidity to DeFi protocols',
        properties: {
          complexity: 'intermediate',
          riskLevel: 'medium_high',
          timeCommitment: 'active_management',
          typicalReturns: '5-100% APY',
          mechanisms: ['liquidity_provision', 'token_rewards', 'fee_earning']
        }
      },
      {
        id: 'impermanent_loss',
        name: 'Impermanent Loss',
        description: 'Temporary loss experienced by liquidity providers due to price divergence',
        properties: {
          cause: 'price_divergence',
          severity: 'depends_on_volatility',
          mitigation: ['correlated_pairs', 'stable_pairs', 'short_duration'],
          calculation: 'mathematical_formula',
          reversibility: 'yes_if_prices_revert'
        }
      },
      {
        id: 'total_value_locked',
        name: 'Total Value Locked (TVL)',
        description: 'Total amount of assets deposited in a DeFi protocol',
        properties: {
          metric_type: 'liquidity_indicator',
          reliability: 'high_for_established_protocols',
          limitations: ['double_counting', 'price_fluctuations', 'withdrawn_anytime'],
          useCase: 'protocol_comparison'
        }
      }
    ];

    concepts.forEach(concept => {
      this.nodes.set(concept.id, {
        id: concept.id,
        type: 'concept',
        name: concept.name,
        description: concept.description,
        properties: concept.properties,
        relationships: [],
        evidenceStrength: 0.95,
        lastUpdated: new Date()
      });
    });
  }

  private addRiskNodes(): void {
    const risks = [
      {
        id: 'smart_contract_risk',
        name: 'Smart Contract Risk',
        description: 'Risk of bugs, exploits, or vulnerabilities in smart contract code',
        properties: {
          severity: 'high',
          mitigation: ['audits', 'bug_bounties', 'gradual_rollout', 'time_testing'],
          indicators: ['audit_reports', 'bug_bounty_programs', 'time_in_production'],
          examples: ['DAO_hack', 'parity_wallet', 'various_defi_exploits']
        }
      },
      {
        id: 'liquidation_risk',
        name: 'Liquidation Risk',
        description: 'Risk of collateral being liquidated due to price movements',
        properties: {
          triggers: ['price_drop', 'volatility_spike', 'oracle_failure'],
          prevention: ['over_collateralization', 'monitoring', 'partial_repayment'],
          severity: 'medium_to_high',
          recoverable: 'partially'
        }
      },
      {
        id: 'regulatory_risk',
        name: 'Regulatory Risk',
        description: 'Risk of changing regulations affecting DeFi protocols',
        properties: {
          predictability: 'low',
          impact: 'potentially_severe',
          geography: 'varies_by_jurisdiction',
          mitigation: ['decentralization', 'compliance_frameworks', 'legal_analysis']
        }
      }
    ];

    risks.forEach(risk => {
      this.nodes.set(risk.id, {
        id: risk.id,
        type: 'risk',
        name: risk.name,
        description: risk.description,
        properties: risk.properties,
        relationships: [],
        evidenceStrength: 0.9,
        lastUpdated: new Date()
      });
    });
  }

  private addMechanismNodes(): void {
    const mechanisms = [
      {
        id: 'automated_market_maker',
        name: 'Automated Market Maker (AMM)',
        description: 'Algorithm that provides liquidity and determines prices automatically',
        properties: {
          formula: 'x * y = k (constant product)',
          advantages: ['permissionless', 'always_available', 'price_discovery'],
          disadvantages: ['impermanent_loss', 'slippage', 'MEV_vulnerability'],
          variants: ['constant_product', 'constant_sum', 'hybrid_models']
        }
      },
      {
        id: 'flash_loans',
        name: 'Flash Loans',
        description: 'Uncollateralized loans that must be repaid within the same transaction',
        properties: {
          collateral: 'none_required',
          duration: 'single_transaction',
          use_cases: ['arbitrage', 'liquidations', 'refinancing'],
          risks: ['complexity', 'MEV', 'failed_transactions']
        }
      }
    ];

    mechanisms.forEach(mechanism => {
      this.nodes.set(mechanism.id, {
        id: mechanism.id,
        type: 'mechanism',
        name: mechanism.name,
        description: mechanism.description,
        properties: mechanism.properties,
        relationships: [],
        evidenceStrength: 0.95,
        lastUpdated: new Date()
      });
    });
  }

  private addTokenNodes(): void {
    const tokens = [
      {
        id: 'governance_tokens',
        name: 'Governance Tokens',
        description: 'Tokens that provide voting rights in protocol governance',
        properties: {
          purpose: 'decentralized_governance',
          value_accrual: ['fees', 'buybacks', 'staking_rewards'],
          risks: ['governance_attacks', 'low_participation', 'regulatory_uncertainty'],
          examples: ['UNI', 'COMP', 'AAVE', 'MKR']
        }
      },
      {
        id: 'stablecoins',
        name: 'Stablecoins',
        description: 'Cryptocurrencies designed to maintain stable value relative to reference asset',
        properties: {
          types: ['fiat_collateralized', 'crypto_collateralized', 'algorithmic'],
          use_cases: ['medium_of_exchange', 'store_of_value', 'unit_of_account'],
          risks: ['depeg_risk', 'counterparty_risk', 'regulatory_risk'],
          examples: ['USDC', 'DAI', 'USDT', 'FRAX']
        }
      }
    ];

    tokens.forEach(token => {
      this.nodes.set(token.id, {
        id: token.id,
        type: 'token',
        name: token.name,
        description: token.description,
        properties: token.properties,
        relationships: [],
        evidenceStrength: 0.9,
        lastUpdated: new Date()
      });
    });
  }

  private addNetworkNodes(): void {
    const networks = [
      {
        id: 'ethereum',
        name: 'Ethereum',
        description: 'Programmable blockchain platform for smart contracts and DeFi',
        properties: {
          consensus: 'proof_of_stake',
          advantages: ['largest_ecosystem', 'battle_tested', 'network_effects'],
          disadvantages: ['high_fees', 'scalability_limits', 'energy_usage'],
          layer2s: ['arbitrum', 'optimism', 'polygon']
        }
      },
      {
        id: 'layer2_solutions',
        name: 'Layer 2 Solutions',
        description: 'Scaling solutions that operate on top of Ethereum mainnet',
        properties: {
          types: ['optimistic_rollups', 'zk_rollups', 'sidechains'],
          benefits: ['lower_fees', 'faster_transactions', 'ethereum_security'],
          tradeoffs: ['additional_complexity', 'liquidity_fragmentation', 'exit_delays']
        }
      }
    ];

    networks.forEach(network => {
      this.nodes.set(network.id, {
        id: network.id,
        type: 'network',
        name: network.name,
        description: network.description,
        properties: network.properties,
        relationships: [],
        evidenceStrength: 0.95,
        lastUpdated: new Date()
      });
    });
  }

  private addEvidenceItems(): void {
    const evidenceItems = [
      {
        id: 'uniswap_audit_2023',
        claim: 'Uniswap V3 is secure and audited',
        evidence: 'Multiple security audits by Trail of Bits, Consensys Diligence, and ABDK',
        source: 'Official Uniswap documentation and audit reports',
        credibility: 0.9,
        type: 'expert_opinion' as const,
        supportingNodes: ['uniswap', 'smart_contract_risk']
      },
      {
        id: 'impermanent_loss_data',
        claim: 'Impermanent loss can be significant in volatile markets',
        evidence: 'Bancor study shows 50% of LPs on Uniswap lose money due to impermanent loss',
        source: 'Bancor Research Report 2021',
        credibility: 0.8,
        type: 'data' as const,
        supportingNodes: ['impermanent_loss', 'yield_farming']
      },
      {
        id: 'defi_hack_statistics',
        claim: 'DeFi protocols face significant smart contract risks',
        evidence: '$3.8 billion lost to DeFi hacks in 2022 according to DeFiLlama',
        source: 'DeFiLlama hack database',
        credibility: 0.85,
        type: 'data' as const,
        supportingNodes: ['smart_contract_risk']
      }
    ];

    evidenceItems.forEach(item => {
      this.evidenceDatabase.set(item.id, {
        id: item.id,
        claim: item.claim,
        evidence: item.evidence,
        source: item.source,
        credibility: item.credibility,
        type: item.type,
        dateAdded: new Date(),
        supportingNodes: item.supportingNodes
      });
    });
  }

  private establishRelationships(): void {
    // Define relationships between nodes
    const relationships = [
      { from: 'uniswap', to: ['automated_market_maker', 'impermanent_loss', 'governance_tokens'] },
      { from: 'yield_farming', to: ['impermanent_loss', 'smart_contract_risk', 'uniswap', 'compound'] },
      { from: 'impermanent_loss', to: ['automated_market_maker', 'yield_farming'] },
      { from: 'smart_contract_risk', to: ['uniswap', 'compound', 'aave'] },
      { from: 'automated_market_maker', to: ['uniswap', 'impermanent_loss'] },
      { from: 'governance_tokens', to: ['uniswap', 'compound', 'aave'] },
      { from: 'ethereum', to: ['uniswap', 'compound', 'aave', 'smart_contract_risk'] }
    ];

    relationships.forEach(rel => {
      const node = this.nodes.get(rel.from);
      if (node) {
        node.relationships = rel.to;
        this.relationships.set(rel.from, rel.to);
      }
    });
  }

  // Public methods for querying and reasoning

  findCounterEvidence(claim: string): CounterEvidence[] {
    const counterEvidences: CounterEvidence[] = [];
    
    // Analyze the claim and find relevant nodes
    const relevantNodes = this.findRelevantNodes(claim);
    
    for (const nodeId of relevantNodes) {
      const node = this.nodes.get(nodeId);
      if (node) {
        const counter = this.generateCounterArgument(claim, node);
        if (counter) {
          counterEvidences.push(counter);
        }
      }
    }
    
    return counterEvidences.sort((a, b) => b.strength - a.strength);
  }

  private findRelevantNodes(claim: string): string[] {
    const relevant: string[] = [];
    const lowerClaim = claim.toLowerCase();
    
    for (const [nodeId, node] of this.nodes) {
      // Check if claim mentions this node or related concepts
      if (lowerClaim.includes(node.name.toLowerCase()) ||
          lowerClaim.includes(nodeId) ||
          this.checkSemanticRelevance(claim, node)) {
        relevant.push(nodeId);
      }
    }
    
    return relevant;
  }

  private checkSemanticRelevance(claim: string, node: DeFiKnowledgeNode): boolean {
    const claimWords = claim.toLowerCase().split(/\s+/);
    const nodeWords = [
      ...node.name.toLowerCase().split(/\s+/),
      ...node.description.toLowerCase().split(/\s+/),
      ...Object.keys(node.properties).map(k => k.toLowerCase()),
      ...Object.values(node.properties).flat().map(v => 
        typeof v === 'string' ? v.toLowerCase() : ''
      ).filter(Boolean)
    ];
    
    const intersection = claimWords.filter(word => 
      nodeWords.some(nodeWord => 
        nodeWord.includes(word) || word.includes(nodeWord)
      )
    );
    
    return intersection.length > 0;
  }

  private generateCounterArgument(claim: string, node: DeFiKnowledgeNode): CounterEvidence | null {
    const supportingEvidence = Array.from(this.evidenceDatabase.values())
      .filter(evidence => evidence.supportingNodes.includes(node.id));
    
    if (supportingEvidence.length === 0) return null;
    
    // Generate counter-claim based on node properties and evidence
    const counterClaim = this.constructCounterClaim(claim, node);
    const reasoning = this.constructReasoning(claim, node, supportingEvidence);
    const strength = this.calculateCounterStrength(supportingEvidence);
    
    return {
      originalClaim: claim,
      counterClaim,
      evidence: supportingEvidence,
      strength,
      reasoning
    };
  }

  private constructCounterClaim(claim: string, node: DeFiKnowledgeNode): string {
    // This would use more sophisticated NLP in production
    const risks = Array.isArray(node.properties.risks) ? node.properties.risks : [];
    const disadvantages = Array.isArray(node.properties.disadvantages) ? node.properties.disadvantages : [];
    
    if (risks.length > 0 || disadvantages.length > 0) {
      return `However, ${node.name} has significant considerations including: ${[...risks, ...disadvantages].join(', ')}`;
    }
    
    return `While ${claim} may have merit, there are important considerations regarding ${node.name}`;
  }

  private constructReasoning(claim: string, node: DeFiKnowledgeNode, evidence: EvidenceItem[]): string {
    const evidenceSummary = evidence.map(e => `${e.claim} (${e.source})`).join('; ');
    return `Based on analysis of ${node.name} and supporting evidence: ${evidenceSummary}`;
  }

  private calculateCounterStrength(evidence: EvidenceItem[]): number {
    if (evidence.length === 0) return 0;
    
    const avgCredibility = evidence.reduce((sum, e) => sum + e.credibility, 0) / evidence.length;
    const evidenceBonus = Math.min(0.3, evidence.length * 0.1);
    
    return Math.min(1.0, avgCredibility + evidenceBonus);
  }

  // Method to get comprehensive analysis of a DeFi topic
  analyzeTopicComprehensively(topic: string): {
    relevantNodes: DeFiKnowledgeNode[];
    evidence: EvidenceItem[];
    risks: DeFiKnowledgeNode[];
    benefits: any[];
    relationships: string[];
  } {
    const relevantNodeIds = this.findRelevantNodes(topic);
    const relevantNodes = relevantNodeIds.map(id => this.nodes.get(id)!).filter(Boolean);
    
    const evidence = Array.from(this.evidenceDatabase.values())
      .filter(e => e.supportingNodes.some(nodeId => relevantNodeIds.includes(nodeId)));
    
    const risks = relevantNodes.filter(node => node.type === 'risk');
    
    const benefits = relevantNodes.map(node => node.properties.benefits).flat().filter(Boolean);
    
    const relationships = relevantNodes.map(node => node.relationships).flat();
    
    return {
      relevantNodes,
      evidence,
      risks,
      benefits,
      relationships
    };
  }

  // Method to update knowledge base with new information
  updateKnowledge(nodeId: string, newProperties: Partial<DeFiKnowledgeNode>): void {
    const node = this.nodes.get(nodeId);
    if (node) {
      Object.assign(node, newProperties);
      node.lastUpdated = new Date();
    }
  }

  // Method to add new evidence
  addEvidence(evidence: Omit<EvidenceItem, 'id' | 'dateAdded'>): void {
    const id = `evidence_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    this.evidenceDatabase.set(id, {
      id,
      ...evidence,
      dateAdded: new Date()
    });
  }
}