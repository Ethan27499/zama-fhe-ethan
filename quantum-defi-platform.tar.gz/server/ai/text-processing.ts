// Advanced Text Processing and Pattern Recognition
import * as natural from 'natural';
import * as _ from 'lodash';

interface TextStatistics {
  wordCount: number;
  sentenceCount: number;
  paragraphCount: number;
  averageWordsPerSentence: number;
  averageSentencesPerParagraph: number;
  lexicalDiversity: number;
  readabilityScore: number;
}

interface PatternMatch {
  pattern: string;
  matches: Array<{
    text: string;
    position: [number, number];
    confidence: number;
    context: string;
  }>;
}

interface SemanticSimilarity {
  score: number;
  method: 'jaccard' | 'cosine' | 'jaro_winkler' | 'levenshtein';
  details: any;
}

export class TextProcessor {
  private stemmer: any;
  private tokenizer: any;
  private metaphone: any;

  constructor() {
    this.stemmer = natural.PorterStemmer;
    this.tokenizer = new natural.WordTokenizer();
    this.metaphone = natural.Metaphone;
  }

  // Text normalization and preprocessing
  normalizeText(text: string): string {
    // Remove extra whitespace
    let normalized = text.replace(/\s+/g, ' ').trim();
    
    // Normalize Vietnamese characters
    normalized = this.normalizeVietnamese(normalized);
    
    // Handle crypto symbols and abbreviations
    normalized = this.normalizeCryptoTerms(normalized);
    
    return normalized;
  }

  private normalizeVietnamese(text: string): string {
    // Normalize Vietnamese diacritics variations
    const vietnameseNormalization: Record<string, string> = {
      'à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ': 'a',
      'è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ': 'e',
      'ì|í|ị|ỉ|ĩ': 'i',
      'ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ': 'o',
      'ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ': 'u',
      'ỳ|ý|ỵ|ỷ|ỹ': 'y',
      'đ': 'd'
    };

    let normalized = text;
    for (const [pattern, replacement] of Object.entries(vietnameseNormalization)) {
      const regex = new RegExp(`[${pattern}]`, 'gi');
      normalized = normalized.replace(regex, replacement);
    }

    return normalized;
  }

  private normalizeCryptoTerms(text: string): string {
    const cryptoNormalizations: Record<string, string> = {
      'bitcoin|btc': 'bitcoin',
      'ethereum|eth': 'ethereum',
      'defi|decentralized finance|tài chính phi tập trung': 'defi',
      'yield farming|canh tác lợi nhuận': 'yield_farming',
      'smart contract|hợp đồng thông minh': 'smart_contract',
      'impermanent loss|tổn thất tạm thời': 'impermanent_loss'
    };

    let normalized = text;
    for (const [pattern, replacement] of Object.entries(cryptoNormalizations)) {
      const regex = new RegExp(`\\b(${pattern})\\b`, 'gi');
      normalized = normalized.replace(regex, replacement);
    }

    return normalized;
  }

  // Advanced tokenization with context preservation
  advancedTokenize(text: string): Array<{
    token: string;
    position: [number, number];
    type: 'word' | 'punctuation' | 'number' | 'crypto' | 'vietnamese';
    stem: string;
    metaphone: string;
  }> {
    const tokens: Array<{
      token: string;
      position: [number, number];
      type: 'word' | 'punctuation' | 'number' | 'crypto' | 'vietnamese';
      stem: string;
      metaphone: string;
    }> = [];

    // Enhanced tokenization with position tracking
    const regex = /\S+/g;
    let match;
    
    while ((match = regex.exec(text)) !== null) {
      const token = match[0];
      const position: [number, number] = [match.index, match.index + token.length];
      
      tokens.push({
        token,
        position,
        type: this.classifyToken(token),
        stem: this.stemmer.stem(token),
        metaphone: this.metaphone.process(token)
      });
    }

    return tokens;
  }

  private classifyToken(token: string): 'word' | 'punctuation' | 'number' | 'crypto' | 'vietnamese' {
    if (/^[^\w]$/.test(token)) return 'punctuation';
    if (/^\d+$/.test(token)) return 'number';
    if (/[àáãạảăắằẳẵặâấầẩẫậèéẹẻẽêềếểễệđìíĩỉịòóõọỏôốồổỗộơớờởỡợùúũụủưứừửữựỳýỵỷỹ]/.test(token)) return 'vietnamese';
    
    const cryptoTerms = ['bitcoin', 'ethereum', 'defi', 'blockchain', 'crypto', 'btc', 'eth'];
    if (cryptoTerms.some(term => token.toLowerCase().includes(term))) return 'crypto';
    
    return 'word';
  }

  // Calculate comprehensive text statistics
  calculateStatistics(text: string): TextStatistics {
    const words = this.tokenizer.tokenize(text) || [];
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0);

    const uniqueWords = new Set(words.map(w => w.toLowerCase()));
    const lexicalDiversity = uniqueWords.size / words.length;

    return {
      wordCount: words.length,
      sentenceCount: sentences.length,
      paragraphCount: paragraphs.length,
      averageWordsPerSentence: words.length / sentences.length,
      averageSentencesPerParagraph: sentences.length / paragraphs.length,
      lexicalDiversity,
      readabilityScore: this.calculateReadabilityScore(words, sentences)
    };
  }

  private calculateReadabilityScore(words: string[], sentences: string[]): number {
    const totalSyllables = words.reduce((sum, word) => sum + this.countSyllables(word), 0);
    const avgWordsPerSentence = words.length / sentences.length;
    const avgSyllablesPerWord = totalSyllables / words.length;

    // Flesch Reading Ease formula
    const score = 206.835 - (1.015 * avgWordsPerSentence) - (84.6 * avgSyllablesPerWord);
    return Math.max(0, Math.min(100, score));
  }

  private countSyllables(word: string): number {
    const vowels = 'aeiouy';
    let syllables = 0;
    let prevWasVowel = false;

    for (let i = 0; i < word.length; i++) {
      const isVowel = vowels.includes(word[i].toLowerCase());
      if (isVowel && !prevWasVowel) {
        syllables++;
      }
      prevWasVowel = isVowel;
    }

    // Adjust for silent 'e'
    if (word.endsWith('e') && syllables > 1) {
      syllables--;
    }

    return Math.max(1, syllables);
  }

  // Advanced pattern matching with context
  findPatterns(text: string, patterns: Array<{name: string; regex: RegExp}>): PatternMatch[] {
    const results: PatternMatch[] = [];

    for (const pattern of patterns) {
      const matches: Array<{
        text: string;
        position: [number, number];
        confidence: number;
        context: string;
      }> = [];

      const regex = new RegExp(pattern.regex.source, 'gi');
      let match;

      while ((match = regex.exec(text)) !== null) {
        const matchText = match[0];
        const position: [number, number] = [match.index, match.index + matchText.length];
        const context = this.extractContext(text, match.index, matchText.length);
        const confidence = this.calculatePatternConfidence(matchText, context);

        matches.push({
          text: matchText,
          position,
          confidence,
          context
        });
      }

      if (matches.length > 0) {
        results.push({
          pattern: pattern.name,
          matches
        });
      }
    }

    return results;
  }

  private extractContext(text: string, position: number, length: number): string {
    const contextRadius = 50;
    const start = Math.max(0, position - contextRadius);
    const end = Math.min(text.length, position + length + contextRadius);
    return text.slice(start, end);
  }

  private calculatePatternConfidence(match: string, context: string): number {
    let confidence = 0.5; // Base confidence

    // Boost for longer matches
    if (match.length > 10) confidence += 0.2;
    
    // Boost for context relevance
    const relevantKeywords = ['defi', 'crypto', 'blockchain', 'protocol', 'token'];
    const contextLower = context.toLowerCase();
    const relevantCount = relevantKeywords.filter(keyword => contextLower.includes(keyword)).length;
    confidence += relevantCount * 0.1;

    // Boost for proper capitalization
    if (/^[A-Z]/.test(match)) confidence += 0.1;

    return Math.min(1.0, confidence);
  }

  // Semantic similarity between texts
  calculateSimilarity(text1: string, text2: string): SemanticSimilarity[] {
    const results: SemanticSimilarity[] = [];

    // Jaccard similarity
    const jaccardScore = this.jaccardSimilarity(text1, text2);
    results.push({
      score: jaccardScore.score,
      method: 'jaccard',
      details: jaccardScore
    });

    // Cosine similarity
    const cosineScore = this.cosineSimilarity(text1, text2);
    results.push({
      score: cosineScore.score,
      method: 'cosine',
      details: cosineScore
    });

    // Jaro-Winkler similarity
    const jaroScore = natural.JaroWinklerDistance(text1, text2);
    results.push({
      score: jaroScore,
      method: 'jaro_winkler',
      details: { distance: jaroScore }
    });

    // Levenshtein similarity
    const levenshteinDistance = natural.LevenshteinDistance(text1, text2);
    const maxLength = Math.max(text1.length, text2.length);
    const levenshteinScore = 1 - (levenshteinDistance / maxLength);
    results.push({
      score: levenshteinScore,
      method: 'levenshtein',
      details: { distance: levenshteinDistance, maxLength }
    });

    return results;
  }

  private jaccardSimilarity(text1: string, text2: string): {score: number; union: number; intersection: number} {
    const tokens1 = new Set(this.tokenizer.tokenize(text1.toLowerCase()) || []);
    const tokens2 = new Set(this.tokenizer.tokenize(text2.toLowerCase()) || []);

    const intersection = new Set([...tokens1].filter(token => tokens2.has(token)));
    const union = new Set([...tokens1, ...tokens2]);

    const score = union.size === 0 ? 0 : intersection.size / union.size;

    return {
      score,
      union: union.size,
      intersection: intersection.size
    };
  }

  private cosineSimilarity(text1: string, text2: string): {score: number; vector1: number[]; vector2: number[]} {
    const tokens1 = this.tokenizer.tokenize(text1.toLowerCase()) || [];
    const tokens2 = this.tokenizer.tokenize(text2.toLowerCase()) || [];

    // Create vocabulary
    const vocabulary = new Set([...tokens1, ...tokens2]);
    const vocabArray = Array.from(vocabulary);

    // Create vectors
    const vector1 = vocabArray.map(token => tokens1.filter(t => t === token).length);
    const vector2 = vocabArray.map(token => tokens2.filter(t => t === token).length);

    // Calculate cosine similarity
    const dotProduct = vector1.reduce((sum, val, i) => sum + val * vector2[i], 0);
    const magnitude1 = Math.sqrt(vector1.reduce((sum, val) => sum + val * val, 0));
    const magnitude2 = Math.sqrt(vector2.reduce((sum, val) => sum + val * val, 0));

    const score = magnitude1 === 0 || magnitude2 === 0 ? 0 : dotProduct / (magnitude1 * magnitude2);

    return {
      score,
      vector1,
      vector2
    };
  }

  // Extract key phrases using statistical methods
  extractKeyPhrases(text: string, maxPhrases: number = 10): Array<{
    phrase: string;
    score: number;
    frequency: number;
    positions: number[];
  }> {
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const phrases: Map<string, {frequency: number; positions: number[]}> = new Map();

    // Extract n-grams (2-4 words)
    for (let n = 2; n <= 4; n++) {
      for (const sentence of sentences) {
        const words = this.tokenizer.tokenize(sentence.toLowerCase()) || [];
        
        for (let i = 0; i <= words.length - n; i++) {
          const phrase = words.slice(i, i + n).join(' ');
          
          // Skip phrases with stop words only
          if (this.isSignificantPhrase(phrase)) {
            const position = text.toLowerCase().indexOf(phrase);
            
            if (!phrases.has(phrase)) {
              phrases.set(phrase, { frequency: 0, positions: [] });
            }
            
            const phraseData = phrases.get(phrase)!;
            phraseData.frequency++;
            if (position !== -1) {
              phraseData.positions.push(position);
            }
          }
        }
      }
    }

    // Calculate scores and sort
    const scored = Array.from(phrases.entries()).map(([phrase, data]) => ({
      phrase,
      score: this.calculatePhraseScore(phrase, data, text),
      frequency: data.frequency,
      positions: data.positions
    }));

    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, maxPhrases);
  }

  private isSignificantPhrase(phrase: string): boolean {
    const stopWords = new Set([
      'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
      'là', 'một', 'và', 'hoặc', 'nhưng', 'trong', 'trên', 'tại', 'để', 'của', 'với', 'bởi'
    ]);

    const words = phrase.split(' ');
    const significantWords = words.filter(word => !stopWords.has(word) && word.length > 2);
    
    return significantWords.length >= words.length * 0.6;
  }

  private calculatePhraseScore(phrase: string, data: {frequency: number; positions: number[]}, text: string): number {
    const words = phrase.split(' ');
    let score = 0;

    // Frequency score
    score += Math.log(data.frequency + 1) * 0.3;

    // Length bonus (favor longer phrases)
    score += words.length * 0.2;

    // Position bonus (favor phrases appearing early)
    if (data.positions.length > 0) {
      const avgPosition = data.positions.reduce((sum, pos) => sum + pos, 0) / data.positions.length;
      const positionScore = 1 - (avgPosition / text.length);
      score += positionScore * 0.2;
    }

    // Crypto relevance bonus
    const cryptoTerms = ['defi', 'blockchain', 'crypto', 'token', 'protocol', 'yield', 'farming'];
    const cryptoRelevance = words.filter(word => cryptoTerms.includes(word.toLowerCase())).length;
    score += cryptoRelevance * 0.3;

    return score;
  }
}

// Export singleton instance
export const textProcessor = new TextProcessor();