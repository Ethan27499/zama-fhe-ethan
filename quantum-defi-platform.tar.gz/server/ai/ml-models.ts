// Machine Learning Models for Fallacy Detection and NLP
import * as tf from '@tensorflow/tfjs-node';
import { Matrix } from 'ml-matrix';
import { LogisticRegression } from 'ml-regression';
import * as natural from 'natural';

interface FallacyClassificationModel {
  model: tf.LayersModel;
  tokenizer: natural.WordTokenizer;
  vectorizer: TfidfVectorizer;
  classes: string[];
  accuracy: number;
}

interface ArgumentStructureModel {
  premiseClassifier: tf.LayersModel;
  conclusionDetector: tf.LayersModel;
  evidenceExtractor: tf.LayersModel;
  logicalConnectorModel: tf.LayersModel;
}

class TfidfVectorizer {
  private vocabulary: Map<string, number> = new Map();
  private idf: Map<string, number> = new Map();
  private maxFeatures: number;
  private tokenizer: natural.WordTokenizer;

  constructor(maxFeatures: number = 5000) {
    this.maxFeatures = maxFeatures;
    this.tokenizer = new natural.WordTokenizer();
  }

  fit(documents: string[]): void {
    // Build vocabulary
    const termFrequency = new Map<string, number>();
    const documentFrequency = new Map<string, number>();
    
    documents.forEach(doc => {
      const tokens = this.tokenizer.tokenize(doc.toLowerCase()) || [];
      const uniqueTokens = new Set(tokens);
      
      tokens.forEach(token => {
        termFrequency.set(token, (termFrequency.get(token) || 0) + 1);
      });
      
      uniqueTokens.forEach(token => {
        documentFrequency.set(token, (documentFrequency.get(token) || 0) + 1);
      });
    });

    // Select top features by frequency
    const sortedTerms = Array.from(termFrequency.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, this.maxFeatures);

    sortedTerms.forEach((term, index) => {
      this.vocabulary.set(term[0], index);
    });

    // Calculate IDF
    const totalDocs = documents.length;
    for (const [term, df] of documentFrequency.entries()) {
      if (this.vocabulary.has(term)) {
        this.idf.set(term, Math.log(totalDocs / df));
      }
    }
  }

  transform(documents: string[]): number[][] {
    return documents.map(doc => this.transformSingle(doc));
  }

  private transformSingle(document: string): number[] {
    const tokens = this.tokenizer.tokenize(document.toLowerCase()) || [];
    const termCount = new Map<string, number>();
    
    tokens.forEach(token => {
      if (this.vocabulary.has(token)) {
        termCount.set(token, (termCount.get(token) || 0) + 1);
      }
    });

    const vector = new Array(this.vocabulary.size).fill(0);
    
    for (const [term, count] of termCount.entries()) {
      const index = this.vocabulary.get(term);
      const idf = this.idf.get(term) || 0;
      if (index !== undefined) {
        vector[index] = count * idf;
      }
    }

    // Normalize vector
    const norm = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
    return norm > 0 ? vector.map(val => val / norm) : vector;
  }
}

export class MLFallacyDetector {
  private models: Map<string, FallacyClassificationModel> = new Map();
  private argumentStructureModel?: ArgumentStructureModel;
  private isInitialized: boolean = false;

  constructor() {
    this.initializeModels();
  }

  private async initializeModels(): Promise<void> {
    try {
      // Initialize fallacy classification models
      await this.initializeFallacyModels();
      
      // Initialize argument structure models
      await this.initializeArgumentModels();
      
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize ML models:', error);
    }
  }

  private async initializeFallacyModels(): Promise<void> {
    const fallacyTypes = [
      'appeal_to_authority',
      'false_dichotomy', 
      'cherry_picking',
      'post_hoc',
      'bandwagon',
      'strawman',
      'slippery_slope',
      'ad_hominem'
    ];

    for (const fallacyType of fallacyTypes) {
      const model = await this.createFallacyModel(fallacyType);
      this.models.set(fallacyType, model);
    }
  }

  private async createFallacyModel(fallacyType: string): Promise<FallacyClassificationModel> {
    // Create a simple neural network for fallacy detection
    const model = tf.sequential({
      layers: [
        tf.layers.dense({
          inputShape: [5000], // TF-IDF features
          units: 128,
          activation: 'relu'
        }),
        tf.layers.dropout({ rate: 0.3 }),
        tf.layers.dense({
          units: 64,
          activation: 'relu'
        }),
        tf.layers.dropout({ rate: 0.3 }),
        tf.layers.dense({
          units: 1,
          activation: 'sigmoid'
        })
      ]
    });

    model.compile({
      optimizer: 'adam',
      loss: 'binaryCrossentropy',
      metrics: ['accuracy']
    });

    const tokenizer = new natural.WordTokenizer();
    const vectorizer = new TfidfVectorizer(5000);
    
    // Train with synthetic data for now (in production, use real labeled data)
    const trainingData = this.generateSyntheticTrainingData(fallacyType);
    vectorizer.fit(trainingData.texts);
    
    const X = tf.tensor2d(vectorizer.transform(trainingData.texts));
    const y = tf.tensor2d(trainingData.labels.map(l => [l]));
    
    await model.fit(X, y, {
      epochs: 10,
      batchSize: 32,
      validationSplit: 0.2,
      verbose: 0
    });

    X.dispose();
    y.dispose();

    return {
      model,
      tokenizer,
      vectorizer,
      classes: ['not_' + fallacyType, fallacyType],
      accuracy: 0.85 // Placeholder
    };
  }

  private generateSyntheticTrainingData(fallacyType: string): {texts: string[], labels: number[]} {
    // Generate synthetic training data based on fallacy patterns
    const positiveExamples = this.getFallacyExamples(fallacyType);
    const negativeExamples = this.getNonFallacyExamples();
    
    const texts = [...positiveExamples, ...negativeExamples];
    const labels = [
      ...new Array(positiveExamples.length).fill(1),
      ...new Array(negativeExamples.length).fill(0)
    ];
    
    return { texts, labels };
  }

  private getFallacyExamples(fallacyType: string): string[] {
    const examples: Record<string, string[]> = {
      'appeal_to_authority': [
        'Vitalik said Ethereum will reach $10k so it must be true',
        'The top crypto influencer recommends this token',
        'Trust me, I am a crypto expert with 10 years experience',
        'According to the Bitcoin maximalist guru, altcoins are scams'
      ],
      'false_dichotomy': [
        'Either you buy Bitcoin now or you will stay poor forever',
        'You must choose between DeFi or traditional finance',
        'There are only two options: HODL or lose everything',
        'If you dont invest in crypto, you will miss the revolution'
      ],
      'cherry_picking': [
        'Look at this 1000% gain, DeFi is always profitable',
        'This protocol never had any hacks, completely safe',
        'I only show you the successful trades, not the losses',
        'Focus on the best case scenario, ignore the risks'
      ],
      'post_hoc': [
        'Bitcoin went up after the Fed meeting, so Fed policy causes Bitcoin rallies',
        'DeFi exploded after COVID, so pandemic caused DeFi growth',
        'Every time whale moves coins, price drops, so whales control market',
        'Token pumped after the tweet, so social media drives prices'
      ],
      'bandwagon': [
        'Everyone is buying this token, you should too',
        'All smart money is moving to DeFi protocols',
        'Most successful traders use this strategy',
        'The whole community believes in this project'
      ],
      'strawman': [
        'Bitcoin critics say its only for criminals but they just dont understand',
        'People who dont like DeFi think its all scams and ponzis',
        'Traditional finance believers think crypto is just gambling',
        'Skeptics claim all protocols will be hacked eventually'
      ],
      'slippery_slope': [
        'If governments regulate stablecoins, then all crypto will be banned',
        'One smart contract bug will destroy the entire DeFi ecosystem',
        'If Bitcoin fails, then all digital assets become worthless',
        'Regulation starts with exchanges, ends with complete crypto prohibition'
      ],
      'ad_hominem': [
        'You are just a noob, you dont understand advanced DeFi',
        'Only idiots believe that FUD about our protocol',
        'Coming from someone who missed the Bitcoin rally',
        'Typical boomer mentality, afraid of innovation'
      ]
    };

    return examples[fallacyType] || [];
  }

  private getNonFallacyExamples(): string[] {
    return [
      'DeFi protocols offer various yield farming opportunities with different risk profiles',
      'Smart contract audits help identify potential vulnerabilities before deployment',
      'Market volatility affects both traditional and crypto assets differently',
      'Diversification across protocols can help manage concentration risk',
      'Historical performance does not guarantee future returns in any investment',
      'Each DeFi protocol has unique mechanisms and risk characteristics',
      'Regulatory frameworks are evolving to address crypto innovation',
      'Technical analysis provides one perspective among many market analysis tools'
    ];
  }

  private async initializeArgumentModels(): Promise<void> {
    // Initialize models for argument structure analysis
    this.argumentStructureModel = {
      premiseClassifier: await this.createPremiseClassifier(),
      conclusionDetector: await this.createConclusionDetector(),
      evidenceExtractor: await this.createEvidenceExtractor(),
      logicalConnectorModel: await this.createLogicalConnectorModel()
    };
  }

  private async createPremiseClassifier(): Promise<tf.LayersModel> {
    const model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [100], units: 64, activation: 'relu' }),
        tf.layers.dropout({ rate: 0.2 }),
        tf.layers.dense({ units: 32, activation: 'relu' }),
        tf.layers.dense({ units: 1, activation: 'sigmoid' })
      ]
    });

    model.compile({
      optimizer: 'adam',
      loss: 'binaryCrossentropy',
      metrics: ['accuracy']
    });

    return model;
  }

  private async createConclusionDetector(): Promise<tf.LayersModel> {
    const model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [100], units: 64, activation: 'relu' }),
        tf.layers.dropout({ rate: 0.2 }),
        tf.layers.dense({ units: 32, activation: 'relu' }),
        tf.layers.dense({ units: 1, activation: 'sigmoid' })
      ]
    });

    model.compile({
      optimizer: 'adam',
      loss: 'binaryCrossentropy',
      metrics: ['accuracy']
    });

    return model;
  }

  private async createEvidenceExtractor(): Promise<tf.LayersModel> {
    const model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [100], units: 64, activation: 'relu' }),
        tf.layers.dropout({ rate: 0.2 }),
        tf.layers.dense({ units: 32, activation: 'relu' }),
        tf.layers.dense({ units: 4, activation: 'softmax' }) // 4 evidence types
      ]
    });

    model.compile({
      optimizer: 'adam',
      loss: 'categoricalCrossentropy',
      metrics: ['accuracy']
    });

    return model;
  }

  private async createLogicalConnectorModel(): Promise<tf.LayersModel> {
    const model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [50], units: 32, activation: 'relu' }),
        tf.layers.dense({ units: 16, activation: 'relu' }),
        tf.layers.dense({ units: 8, activation: 'softmax' }) // Different connector types
      ]
    });

    model.compile({
      optimizer: 'adam',
      loss: 'categoricalCrossentropy',
      metrics: ['accuracy']
    });

    return model;
  }

  async classifyFallacy(text: string): Promise<{
    fallacyType: string;
    confidence: number;
    reasoning: string;
  }[]> {
    if (!this.isInitialized) {
      await this.initializeModels();
    }

    const results: {fallacyType: string; confidence: number; reasoning: string}[] = [];

    for (const [fallacyType, model] of this.models) {
      try {
        const features = model.vectorizer.transform([text]);
        const prediction = model.model.predict(tf.tensor2d(features)) as tf.Tensor;
        const confidence = await prediction.data();
        
        if (confidence[0] > 0.5) {
          results.push({
            fallacyType,
            confidence: confidence[0],
            reasoning: `ML model detected patterns consistent with ${fallacyType}`
          });
        }

        prediction.dispose();
      } catch (error) {
        console.error(`Error classifying ${fallacyType}:`, error);
      }
    }

    return results.sort((a, b) => b.confidence - a.confidence);
  }

  async analyzeArgumentStructure(text: string): Promise<{
    premises: string[];
    conclusion: string;
    evidenceTypes: string[];
    logicalConnectors: string[];
    structuralStrength: number;
  }> {
    if (!this.argumentStructureModel) {
      await this.initializeArgumentModels();
    }

    // Simple sentence-based analysis for now
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    // Last sentence is often the conclusion
    const conclusion = sentences[sentences.length - 1] || '';
    const premises = sentences.slice(0, -1);
    
    // Extract evidence types using pattern matching
    const evidenceTypes = this.extractEvidenceTypes(text);
    
    // Extract logical connectors
    const logicalConnectors = this.extractLogicalConnectors(text);
    
    // Calculate structural strength
    const structuralStrength = this.calculateStructuralStrength(premises, conclusion, evidenceTypes, logicalConnectors);

    return {
      premises,
      conclusion,
      evidenceTypes,
      logicalConnectors,
      structuralStrength
    };
  }

  private extractEvidenceTypes(text: string): string[] {
    const evidencePatterns = [
      { type: 'statistical', patterns: [/\d+%/, /statistics show/, /data indicates/, /studies reveal/] },
      { type: 'expert_opinion', patterns: [/expert says/, /research suggests/, /according to/] },
      { type: 'historical', patterns: [/historically/, /in the past/, /previous/] },
      { type: 'logical', patterns: [/therefore/, /thus/, /consequently/] }
    ];

    const found: string[] = [];
    const lowerText = text.toLowerCase();

    for (const evidence of evidencePatterns) {
      for (const pattern of evidence.patterns) {
        if (pattern.test(lowerText)) {
          found.push(evidence.type);
          break;
        }
      }
    }

    return [...new Set(found)];
  }

  private extractLogicalConnectors(text: string): string[] {
    const connectors = [
      'therefore', 'thus', 'consequently', 'because', 'since', 'however', 
      'but', 'although', 'moreover', 'furthermore', 'in addition'
    ];

    const found: string[] = [];
    const lowerText = text.toLowerCase();

    for (const connector of connectors) {
      if (lowerText.includes(connector)) {
        found.push(connector);
      }
    }

    return found;
  }

  private calculateStructuralStrength(
    premises: string[], 
    conclusion: string, 
    evidenceTypes: string[], 
    logicalConnectors: string[]
  ): number {
    let strength = 0;

    // Base score for having premises and conclusion
    if (premises.length > 0 && conclusion.length > 0) {
      strength += 0.3;
    }

    // Bonus for multiple premises
    strength += Math.min(0.3, premises.length * 0.1);

    // Bonus for evidence
    strength += Math.min(0.2, evidenceTypes.length * 0.05);

    // Bonus for logical connectors
    strength += Math.min(0.2, logicalConnectors.length * 0.05);

    return Math.min(1.0, strength);
  }

  // Clean up resources
  dispose(): void {
    for (const [, model] of this.models) {
      model.model.dispose();
    }

    if (this.argumentStructureModel) {
      this.argumentStructureModel.premiseClassifier.dispose();
      this.argumentStructureModel.conclusionDetector.dispose();
      this.argumentStructureModel.evidenceExtractor.dispose();
      this.argumentStructureModel.logicalConnectorModel.dispose();
    }
  }
}