import { LogoFetcher } from './logo-fetcher';

async function main() {
  console.log('🚀 Starting Logo Fetcher...');
  
  const fetcher = new LogoFetcher();
  const result = await fetcher.fetchAllLogos();
  
  console.log('\n✅ Logo fetching completed!');
  console.log(`📊 Summary: ${result.total} logos updated`);
  
  process.exit(0);
}

main().catch(error => {
  console.error('❌ Logo fetcher failed:', error);
  process.exit(1);
});