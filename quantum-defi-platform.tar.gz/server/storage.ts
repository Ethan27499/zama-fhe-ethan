import { users, pools, protocols, blockchains, tokens, type User, type InsertUser, type Pool, type Protocol, type Blockchain } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, ilike, sql } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  
  // DeFi data methods
  getAllPools(filters?: PoolFilters): Promise<Pool[]>;
  getPoolsByProtocol(protocolId: number): Promise<Pool[]>;
  getPoolsByChain(blockchainId: number): Promise<Pool[]>;
  getAllProtocols(): Promise<Protocol[]>;
  getAllBlockchains(): Promise<Blockchain[]>;
  searchPools(query: string): Promise<Pool[]>;
}

export interface PoolFilters {
  chain?: string;
  category?: string;
  risk?: string;
  sortBy?: 'apy' | 'tvl' | 'volume';
  search?: string;
  limit?: number;
  offset?: number;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllPools(filters?: PoolFilters): Promise<any[]> {
    let baseQuery = db
      .select({
        id: pools.id,
        protocolId: pools.protocolId,
        blockchainId: pools.blockchainId,
        poolAddress: pools.poolAddress,
        name: pools.name,
        tokens: pools.tokens,
        apy: pools.apy,
        apr: pools.apr,
        tvl: pools.tvl,
        volume24h: pools.volume24h,
        fees24h: pools.fees24h,
        poolType: pools.poolType,
        riskScore: pools.riskScore,
        isActive: pools.isActive,
        metadata: pools.metadata,
        createdAt: pools.createdAt,
        updatedAt: pools.updatedAt,
        protocolName: protocols.name,
        protocolCategory: protocols.category,
        protocolLogo: protocols.logo,
        blockchainName: blockchains.name,
        blockchainSymbol: blockchains.symbol,
      })
      .from(pools)
      .leftJoin(protocols, eq(pools.protocolId, protocols.id))
      .leftJoin(blockchains, eq(pools.blockchainId, blockchains.id))
      .where(eq(pools.isActive, true));

    if (filters) {
      const conditions = [eq(pools.isActive, true)];

      if (filters.chain && filters.chain !== 'All') {
        conditions.push(eq(blockchains.name, filters.chain));
      }

      if (filters.category && filters.category !== 'All') {
        conditions.push(eq(protocols.category, filters.category));
      }

      if (filters.risk && filters.risk !== 'All') {
        const riskMapping = { 'Low': [1, 3], 'Medium': [4, 6], 'High': [7, 10] };
        const range = riskMapping[filters.risk as keyof typeof riskMapping];
        if (range) {
          conditions.push(and(
            sql`${pools.riskScore} >= ${range[0]}`,
            sql`${pools.riskScore} <= ${range[1]}`
          ));
        }
      }

      if (filters.search) {
        conditions.push(
          or(
            ilike(protocols.name, `%${filters.search}%`),
            ilike(pools.name, `%${filters.search}%`),
            ilike(blockchains.name, `%${filters.search}%`)
          )
        );
      }

      baseQuery = baseQuery.where(and(...conditions));

      // Sorting
      if (filters.sortBy === 'apy') {
        baseQuery = baseQuery.orderBy(desc(pools.apy));
      } else if (filters.sortBy === 'volume') {
        baseQuery = baseQuery.orderBy(desc(pools.volume24h));
      } else {
        baseQuery = baseQuery.orderBy(desc(pools.tvl)); // Default sort by TVL
      }

      // Pagination
      if (filters.limit) {
        baseQuery = baseQuery.limit(filters.limit);
      }
      if (filters.offset) {
        baseQuery = baseQuery.offset(filters.offset);
      }
    } else {
      baseQuery = baseQuery.orderBy(desc(pools.tvl)).limit(100);
    }

    const result = await baseQuery;
    
    // Transform the joined result
    return result.map(row => ({
      ...row,
      protocol: {
        name: row.protocolName,
        category: row.protocolCategory,
        logo: row.protocolLogo,
      },
      blockchain: {
        name: row.blockchainName,
        symbol: row.blockchainSymbol,
      },
    }));
  }

  async getPoolsByProtocol(protocolId: number): Promise<Pool[]> {
    return await db
      .select()
      .from(pools)
      .where(and(eq(pools.protocolId, protocolId), eq(pools.isActive, true)))
      .orderBy(desc(pools.tvl));
  }

  async getPoolsByChain(blockchainId: number): Promise<Pool[]> {
    return await db
      .select()
      .from(pools)
      .where(and(eq(pools.blockchainId, blockchainId), eq(pools.isActive, true)))
      .orderBy(desc(pools.tvl));
  }

  async getAllProtocols(): Promise<Protocol[]> {
    return await db
      .select()
      .from(protocols)
      .orderBy(desc(protocols.tvl));
  }

  async getAllBlockchains(): Promise<Blockchain[]> {
    return await db
      .select()
      .from(blockchains)
      .where(eq(blockchains.isActive, true))
      .orderBy(desc(blockchains.tvl));
  }

  async searchPools(query: string): Promise<any[]> {
    const result = await db
      .select({
        id: pools.id,
        protocolId: pools.protocolId,
        blockchainId: pools.blockchainId,
        poolAddress: pools.poolAddress,
        name: pools.name,
        tokens: pools.tokens,
        apy: pools.apy,
        apr: pools.apr,
        tvl: pools.tvl,
        volume24h: pools.volume24h,
        fees24h: pools.fees24h,
        poolType: pools.poolType,
        riskScore: pools.riskScore,
        isActive: pools.isActive,
        metadata: pools.metadata,
        createdAt: pools.createdAt,
        updatedAt: pools.updatedAt,
        protocolName: protocols.name,
        protocolCategory: protocols.category,
        protocolLogo: protocols.logo,
        blockchainName: blockchains.name,
        blockchainSymbol: blockchains.symbol,
      })
      .from(pools)
      .leftJoin(protocols, eq(pools.protocolId, protocols.id))
      .leftJoin(blockchains, eq(pools.blockchainId, blockchains.id))
      .where(
        and(
          eq(pools.isActive, true),
          or(
            ilike(protocols.name, `%${query}%`),
            ilike(pools.name, `%${query}%`),
            ilike(blockchains.name, `%${query}%`)
          )
        )
      )
      .orderBy(desc(pools.tvl))
      .limit(50);

    return result.map(row => ({
      ...row,
      protocol: {
        name: row.protocolName,
        category: row.protocolCategory,
        logo: row.protocolLogo,
      },
      blockchain: {
        name: row.blockchainName,
        symbol: row.blockchainSymbol,
      },
    }));
  }
}

export const storage = new DatabaseStorage();
