import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage, type PoolFilters } from "./storage";
import { insertUserSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { dataFetcher } from "./data-fetcher";
import chatRoutes from "./routes/chat";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register chat routes
  app.use(chatRoutes);

  // Auth routes
  app.post("/api/register", async (req, res) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }
      
      const user = await storage.createUser({ username, password });
      res.json({ message: "User created successfully", userId: user.id });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({
          error: "Validation failed",
          details: fromZodError(error).message,
        });
      }
      
      console.error("Registration error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      req.session.userId = user.id;
      res.json({ message: "Login successful", user: { id: user.id, username: user.username } });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({
          error: "Validation failed",
          details: fromZodError(error).message,
        });
      }
      
      console.error("Login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ error: "Could not log out" });
      }
      res.json({ message: "Logout successful" });
    });
  });

  app.get("/api/me", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json({ user: { id: user.id, username: user.username } });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // DeFi API routes
  app.get("/api/pools", async (req, res) => {
    try {
      const filters: PoolFilters = {
        chain: req.query.chain as string,
        category: req.query.category as string,
        risk: req.query.risk as string,
        sortBy: req.query.sortBy as 'apy' | 'tvl' | 'volume',
        search: req.query.search as string,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 50,
        offset: req.query.offset ? parseInt(req.query.offset as string) : 0,
      };

      const pools = await storage.getAllPools(filters);
      res.json({ pools });
    } catch (error) {
      console.error("Get pools error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/protocols", async (req, res) => {
    try {
      const protocols = await storage.getAllProtocols();
      res.json({ protocols });
    } catch (error) {
      console.error("Get protocols error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/blockchains", async (req, res) => {
    try {
      const blockchains = await storage.getAllBlockchains();
      res.json({ blockchains });
    } catch (error) {
      console.error("Get blockchains error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/pools/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Search query is required" });
      }

      const pools = await storage.searchPools(query);
      res.json({ pools });
    } catch (error) {
      console.error("Search pools error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await dataFetcher.getPoolStats();
      res.json(stats);
    } catch (error) {
      console.error("Get stats error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
